// Datos ficticios para pruebas (nunca se mezclan con datos reales: viven solo en memoria).
import { CATEGORIES } from '../../src/domain/catalog';
import { DEFAULT_WEIGHTS, ENGINE } from '../../src/domain/recommender/config';
import type { RecommendationInput } from '../../src/domain/recommender/types';
import type { Category, Garment, WeatherSnapshot } from '../../src/domain/types';

let n = 0;
export function garment(over: Partial<Garment> & { category: Category }): Garment {
  const c = CATEGORIES[over.category];
  n++;
  return {
    id: over.id ?? `g${n}`,
    profileId: 'p1',
    name: over.name ?? `${c.label} ${n}`,
    colorPrimary: 'negro',
    colorsSecondary: [],
    pattern: 'liso',
    style: 'casual',
    formality: c.defaultFormality,
    seasons: ['todo_el_ano'],
    tempMin: c.defaultTemp[0],
    tempMax: c.defaultTemp[1],
    waterproof: false,
    wearCount: 0,
    status: 'disponible',
    favorite: false,
    tags: [],
    createdAt: '2026-01-01T00:00:00Z',
    updatedAt: '2026-01-01T00:00:00Z',
    ...over,
  };
}

export const EVENT_DIARIO = { key: 'diario', label: 'Día a día', formality: 2, strict: false, preferredStyles: ['casual' as const] };
export const EVENT_FORMAL = { key: 'reunion_formal', label: 'Reunión formal', formality: 4, strict: true, preferredStyles: ['formal' as const, 'elegante' as const] };

export function weather(tempC: number, condition: WeatherSnapshot['condition'] = 'soleado', source: 'api' | 'manual' = 'manual'): WeatherSnapshot {
  return { source, date: '2026-11-20', tempC, precipProbability: condition === 'lluvioso' ? 90 : 0, condition, description: condition };
}

export function input(garments: Garment[], over: Partial<RecommendationInput> = {}): RecommendationInput {
  return {
    garments,
    date: '2026-11-20',
    today: '2026-11-20',
    event: EVENT_DIARIO,
    weather: weather(20),
    prefs: { preferredStyles: [], avoidColors: [], allowUsedPending: false, repeatWindowDays: 7, minCoherence: ENGINE.minCoherence, weights: { ...DEFAULT_WEIGHTS } },
    wears: [],
    ratings: [],
    blocked: [],
    planned: [],
    respectReservations: true,
    includeAccessories: false,
    ...over,
  };
}

/** Generador pseudoaleatorio determinista (mulberry32) para pruebas de propiedades. */
export function rng(seed: number) {
  return () => {
    seed |= 0; seed = (seed + 0x6d2b79f5) | 0;
    let t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
