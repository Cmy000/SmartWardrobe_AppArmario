import assert from 'node:assert/strict';
import { test } from 'node:test';
import { RuleBasedRecommender } from '../../src/domain/recommender/engine';
import { describeWmo, manualWeather, MemoryCache, WeatherError, WeatherService } from '../../src/domain/weather';
import { garment, input } from './fixtures';

const loc = { name: 'Bogotá', latitude: 4.61, longitude: -74.08 };
const sample = {
  daily: {
    time: ['2026-11-20', '2026-11-21'],
    temperature_2m_max: [19.4, 20],
    temperature_2m_min: [8.2, 9],
    apparent_temperature_max: [18.1, 19],
    precipitation_probability_max: [70, 10],
    weather_code: [61, 2],
  },
};
const okFetch = (calls: string[]) => async (url: string) => { calls.push(url); return { ok: true, status: 200, json: async () => sample }; };

test('parsea el pronóstico de Open-Meteo y marca la fuente como api', async () => {
  const s = await new WeatherService(okFetch([])).forecast(loc, '2026-11-20');
  assert.equal(s.source, 'api');
  assert.equal(s.tempC, Math.round((0.6 * 19.4 + 0.4 * 8.2) * 10) / 10);
  assert.equal(s.precipProbability, 70);
  assert.equal(s.condition, 'lluvioso');
  assert.equal(s.description, 'Lluvia');
});

test('usa caché dentro del TTL y vuelve a consultar al vencer', async () => {
  const calls: string[] = [];
  let now = 1_000_000;
  const svc = new WeatherService(okFetch(calls), new MemoryCache(), () => now);
  await svc.forecast(loc, '2026-11-20');
  await svc.forecast(loc, '2026-11-21');
  assert.equal(calls.length, 1);
  now += 61 * 60 * 1000;
  await svc.forecast(loc, '2026-11-20');
  assert.equal(calls.length, 2);
});

test('falla de red → WeatherError("red"), sin datos inventados', async () => {
  const svc = new WeatherService(async () => { throw new TypeError('Failed to fetch'); });
  await assert.rejects(svc.forecast(loc, '2026-11-20'), (e: unknown) => e instanceof WeatherError && e.kind === 'red');
});

test('HTTP 5xx y respuesta mal formada producen errores tipados', async () => {
  await assert.rejects(new WeatherService(async () => ({ ok: false, status: 503, json: async () => ({}) })).forecast(loc, '2026-11-20'), (e: unknown) => (e as WeatherError).kind === 'http');
  await assert.rejects(new WeatherService(async () => ({ ok: true, status: 200, json: async () => ({ hola: 1 }) })).forecast(loc, '2026-11-20'), (e: unknown) => (e as WeatherError).kind === 'respuesta_invalida');
});

test('sin ubicación o fecha fuera del horizonte → error que activa el modo manual', async () => {
  await assert.rejects(new WeatherService(okFetch([])).forecast(undefined, '2026-11-20'), (e: unknown) => (e as WeatherError).kind === 'sin_ubicacion');
  await assert.rejects(new WeatherService(okFetch([])).forecast(loc, '2027-01-30'), (e: unknown) => (e as WeatherError).kind === 'fuera_de_rango');
});

test('clima manual: fuente manual, sensación térmica opcional y el motor genera outfits', () => {
  const m = manualWeather('2026-11-20', 15, 'lluvioso', 12);
  assert.equal(m.source, 'manual');
  assert.equal(m.tempC, 12);
  const gs = [garment({ id: 't', category: 'sueter' }), garment({ id: 'b', category: 'jean' }), garment({ id: 's', category: 'botas', waterproof: true }), garment({ id: 'o', category: 'chaqueta', waterproof: true })];
  const r = new RuleBasedRecommender().recommend(input(gs, { weather: m }));
  assert.ok(r.outfits.length > 0);
  assert.ok(r.outfits[0].explanation.some((l) => l.text.includes('ingresado manualmente')));
});

test('códigos WMO', () => {
  assert.equal(describeWmo(0).condition, 'soleado');
  assert.equal(describeWmo(3).condition, 'nublado');
  assert.equal(describeWmo(95).condition, 'lluvioso');
});
