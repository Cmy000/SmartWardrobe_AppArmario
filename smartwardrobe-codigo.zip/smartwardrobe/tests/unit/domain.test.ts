import assert from 'node:assert/strict';
import { test } from 'node:test';
import { colorPair, outfitColor } from '../../src/domain/colors';
import { checkNewPlan, planConflicts, usageFromHistory } from '../../src/domain/planning';
import { computeStats, MIN_TRACKING_DAYS } from '../../src/domain/stats';
import { canTransition, InvalidTransitionError, isRecommendable, planTransition, TRANSITIONS } from '../../src/domain/status';
import type { GarmentStatus, WearRecord } from '../../src/domain/types';
import { garment } from './fixtures';

// ---------- Máquina de estados ----------
test('transiciones válidas e inválidas', () => {
  assert.ok(canTransition('disponible', 'lavanderia'));
  assert.ok(canTransition('lavanderia', 'disponible'));
  assert.ok(canTransition('reparacion', 'disponible'));
  assert.ok(!canTransition('lavanderia', 'usada'));
  assert.ok(!canTransition('retirada', 'lavanderia'));
  assert.throws(() => planTransition('lavanderia', { to: 'usada' }), InvalidTransitionError);
  assert.throws(() => planTransition('disponible', { to: 'disponible' }), InvalidTransitionError);
});

test('reparación exige motivo y abre/cierra mantenimiento', () => {
  assert.throws(() => planTransition('disponible', { to: 'reparacion' }), /motivo/);
  assert.deepEqual(planTransition('disponible', { to: 'reparacion', reason: 'Botón suelto' }), { openMaintenance: 'reparacion', closeMaintenance: false });
  assert.deepEqual(planTransition('reparacion', { to: 'disponible' }), { openMaintenance: undefined, closeMaintenance: true });
  assert.deepEqual(planTransition('usada', { to: 'lavanderia' }), { openMaintenance: 'lavanderia', closeMaintenance: false });
});

test('solo "disponible" (y "usada" si se permite) es recomendable', () => {
  const all = Object.keys(TRANSITIONS) as GarmentStatus[];
  assert.deepEqual(all.filter((s) => isRecommendable(s, false)), ['disponible']);
  assert.deepEqual(all.filter((s) => isRecommendable(s, true)), ['disponible', 'usada']);
});

test('usar una prenda no la manda a lavar automáticamente: usada → disponible es válido', () => {
  assert.ok(canTransition('usada', 'disponible'));
});

// ---------- Colores ----------
test('compatibilidad cromática', () => {
  assert.equal(colorPair('negro', 'rojo').relation, 'neutral');
  assert.equal(colorPair('rojo', 'rojo').relation, 'mismo');
  assert.equal(colorPair('azul', 'naranja').relation, 'complementario');
  assert.equal(colorPair('verde', 'fucsia').relation, 'complementario');
  assert.equal(colorPair('rojo', 'verde').relation, 'choque');
  const neutral = outfitColor([{ colorPrimary: 'blanco', pattern: 'liso' }, { colorPrimary: 'negro', pattern: 'liso' }]);
  const loud = outfitColor([{ colorPrimary: 'rojo', pattern: 'flores' }, { colorPrimary: 'verde', pattern: 'cuadros' }, { colorPrimary: 'morado', pattern: 'liso' }]);
  assert.ok(neutral.score > loud.score);
  assert.equal(neutral.summary, 'paleta neutra');
});

// ---------- Historial ----------
const wear = (date: string, itemIds: string[]): WearRecord => ({ id: date + itemIds.join(), profileId: 'p1', date, itemIds, createdAt: '' });

test('métricas de uso salen solo del historial real e ignoran fechas futuras', () => {
  const wears = [wear('2026-11-01', ['a', 'b']), wear('2026-11-10', ['a']), wear('2026-12-01', ['a'])];
  assert.deepEqual(usageFromHistory('a', wears, '2026-11-20'), { wearCount: 2, lastWornAt: '2026-11-10' });
  assert.deepEqual(usageFromHistory('c', wears, '2026-11-20'), { wearCount: 0, lastWornAt: undefined });
});

test('conflictos de planificación: prenda en lavandería y doble reserva', () => {
  const gs = [garment({ id: 'a', category: 'camiseta', status: 'lavanderia', name: 'Camiseta A' }), garment({ id: 'b', category: 'jean' })];
  const plans = [
    { id: 'p1', profileId: 'p1', date: '2026-11-25', itemIds: ['a', 'b'], createdAt: '1' },
    { id: 'p2', profileId: 'p1', date: '2026-11-25', itemIds: ['b'], createdAt: '2' },
    { id: 'p0', profileId: 'p1', date: '2026-11-01', itemIds: ['a'], createdAt: '0' }, // pasado: no se evalúa
  ];
  const c = planConflicts(plans, gs, '2026-11-20');
  assert.equal(c.filter((x) => x.kind === 'no_disponible').length, 1);
  assert.equal(c.filter((x) => x.kind === 'doble_reserva').length, 1);
  assert.equal(checkNewPlan(['b'], '2026-11-25', plans, gs).length, 1);
  assert.equal(checkNewPlan(['b'], '2026-11-26', plans, gs).length, 0);
});

// ---------- Estadísticas ----------
test('estadísticas con datos conocidos', () => {
  const gs = [
    garment({ id: 'a', category: 'camiseta', colorPrimary: 'blanco', wearCount: 3, cost: 60000 }),
    garment({ id: 'b', category: 'jean', colorPrimary: 'denim', wearCount: 1 }),
    garment({ id: 'c', category: 'tenis', colorPrimary: 'blanco', wearCount: 0, status: 'lavanderia', cost: 200000 }),
    garment({ id: 'd', category: 'chaqueta', colorPrimary: 'negro', status: 'retirada' }),
  ];
  const wears = [wear('2026-10-01', ['a', 'b']), wear('2026-11-02', ['a']), wear('2026-11-15', ['a'])];
  const maint = [{ id: 'm', profileId: 'p1', garmentId: 'c', kind: 'lavanderia' as const, reportedAt: '' }];
  const s = computeStats(gs, wears, maint, '2026-11-20', 30);
  assert.equal(s.totalGarments, 3);
  assert.equal(s.retired, 1);
  assert.equal(s.available, 2);
  assert.equal(s.pendingMaintenance, 1);
  assert.equal(s.wearsInPeriod, 2);
  assert.equal(s.outfitsRegistered, 3);
  assert.ok('value' in s.usedShare && s.usedShare.value !== null);
  assert.equal((s.usedShare as { value: number }).value, 1 / 3); // solo 'a' usada en 30 días
  assert.deepEqual(s.byColor.find((c) => c.key === 'blanco')?.count, 2);
  assert.equal(s.frequency[0].id, 'a');
  assert.equal(s.costPerWear.find((x) => x.id === 'a')!.cpw, 20000);
  assert.equal(s.costPerWear.find((x) => x.id === 'c')!.cpw, null); // sin usos: no se inventa
  assert.ok(s.neverWorn.value !== null && s.neverWorn.value.count === 1);
});

test('estadísticas: con poco historial "sin uso" se reporta como datos insuficientes', () => {
  const gs = [garment({ id: 'a', category: 'camiseta' })];
  const s = computeStats(gs, [wear('2026-11-18', ['a'])], [], '2026-11-20', null);
  assert.equal(s.neverWorn.value, null);
  assert.match((s.neverWorn as { reason: string }).reason, new RegExp(String(MIN_TRACKING_DAYS)));
  const empty = computeStats([], [], [], '2026-11-20', 30);
  assert.equal(empty.usedShare.value, null);
});
