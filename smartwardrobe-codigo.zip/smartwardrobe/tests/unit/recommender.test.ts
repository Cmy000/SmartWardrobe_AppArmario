import assert from 'node:assert/strict';
import { test } from 'node:test';
import { CATEGORIES, COLORS } from '../../src/domain/catalog';
import { DEFAULT_WEIGHTS } from '../../src/domain/recommender/config';
import { RuleBasedRecommender, comboKey } from '../../src/domain/recommender/engine';
import { slotOf } from '../../src/domain/recommender/features';
import { BLOCKING_STATUSES } from '../../src/domain/status';
import type { Category, Garment, GarmentStatus, Style } from '../../src/domain/types';
import { EVENT_FORMAL, garment, input, rng, weather } from './fixtures';

const engine = new RuleBasedRecommender();

function basicWardrobe(): Garment[] {
  return [
    garment({ id: 't1', category: 'camiseta', colorPrimary: 'blanco' }),
    garment({ id: 't2', category: 'camisa', colorPrimary: 'celeste', formality: 3 }),
    garment({ id: 'b1', category: 'jean', colorPrimary: 'denim' }),
    garment({ id: 'b2', category: 'pantalon', colorPrimary: 'negro', formality: 3 }),
    garment({ id: 's1', category: 'tenis', colorPrimary: 'blanco' }),
    garment({ id: 's2', category: 'zapatos', colorPrimary: 'negro', formality: 4 }),
    garment({ id: 'o1', category: 'chaqueta', colorPrimary: 'camel' }),
  ];
}

const isComplete = (slots: string[]) => {
  const s = new Set(slots);
  const hasShoes = s.has('shoes');
  const body = (s.has('top') && s.has('bottom') && !s.has('onepiece')) || (s.has('onepiece') && !s.has('top') && !s.has('bottom'));
  return hasShoes && body;
};

test('genera outfits completos y coherentes con un armario básico', () => {
  const r = engine.recommend(input(basicWardrobe()));
  assert.ok(r.outfits.length > 0, 'debería haber recomendaciones');
  const byId = new Map(basicWardrobe().map((g) => [g.id, g]));
  for (const o of r.outfits) {
    assert.ok(isComplete(o.itemIds.map((id) => slotOf(byId.get(id)!))), `outfit incompleto: ${o.itemIds}`);
    assert.ok(o.score >= 0 && o.score <= 1);
    assert.ok(o.coherence >= 0.6);
    assert.equal(new Set(o.itemIds).size, o.itemIds.length, 'sin prendas duplicadas');
  }
  // ordenadas por puntuación descendente
  for (let i = 1; i < r.outfits.length; i++) assert.ok(r.outfits[i - 1].score >= r.outfits[i].score);
});

test('REGLA ESTRICTA: ninguna prenda no disponible aparece jamás (prueba de propiedades, 300 armarios aleatorios)', () => {
  const rand = rng(42);
  const cats = Object.keys(CATEGORIES) as Category[];
  const statuses: GarmentStatus[] = ['disponible', 'disponible', 'disponible', 'usada', 'lavanderia', 'reparacion', 'guardada', 'retirada'];
  const colors = Object.keys(COLORS);
  const styles: Style[] = ['casual', 'elegante', 'formal', 'deportivo', 'minimalista', 'urbano', 'bohemio'];
  const pick = <T,>(a: T[]) => a[Math.floor(rand() * a.length)];
  let totalOutfits = 0;
  for (let trial = 0; trial < 300; trial++) {
    const gs: Garment[] = [];
    const size = 6 + Math.floor(rand() * 30);
    for (let i = 0; i < size; i++) gs.push(garment({ id: `x${trial}-${i}`, category: pick(cats), status: pick(statuses), colorPrimary: pick(colors), style: pick(styles), formality: 1 + Math.floor(rand() * 5) }));
    const allowUsed = rand() < 0.3;
    const base = input(gs, { weather: rand() < 0.2 ? null : weather(Math.round(rand() * 35), pick(['soleado', 'nublado', 'lluvioso'] as const)), includeAccessories: rand() < 0.5 });
    const r = engine.recommend({ ...base, prefs: { ...base.prefs, allowUsedPending: allowUsed } });
    const byId = new Map(gs.map((g) => [g.id, g]));
    for (const o of r.outfits) {
      totalOutfits++;
      for (const id of o.itemIds) {
        const st = byId.get(id)!.status;
        assert.ok(!BLOCKING_STATUSES.has(st), `prenda ${id} en estado ${st} apareció en una recomendación`);
        if (!allowUsed) assert.equal(st, 'disponible');
        assert.equal(byId.get(id)!.profileId, 'p1');
      }
    }
  }
  assert.ok(totalOutfits > 100, `la prueba debe ejercitar muchos outfits (fueron ${totalOutfits})`);
});

test('prendas en estado "usada" solo entran si el usuario lo habilita', () => {
  const gs = basicWardrobe().map((g) => (g.id === 's1' || g.id === 's2' ? { ...g, status: 'usada' as const } : g));
  assert.equal(engine.recommend(input(gs)).outfits.length, 0);
  const base = input(gs);
  assert.ok(engine.recommend({ ...base, prefs: { ...base.prefs, allowUsedPending: true } }).outfits.length > 0);
});

test('filtro de temperatura: excluye prendas fuera de rango y lo informa', () => {
  const gs = [...basicWardrobe(), garment({ id: 'sh', category: 'short', colorPrimary: 'beige' }), garment({ id: 'sa', category: 'sandalias', colorPrimary: 'camel' })];
  const r = engine.recommend(input(gs, { weather: weather(8) }));
  assert.ok(r.excluded.temperatura >= 2);
  for (const o of r.outfits) assert.ok(!o.itemIds.includes('sh') && !o.itemIds.includes('sa'));
});

test('con frío se exige capa exterior; con calor se prohíbe', () => {
  const cold = engine.recommend(input(basicWardrobe(), { weather: weather(12) }));
  assert.ok(cold.outfits.length > 0);
  for (const o of cold.outfits) assert.ok(o.itemIds.includes('o1'), 'debe incluir la chaqueta');
  const hot = engine.recommend(input(basicWardrobe().map((g) => (g.id === 'o1' ? { ...g, tempMax: 35 } : g)), { weather: weather(28) }));
  for (const o of hot.outfits) assert.ok(!o.itemIds.includes('o1'));
});

test('frío sin abrigo disponible: no bloquea, genera sin capa y avisa', () => {
  const gs = basicWardrobe().map((g) => (g.id === 'o1' ? { ...g, status: 'lavanderia' as const } : g));
  const r = engine.recommend(input(gs, { weather: weather(12) }));
  assert.ok(r.outfits.length > 0);
  assert.ok(r.warnings.some((w) => w.includes('abrigos')));
});

test('sin datos de clima la generación funciona igualmente', () => {
  const r = engine.recommend(input(basicWardrobe(), { weather: null }));
  assert.ok(r.outfits.length > 0);
  assert.ok(r.outfits[0].explanation.some((l) => l.factor === 'weather' && l.text.includes('Sin datos')));
});

test('formalidad obligatoria: reunión formal descarta prendas informales', () => {
  const r = engine.recommend(input(basicWardrobe(), { event: EVENT_FORMAL }));
  for (const o of r.outfits) for (const id of o.itemIds) assert.ok(!['t1', 's1'].includes(id), `prenda informal ${id} en reunión formal`);
  assert.ok(r.excluded.formalidad >= 2);
});

test('combinaciones bloqueadas por el usuario nunca se recomiendan', () => {
  const r0 = engine.recommend(input(basicWardrobe()));
  const top = r0.outfits[0].itemIds;
  const pair = top.slice(0, 2);
  const r = engine.recommend(input(basicWardrobe(), { blocked: [{ id: 'b', profileId: 'p1', itemIds: pair, createdAt: '' }] }));
  for (const o of r.outfits) assert.ok(!pair.every((id) => o.itemIds.includes(id)));
});

test('prevención de repeticiones: no repite exactamente un outfit usado dentro de la ventana', () => {
  const r0 = engine.recommend(input(basicWardrobe()));
  const worn = r0.outfits[0].itemIds;
  const wears = [{ id: 'w', profileId: 'p1', date: '2026-11-18', itemIds: worn, createdAt: '' }];
  const r = engine.recommend(input(basicWardrobe(), { wears }));
  assert.ok(!r.outfits.some((o) => comboKey(o.itemIds) === comboKey(worn)));
  // Fuera de la ventana (hace 20 días con ventana de 7) sí puede volver a aparecer.
  const r2 = engine.recommend(input(basicWardrobe(), { wears: [{ ...wears[0], date: '2026-10-31' }] }));
  assert.ok(r2.outfits.some((o) => comboKey(o.itemIds) === comboKey(worn)));
});

test('valoraciones: una combinación calificada con 5 sube respecto a calificada con 1', () => {
  const base = engine.recommend(input(basicWardrobe()));
  const target = base.outfits[base.outfits.length - 1].itemIds;
  const rate = (rating: number) => engine.recommend(input(basicWardrobe(), { ratings: [{ id: 'r', profileId: 'p1', comboKey: comboKey(target), itemIds: target, rating, at: '2026-11-01' }] }));
  const s5 = rate(5).outfits.find((o) => comboKey(o.itemIds) === comboKey(target));
  const s1 = rate(1).outfits.find((o) => comboKey(o.itemIds) === comboKey(target));
  assert.ok(s5, 'la combinación bien calificada debe seguir apareciendo');
  if (s1) assert.ok(s5!.score > s1.score);
  assert.ok(s5!.explanation.some((l) => l.factor === 'rating' && l.text.includes('5/5')));
});

test('la rotación no rescata un conjunto incoherente (umbral de coherencia)', () => {
  // Prendas de estilos incompatibles y colores que chocan, nunca usadas (máximo bono de rotación).
  const gs = [
    garment({ id: 'a', category: 'camiseta', style: 'deportivo', colorPrimary: 'fucsia', pattern: 'animal_print', formality: 1 }),
    garment({ id: 'b', category: 'pantalon', style: 'formal', colorPrimary: 'verde', pattern: 'cuadros', formality: 4 }),
    garment({ id: 'c', category: 'zapatos', style: 'formal', colorPrimary: 'naranja', pattern: 'flores', formality: 4 }),
  ];
  const w = { ...DEFAULT_WEIGHTS, rotation: 50, recency: 50 };
  const base = input(gs);
  const r = engine.recommend({ ...base, prefs: { ...base.prefs, weights: w } });
  assert.equal(r.outfits.length, 0);
});

test('explicaciones: cada frase corresponde a un componente calculado', () => {
  const gs = basicWardrobe().map((g) => (g.id === 'o1' ? { ...g, lastWornAt: '2026-10-27', wearCount: 1 } : { ...g, lastWornAt: '2026-11-15', wearCount: 3 }));
  const r = engine.recommend(input(gs, { weather: weather(12, 'nublado', 'api') }));
  const o = r.outfits[0];
  const valid = new Set(['disponibilidad', 'plantilla', ...Object.keys(DEFAULT_WEIGHTS)]);
  for (const l of o.explanation) assert.ok(valid.has(l.factor), `factor desconocido ${l.factor}`);
  const recency = o.explanation.find((l) => l.factor === 'recency');
  assert.ok(recency, 'debe mencionar la chaqueta sin usar');
  assert.match(recency!.text, /Hace 24 días/);
  assert.ok(o.explanation.find((l) => l.factor === 'weather')!.text.includes('Open-Meteo'));
  for (const k of Object.keys(DEFAULT_WEIGHTS)) assert.ok(typeof o.components[k as keyof typeof DEFAULT_WEIGHTS] === 'number');
});

test('eficiencia: con un armario grande evalúa muchas menos combinaciones que el producto cartesiano', () => {
  const gs: Garment[] = [];
  const cats: Category[] = ['camiseta', 'camisa', 'jean', 'pantalon', 'tenis', 'zapatos', 'chaqueta'];
  for (let i = 0; i < 280; i++) gs.push(garment({ id: `big${i}`, category: cats[i % cats.length], colorPrimary: Object.keys(COLORS)[i % 20] }));
  const t0 = performance.now();
  const r = engine.recommend(input(gs, { weather: weather(14) }));
  const ms = performance.now() - t0;
  const cartesian = 80 * 80 * 40 * 80; // tops × bottoms × outer × shoes
  assert.ok(r.candidatesEvaluated < cartesian / 100, `evaluadas ${r.candidatesEvaluated}`);
  assert.ok(ms < 1000, `tardó ${ms.toFixed(0)} ms`);
  assert.ok(r.outfits.length > 0);
});

test('resultados variados: dos recomendaciones no comparten más de la mitad de las prendas cuando hay alternativas', () => {
  const gs: Garment[] = [];
  const cats: Category[] = ['camiseta', 'jean', 'tenis'];
  const cols = ['blanco', 'negro', 'gris', 'beige', 'azul_marino'];
  for (let i = 0; i < 15; i++) gs.push(garment({ id: `v${i}`, category: cats[i % 3], colorPrimary: cols[i % 5] }));
  const r = engine.recommend(input(gs));
  assert.ok(r.outfits.length >= 4);
  const ids = r.outfits.map((o) => o.itemIds);
  const overlap = (a: string[], b: string[]) => a.filter((x) => b.includes(x)).length / new Set([...a, ...b]).size;
  assert.ok(overlap(ids[0], ids[1]) <= 0.5);
});

test('reservas: prendas planificadas para el mismo día no se recomiendan si se respeta la reserva', () => {
  const planned = [{ id: 'pl', profileId: 'p1', date: '2026-11-20', itemIds: ['s1', 's2'], createdAt: '' }];
  assert.equal(engine.recommend(input(basicWardrobe(), { planned })).outfits.length, 0);
  assert.ok(engine.recommend(input(basicWardrobe(), { planned, respectReservations: false })).outfits.length > 0);
  assert.ok(engine.recommend(input(basicWardrobe(), { planned: [{ ...planned[0], date: '2026-11-25' }] })).outfits.length > 0);
});
