// Pruebas de extremo a extremo en Chromium real (Playwright) sobre el build estático `dist/`.
// Cubren los criterios de aceptación: perfiles aislados, prendas con foto, estados, clima API/manual,
// recomendaciones solo con prendas disponibles, registro de uso, historial, estadísticas,
// persistencia tras recargar, respaldo/restauración y acceso cruzado por URL.
// Open-Meteo se simula con `page.route` (respuestas de prueba, nunca datos presentados como reales).
// Uso: npm run test:e2e   (opcional: SCREENSHOTS=1 para guardar capturas en tests/e2e/screens/)
import { chromium } from 'playwright';
import { spawn } from 'node:child_process';
import fs from 'node:fs';
import path from 'node:path';
import zlib from 'node:zlib';
import assert from 'node:assert/strict';

const root = path.resolve(path.dirname(new URL(import.meta.url).pathname), '../..');
const PORT = 5199;
const BASE = `http://127.0.0.1:${PORT}/`;
const shots = process.env.SCREENSHOTS ? path.join(root, 'tests/e2e/screens') : null;
if (shots) fs.mkdirSync(shots, { recursive: true });
const tmp = fs.mkdtempSync('/tmp/sw-e2e-');

// ---------- Fotos de prueba: PNG sólidos generados aquí (sin dependencias) ----------
function png(r, g, b, w = 64, h = 80) {
  const crc = (buf) => { let c, crcT = []; for (let n = 0; n < 256; n++) { c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1; crcT[n] = c >>> 0; } let x = 0xffffffff; for (const v of buf) x = crcT[(x ^ v) & 0xff] ^ (x >>> 8); return (x ^ 0xffffffff) >>> 0; };
  const chunk = (type, data) => { const len = Buffer.alloc(4); len.writeUInt32BE(data.length); const td = Buffer.concat([Buffer.from(type), data]); const c = Buffer.alloc(4); c.writeUInt32BE(crc(td)); return Buffer.concat([len, td, c]); };
  const ihdr = Buffer.alloc(13); ihdr.writeUInt32BE(w, 0); ihdr.writeUInt32BE(h, 4); ihdr[8] = 8; ihdr[9] = 2;
  const raw = Buffer.alloc((w * 3 + 1) * h); for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) raw.set([r, g, b], y * (w * 3 + 1) + 1 + x * 3);
  return Buffer.concat([Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]), chunk('IHDR', ihdr), chunk('IDAT', zlib.deflateSync(raw)), chunk('IEND', Buffer.alloc(0))]);
}
const photo = (name, rgb) => { const p = path.join(tmp, `${name}.png`); fs.writeFileSync(p, png(...rgb)); return p; };
const notImage = path.join(tmp, 'falsa.png'); fs.writeFileSync(notImage, 'esto no es una imagen');

const forecastFixture = () => {
  const d = new Date(); const time = [];
  for (let i = 0; i < 16; i++) { const x = new Date(d.getFullYear(), d.getMonth(), d.getDate() + i); time.push(`${x.getFullYear()}-${String(x.getMonth() + 1).padStart(2, '0')}-${String(x.getDate()).padStart(2, '0')}`); }
  return { daily: { time, temperature_2m_max: time.map(() => 19), temperature_2m_min: time.map(() => 9), apparent_temperature_max: time.map(() => 18), precipitation_probability_max: time.map(() => 20), weather_code: time.map(() => 3) } };
};

// ---------- Infraestructura ----------
const server = spawn(process.execPath, [path.join(root, 'scripts/serve.mjs'), String(PORT)], { stdio: 'pipe' });
await new Promise((r) => server.stdout.once('data', r));
const browser = await chromium.launch();
const results = [];
let failed = 0;
async function step(name, fn) {
  const t0 = Date.now();
  try { await fn(); results.push(`ok   ${name} (${Date.now() - t0} ms)`); }
  catch (e) { failed++; results.push(`FAIL ${name}\n     ${String(e.message).split('\n').slice(0, 4).join('\n     ')}`); }
}

const ctx = await browser.newContext({ viewport: { width: 390, height: 844 }, deviceScaleFactor: 2, isMobile: true, hasTouch: true, acceptDownloads: true, locale: 'es-CO' });
const page = await ctx.newPage();
const consoleErrors = [];
page.on('pageerror', (e) => consoleErrors.push(e.message));
page.on('console', (m) => { if (m.type() === 'error' && !/open-meteo|Failed to load resource/.test(m.text())) consoleErrors.push(m.text()); });
let weatherMode = 'fail';
await ctx.route(/open-meteo\.com/, (route) => {
  const u = route.request().url();
  if (weatherMode === 'fail') return route.abort('internetdisconnected');
  if (u.includes('geocoding')) return route.fulfill({ json: { results: [{ name: 'Bogotá', admin1: 'Bogotá D.C.', country: 'Colombia', latitude: 4.60971, longitude: -74.08175 }] } });
  return route.fulfill({ json: forecastFixture() });
});
const shot = async (n) => { if (shots) await page.screenshot({ path: path.join(shots, `${n}.png`), fullPage: true }); };
const go = async (hash) => { await page.goto(BASE + '#' + hash); await page.waitForLoadState('domcontentloaded'); };
const ids = {};

async function createProfile(name) {
  await go('/');
  await page.getByRole('button', { name: 'Crear perfil' }).first().click();
  await page.getByLabel('Tu nombre').fill(name);
  await page.locator('form').getByRole('button', { name: 'Crear perfil' }).click();
  await page.getByRole('heading', { name: new RegExp(`, ${name}$`) }).waitFor();
}
async function logout() {
  await go('/ajustes');
  await page.getByRole('button', { name: 'Cerrar sesión' }).click();
  await page.getByText('¿Quién eres?').waitFor();
}
async function addGarment({ name, category, color, rgb, extra }) {
  await go('/prenda/nueva');
  await page.getByTestId('photo-input').setInputFiles(photo(name.replace(/\W/g, ''), rgb));
  await page.locator('img[alt="Vista previa"]').waitFor();
  await page.getByTestId('name').fill(name);
  await page.getByTestId('category').selectOption(category);
  await page.getByRole('radio', { name: color, exact: true }).click();
  if (extra) await extra();
  await page.getByTestId('save-garment').click();
  await page.getByTestId('garment-name').waitFor();
  ids[name] = page.url().split('#/prenda/')[1];
}

// ================= Escenarios =================
await step('1. Crear primer perfil (Ana)', async () => {
  await createProfile('Ana');
  await shot('01-dashboard-vacio');
});

await step('2. Rechaza archivos que no son imágenes (validación de contenido real)', async () => {
  await go('/prenda/nueva');
  await page.getByTestId('photo-input').setInputFiles(notImage);
  await page.getByText('no es una imagen válida').waitFor();
});

const anaWardrobe = [
  { name: 'Camiseta blanca', category: 'camiseta', color: 'Blanco', rgb: [245, 245, 240] },
  { name: 'Suéter gris', category: 'sueter', color: 'Gris', rgb: [150, 150, 155] },
  { name: 'Camisa celeste', category: 'camisa', color: 'Celeste', rgb: [156, 199, 236] },
  { name: 'Jean azul', category: 'jean', color: 'Denim', rgb: [74, 106, 147] },
  { name: 'Pantalón negro', category: 'pantalon', color: 'Negro', rgb: [28, 25, 23] },
  { name: 'Tenis blancos', category: 'tenis', color: 'Blanco', rgb: [250, 250, 250] },
  { name: 'Botines negros', category: 'botas', color: 'Negro', rgb: [20, 20, 20] },
  { name: 'Chaqueta camel', category: 'chaqueta', color: 'Camel', rgb: [182, 134, 84] },
];
await step('3. Registrar 8 prendas con foto, categoría y color', async () => {
  for (const g of anaWardrobe) await addGarment(g);
  await go('/armario');
  assert.equal(await page.getByTestId('garment-tile').count(), 8);
  await shot('02-armario');
});

await step('4. Estados: botines a lavandería, chaqueta a reparación (motivo obligatorio)', async () => {
  await go(`/prenda/${ids['Botines negros']}`);
  await page.getByTestId('to-lavanderia').click();
  await page.getByTestId('confirm-status').click();
  await page.getByTestId('status-actions').getByText('Marcar disponible').waitFor();
  await go(`/prenda/${ids['Camisa celeste']}`);
  await page.getByTestId('to-reparacion').click();
  assert.ok(await page.getByTestId('confirm-status').isDisabled(), 'sin motivo no se puede confirmar');
  await page.getByTestId('repair-reason').fill('Botón suelto');
  await page.getByTestId('confirm-status').click();
  await page.getByText('Motivo: Botón suelto').waitFor();
  await shot('03-detalle-reparacion');
  await go('/mantenimiento');
  assert.equal(await page.getByTestId('maint-row').count(), 2);
});

await step('5. Clima: la API falla → modo manual automático y la generación NO se bloquea', async () => {
  weatherMode = 'fail';
  await go('/ajustes');
  // sin ubicación configurada
  await go('/generar');
  await page.getByTestId('weather-source').getByText('ingreso manual').waitFor();
  await page.getByLabel('Temperatura aproximada').fill('14');
  await page.getByTestId('generate').click();
  await page.getByTestId('result-card').first().waitFor();
  const text = await page.getByTestId('results').innerText();
  assert.ok(!text.includes('Botines negros'), 'prenda en lavandería apareció');
  assert.ok(!text.includes('Camisa celeste'), 'prenda en reparación apareció');
  assert.match(text, /ingresado manualmente/);
  assert.match(text, /Todas las prendas están disponibles/);
  assert.match(text, /Chaqueta camel|Suéter gris/); // 14 °C: capa o suéter
  await shot('04-recomendaciones-manual');
});

await step('6. Registrar uso efectivo del mejor outfit; las prendas quedan "usadas" (no lavado automático)', async () => {
  await page.getByTestId('wear-btn').first().click();
  await page.getByText('Registrado como usado').waitFor();
  await go('/');
  await page.getByText('¿Qué hacemos con lo que usaste?').waitFor();
  const n = await page.locator('section[aria-labelledby="pend"] li').count();
  assert.ok(n >= 3, `esperaba ≥3 prendas pendientes, hay ${n}`);
  await shot('05-dashboard-pendientes');
  await page.locator('section[aria-labelledby="pend"] li').first().getByRole('button', { name: 'Disponible' }).click();
  await page.waitForTimeout(300);
  assert.equal(await page.locator('section[aria-labelledby="pend"] li').count(), n - 1);
});

await step('7. Historial y estadísticas actualizadas', async () => {
  await go('/calendario');
  assert.equal(await page.getByTestId('wear-entry').count(), 1);
  await shot('06-calendario');
  await go('/estadisticas');
  assert.match(await page.getByTestId('kpi-wears').innerText(), /^OUTFITS REGISTRADOS\s*1/i);
  assert.match(await page.getByTestId('kpi-total').innerText(), /8/);
  assert.match(await page.getByTestId('kpi-used').innerText(), /%/);
  await shot('07-estadisticas');
});

await step('8. Clima desde la API (respuesta simulada) con ubicación configurada; se indica la fuente', async () => {
  weatherMode = 'ok';
  // Antes: decidir el estado de las prendas usadas (vuelven a estar disponibles).
  await go('/mantenimiento');
  while (await page.getByRole('button', { name: 'Disponible', exact: true }).count()) { await page.getByRole('button', { name: 'Disponible', exact: true }).first().click(); await page.waitForTimeout(150); }
  await go('/ajustes');
  await page.getByLabel('Ciudad').fill('Bogota');
  await page.getByRole('button', { name: 'Buscar' }).click();
  await page.getByRole('button', { name: /Bogotá, Bogotá D.C., Colombia/ }).click();
  await page.getByTestId('save-prefs').click();
  await page.getByText('Preferencias guardadas').waitFor();
  await go('/generar');
  await page.getByTestId('weather-source').getByText('Open-Meteo').waitFor();
  await page.getByTestId('generate').click();
  await page.getByTestId('result-card').first().waitFor();
  assert.match(await page.getByTestId('results').innerText(), /pronóstico de Open-Meteo/);
});

await step('9. Guardar outfit, calificarlo y bloquear una combinación', async () => {
  await page.getByTestId('save-btn').first().click();
  await page.getByText('Guardado', { exact: true }).waitFor();
  await page.getByTestId('result-card').first().getByRole('radio', { name: '5 de 5' }).click();
  await page.getByTestId('block-btn').nth(1).click();
  await page.getByText('Bloqueado', { exact: true }).waitFor();
  await go('/outfits');
  assert.equal(await page.getByTestId('saved-outfit').count(), 1);
  await shot('08-mis-outfits');
});

await step('10. Persistencia: recargar el navegador no pierde datos', async () => {
  await page.reload();
  await go('/armario');
  await page.getByTestId('garment-tile').first().waitFor();
  assert.equal(await page.getByTestId('garment-tile').count(), 8);
});

await step('11. Segundo perfil (Bea) aislado: no ve prendas de Ana ni por URL directa', async () => {
  await logout();
  await createProfile('Bea');
  await go('/armario');
  await page.getByText('Tu armario está vacío').waitFor();
  await go(`/prenda/${ids['Jean azul']}`);
  await page.getByTestId('not-found').waitFor();
  await go(`/prenda/${ids['Jean azul']}/editar`);
  await page.getByText('Prenda no encontrada').waitFor();
  await addGarment({ name: 'Vestido rojo de Bea', category: 'vestido', color: 'Rojo', rgb: [192, 57, 43] });
  // Intento de modificar una prenda ajena a nivel de repositorio (simula manipular ids).
  const blocked = await page.evaluate(async (foreignId) => {
    const open = () => new Promise((res, rej) => { const r = indexedDB.open('smartwardrobe'); r.onsuccess = () => res(r.result); r.onerror = () => rej(r.error); });
    const db = await open();
    const g = await new Promise((res) => { const r = db.transaction('garments').objectStore('garments').get(foreignId); r.onsuccess = () => res(r.result); });
    return { foreignOwner: g.profileId, activeProfile: localStorage.getItem('sw-active-profile') };
  }, ids['Jean azul']);
  assert.notEqual(blocked.foreignOwner, blocked.activeProfile);
  await go('/estadisticas');
  assert.match(await page.getByTestId('kpi-total').innerText(), /\b1\b/);
});

await step('12. Volver a Ana: ve solo sus 8 prendas', async () => {
  await logout();
  await page.getByTestId('profile-Ana').click();
  await go('/armario');
  await page.getByTestId('garment-tile').first().waitFor();
  const t = await page.getByTestId('garment-grid').innerText();
  assert.equal(await page.getByTestId('garment-tile').count(), 8);
  assert.ok(!t.includes('Vestido rojo de Bea'));
});

let backupPath;
await step('13. Descargar respaldo ZIP y restaurarlo como perfil nuevo', async () => {
  await go('/ajustes');
  const [dl] = await Promise.all([page.waitForEvent('download'), page.getByTestId('export').click()]);
  backupPath = path.join(tmp, 'backup.zip');
  await dl.saveAs(backupPath);
  assert.ok(fs.statSync(backupPath).size > 2000);
  await page.getByTestId('import').setInputFiles(backupPath);
  await page.getByText(/Respaldo restaurado como el perfil "Ana"/).waitFor();
  await logout();
  assert.equal(await page.getByTestId('profile-Ana').count(), 2);
  await page.getByTestId('profile-Ana').nth(1).click();
  await go('/armario');
  await page.getByTestId('garment-tile').first().waitFor();
  assert.equal(await page.getByTestId('garment-tile').count(), 8);
  await go('/calendario');
  assert.equal(await page.getByTestId('wear-entry').count(), 1);
});

await step('14. Perfil de demostración separado y claramente marcado', async () => {
  await logout();
  await page.getByRole('button', { name: 'Probar con datos de demostración' }).click();
  await page.getByTestId('profile-Demo').waitFor();
  await page.getByTestId('profile-Demo').click();
  await page.getByText('Estás viendo datos de demostración').waitFor();
  await go('/');
  await page.getByTestId('dash-top').waitFor();
  await shot('09-demo-dashboard');
  await go('/armario');
  await shot('10-demo-armario');
  await go('/estadisticas');
  await shot('11-demo-estadisticas');
});

await step('15. Escritorio: navegación lateral y pantallas principales sin errores', async () => {
  const desk = await ctx.browser().newContext({ viewport: { width: 1366, height: 900 } });
  await desk.route(/open-meteo\.com/, (r) => r.fulfill({ json: forecastFixture() }));
  const p = await desk.newPage();
  p.on('pageerror', (e) => consoleErrors.push(e.message));
  await p.goto(BASE);
  await p.getByRole('button', { name: 'Probar con datos de demostración' }).click();
  await p.getByTestId('profile-Demo').click();
  for (const h of ['/', '/armario', '/generar', '/outfits', '/calendario', '/mantenimiento', '/estadisticas', '/ajustes']) {
    await p.goto(BASE + '#' + h);
    await p.waitForTimeout(250);
    assert.ok(await p.locator('h1').first().isVisible(), `sin título en ${h}`);
  }
  await p.goto(BASE + '#/generar');
  await p.getByTestId('generate').click();
  await p.getByTestId('result-card').first().waitFor();
  if (shots) await p.screenshot({ path: path.join(shots, '12-escritorio-generador.png'), fullPage: true });
  await desk.close();
});

await step('16. Sin errores de JavaScript en consola', async () => {
  assert.deepEqual(consoleErrors, []);
});

await browser.close();
server.kill();
console.log(results.join('\n'));
console.log(`\n${results.length - failed}/${results.length} escenarios E2E superados`);
process.exit(failed ? 1 : 0);
