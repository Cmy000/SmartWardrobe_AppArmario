# Manual de usuario — SmartWardrobe

## Primeros pasos
1. Abre el enlace de la app (por ejemplo, `https://<usuario>.github.io/smartwardrobe/`).
2. **Instálala** para usarla como una aplicación: en Android/Chrome, menú ⋮ → *Instalar
   aplicación*; en iPhone/Safari, Compartir → *Agregar a inicio*.
3. Toca **Crear perfil** y escribe tu nombre. Si compartes el dispositivo con alguien,
   ponle un PIN.
4. Si solo quieres explorar, usa **Probar con datos de demostración**: crea un perfil
   aparte, marcado "Demo", con ilustraciones en lugar de fotos.

> Tus datos se guardan **solo en este dispositivo y navegador**. Nadie más los ve. Haz
> respaldos con frecuencia (ver *Copias de seguridad*).

## Registrar prendas
*Armario → Agregar prenda*. Toca el recuadro de la foto: en el celular se abre la cámara.
- La app sugiere el color principal a partir de la foto; verifícalo.
- Al elegir la categoría se rellenan valores típicos de **rango de temperatura** y
  **formalidad**. Ajústalos: el motor los usa para decidir.
- Marca *Apta para lluvia* en chaquetas y calzado impermeables.
- En *Más detalles* puedes agregar material, marca, fecha, **costo** (para calcular el
  costo por uso), etiquetas y observaciones.

## Estados de una prenda
Desde el detalle de una prenda:

| Estado | ¿Se recomienda? | Cuándo usarlo |
|---|---|---|
| Limpia y disponible | Sí | Lista para usar |
| Usada · decidir si lavar | No (configurable) | Queda así después de registrar un uso |
| En lavandería | Nunca | Enviada a lavar |
| Requiere reparación | Nunca | Pide el motivo. Lleva registro de fechas y notas |
| Guardada temporalmente | Nunca | Ropa de otra temporada, en préstamo, etc. |
| Retirada del armario | Nunca | Ya no la usas, pero quieres conservar su historial |

La app **no supone que todo lo usado deba lavarse**. En el inicio aparece "¿Qué hacemos
con lo que usaste?" con dos botones: *Disponible* o *Lavar*. En *Lavandería* puedes
marcar todo como limpio de una vez o dar por terminada una reparación.

## Pedir un outfit
*Crear* (botón central):
1. Elige la fecha y el **evento**. Algunos eventos (reunión formal, ceremonia, deporte)
   exigen una formalidad mínima.
2. **Clima:** si configuraste tu ciudad en *Ajustes*, se usa el pronóstico. Si no hay
   conexión o el servicio falla, aparece el **modo manual**: elige la temperatura, si
   está soleado, nublado o lluvioso, y, si quieres, la sensación térmica. La etiqueta
   "Fuente" siempre indica de dónde salió el dato.
3. Toca **Generar recomendaciones**. Cada opción explica por qué fue elegida; en *Ver
   desglose* puedes ver la puntuación por componente.

Con cada recomendación puedes hacer lo siguiente:
- **Lo usé:** registra el uso real y actualiza los conteos y el calendario. Para fechas
  futuras, el botón es **Planificar**.
- **Guardar:** la añade a *Mis outfits*.
- **Calificar** de 1 a 5 estrellas: las combinaciones mejor calificadas suben en futuras
  recomendaciones.
- **Descartar** u **No sugerir más:** esta última bloquea la combinación para siempre.
  Puedes desbloquearla en *Mis outfits → Bloqueados*.

## Mis outfits
Guarda combinaciones recomendadas o **créalas a mano**: *Crear manualmente* → elige
prendas por tipo. Desde aquí puedes usarlas hoy, planificarlas, marcarlas como favoritas
o calificarlas. Si una prenda del outfit no está disponible, la tarjeta lo indica.

## Calendario
Los puntos marrones indican días con un outfit usado; los círculos verdes, outfits
planificados; los ámbar, un plan con un **conflicto** (una prenda en lavandería o
reservada dos veces). Al tocar un día puedes registrar un plan como usado, quitarlo,
borrar un registro de uso (los conteos se recalculan) o registrar un outfit guardado en
una fecha pasada.

## Estadísticas
Elige el periodo (30 días, 90 días, 1 año o todo). Los indicadores que dependen del
historial muestran **"Datos insuficientes"** hasta que haya al menos 14 días de
registros: la app no inventa cifras. Toca una categoría para filtrar la frecuencia de
uso. Cada gráfico tiene la opción *Ver como tabla*.

## Ajustes
- **Ubicación:** busca tu ciudad o usa tu ubicación actual.
- **Estilos preferidos, colores a evitar y ventana sin repeticiones** (no repetir lo que
  usaste en los últimos N días).
- **Después de registrar un uso:** preguntar si lavar, o mantener la prenda disponible.
- **Motor (avanzado):** pesos de cada factor y coherencia mínima.
- **Copias de seguridad:** descargar respaldo (.zip con fotos), restaurar o exportar el
  inventario a CSV (Excel).
- **Perfil:** cambiar el nombre o el PIN, cerrar sesión o eliminar el perfil.

## Copias de seguridad y cambio de celular
*Ajustes → Descargar respaldo* genera un `.zip` con todo, incluidas las fotos. Para
llevar tu armario a otro dispositivo, abre la app allí y elige *Restaurar un respaldo*,
desde la pantalla de perfiles o desde Ajustes. Se crea un perfil con tus datos. Detalles
en [BACKUP.md](BACKUP.md).

## Preguntas frecuentes
- **No me sale ninguna recomendación.** Necesitas, *disponibles*, al menos una parte
  superior, una inferior (o un vestido) y un calzado adecuados para la temperatura. Revisa
  el aviso "Excluidas: …" que aparece sobre los resultados.
- **El iPhone no acepta la foto (HEIC).** Ve a *Ajustes del iPhone → Cámara → Formatos →
  Más compatible*.
- **¿Mis amigas ven mi armario?** No. Cada persona usa la app en su propio celular y los
  datos nunca salen de él.
