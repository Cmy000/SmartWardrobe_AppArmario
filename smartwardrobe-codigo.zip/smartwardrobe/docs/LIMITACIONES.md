# Limitaciones, riesgos y mejoras futuras

## Desviaciones respecto al prompt maestro (decididas para este PMV)

| Requisito original | En este PMV | Para escalar |
|---|---|---|
| Backend FastAPI + SQLAlchemy + Alembic + SQLite | Sin backend. IndexedDB en el navegador, con migraciones por versión en `db.ts` | Backend FastAPI con el mismo modelo de datos. El dominio TS es la especificación ejecutable que se portaría |
| Motor en Python | Motor en TypeScript (corre en el celular y no necesita servidor) | Portar `src/domain/recommender` a Python 1:1, o entrenar en Python y exportar los pesos (docs/ALGORITMO.md) |
| Cuentas con autenticación segura y sesiones de servidor | Perfiles locales con PIN opcional (PBKDF2). El aislamiento real lo da que cada persona usa **su propio dispositivo** | Autenticación en servidor (Argon2id + sesiones HttpOnly) |
| API REST documentada con OpenAPI | No aplica (no hay API) | — |
| pytest | `node --test` (dominio) + Playwright (E2E) | — |
| Variables de entorno / secretos | No hay secretos: Open-Meteo no usa clave | — |
| Logging centralizado | Errores mostrados al usuario; sin telemetría (nada sale del dispositivo) | Logging en servidor sin datos sensibles |

## Riesgos del uso en varios dispositivos

- **No hay sincronización.** El celular y el computador tienen armarios distintos. El
  respaldo y la restauración sirven para *trasladar* un armario, no para mantener dos
  copias al día (cada restauración crea un perfil nuevo).
- **Pérdida de datos** si se borra el navegador (ver BACKUP.md). Es el riesgo principal
  de este PMV.
- **Dispositivos compartidos:** el PIN evita accesos casuales, pero no cifra. Alguien con
  acceso al dispositivo y conocimientos técnicos puede leer IndexedDB. Para privacidad
  fuerte, usa tu propio dispositivo.
- **Varias pestañas abiertas:** cada pestaña lee de la base al navegar; si editas en dos
  pestañas a la vez, la otra pestaña muestra datos viejos hasta que recargues. No hay
  corrupción, porque cada escritura es transaccional.
- **Red local por HTTP** (`serve.mjs --lan`): cualquiera en la misma red Wi-Fi puede abrir
  la app, pero solo vería **sus propios** datos locales, porque el servidor no guarda nada.
  No expongas ese servidor a internet: para eso usa GitHub o Cloudflare Pages.
- **Open-Meteo:** el servicio gratuito no tiene garantía de disponibilidad (por eso
  existe el modo manual) y es solo para **uso no comercial**. Una versión comercial
  requiere su plan pago o un servidor propio.

## Limitaciones funcionales conocidas

- Importación de inventario solo desde el respaldo ZIP propio; no se importa CSV de
  terceros.
- Una sola foto por prenda.
- La sugerencia de color a partir de la foto es heurística (promedio de la zona central).
  No hay reconocimiento de categoría.
- Sin notificaciones (por ejemplo, "hoy tienes un plan").
- La "temperatura efectiva" del día es 0,6·máx + 0,4·mín. No considera la hora del evento.
- Pesos del motor sin calibración empírica (ver docs/ALGORITMO.md).
- Revisión de tipos de la interfaz React hecha con un *shim* en el entorno de desarrollo.
  En tu equipo, `npm run typecheck` la revisa con `@types/react`.

## Mejoras futuras sugeridas (por prioridad)

1. Sincronización opcional (por ejemplo, un backend FastAPI propio o Supabase con nivel
   gratuito) con autenticación real.
2. Recordatorio periódico de respaldo y exportación automática a Drive.
3. Calibración de pesos con los datos de aceptación y rechazo acumulados.
4. Varias fotos por prenda y recorte automático del fondo.
5. Detección de categoría y color con un modelo de visión en el navegador (ONNX).
6. Hora del evento para usar el pronóstico horario.
7. Notificaciones push de planes del día (requiere HTTPS, ya disponible en Pages).
