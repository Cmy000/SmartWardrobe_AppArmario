# Copias de seguridad y restauración

## Por qué importan
Los datos viven en el IndexedDB del navegador. **Se pierden** si:
- borras los datos de navegación o del sitio;
- desinstalas la app o el navegador, o cambias de celular;
- usas navegación privada;
- el navegador libera espacio. La app pide almacenamiento *persistente*; en *Ajustes* se
  muestra si el navegador lo concedió. Instalar la PWA ayuda a obtenerlo. En Safari/iOS,
  los datos de sitios **no instalados** pueden borrarse tras unos 7 días sin uso.

Recomendación: descarga un respaldo cada semana o después de registrar varias prendas, y
guárdalo en Drive, iCloud o el correo.

## Crear un respaldo
*Ajustes → Copias de seguridad → Descargar respaldo (.zip)*. El archivo
`smartwardrobe-<perfil>-<fecha>.zip` contiene:

```
data.json          # perfil, preferencias, prendas, estados, mantenimiento, outfits,
                   # recomendaciones, calificaciones, vetos, usos y planes
images/<id>.jpg        # foto (máx. 1280 px, sin EXIF)
images/<id>.thumb.jpg  # miniatura
LEEME.txt
```

El formato es `smartwardrobe-backup`, versión 1. La exportación CSV del inventario sirve
para analizar en Excel, **no** para restaurar.

## Restaurar
En la pantalla de perfiles (*Restaurar un respaldo*) o en *Ajustes → Restaurar
respaldo*, elige el `.zip`. El proceso:
1. valida el formato y la versión;
2. crea un **perfil nuevo** con **identificadores nuevos**, de modo que nunca sobrescribe
   ni mezcla datos de otros perfiles;
3. escribe todo en una única transacción: si algo falla, no queda nada a medias.

Para *reemplazar* un perfil existente, restaura el respaldo, comprueba que esté completo
y luego elimina el perfil viejo (*Ajustes → Eliminar perfil y datos*).

## Probado
La prueba E2E n.º 13 exporta un perfil, lo restaura y verifica que tenga las mismas
prendas y el mismo historial de uso.
