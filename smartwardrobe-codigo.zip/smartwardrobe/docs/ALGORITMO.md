# Motor de recomendación (reglas-v1)

Código: `src/domain/recommender/` — `config.ts` (parámetros), `features.ts` (filtro y
características por prenda), `engine.ts` (búsqueda y puntuación), `explain.ts`
(explicaciones), `types.ts` (contratos). Pruebas: `tests/unit/recommender.test.ts`.

## Etapas

1. **Filtro estricto** (`hardFilter`): una prenda que no pasa queda excluida y ninguna
   etapa posterior puede recuperarla. Los motivos se informan en la interfaz.
   - estado ≠ `disponible` (o `usada`, solo si el usuario lo habilita);
   - reservada en un plan del mismo día (si se respeta la reserva);
   - temperatura efectiva fuera de `[tempMin − 2, tempMax + 2]`;
   - formalidad a más de 1 nivel del objetivo **cuando el evento la exige** (reunión
     formal, ceremonia, deporte);
   - color principal en la lista "colores que prefiero no recibir".
2. **Características por prenda** (0..1):
   - `weather` = 1 − 0,5·min(1,5; |T − centro| / semirango); en días de lluvia suma 0,15
     a calzado y abrigos impermeables y resta 0,25 a los que no lo son (sandalias y
     gamuza restan 0,3). Sin clima vale 0,5.
   - `event` = 1 − min(1; |formalidad − objetivo| / 3), más 0,15 si el estilo coincide
     con los estilos típicos del evento.
   - `preference` = 0,5 + 0,3 si el estilo está entre los preferidos + 0,2 si es favorita.
   - `rotation` = 1 − usos / (máximo de usos en su posición + 1).
   - `recency` = min(1; días sin uso / 30); vale 1 si nunca se ha usado.
   - `rating` = promedio de (calificación − 1)/4 de los outfits calificados que la
     incluyen; vale 0,5 sin datos.
3. **Plantillas** (`TEMPLATES`): superior+inferior+calzado, vestido+calzado, y sus
   variantes con abrigo. Con temperatura efectiva < 17 °C o lluvia se exige abrigo, si
   hay alguno disponible; si no, se avisa. Por encima de 24 °C sin lluvia se excluye el
   abrigo.
4. **Poda top-K:** por cada posición solo pasan las K = 8 mejores prendas según el
   promedio ponderado de sus características.
5. **Búsqueda por haz** (*beam search*, B = 40): las posiciones se llenan una a una. Cada
   parcial se puntúa con 0,6 · coherencia media de pares (color y estilo) + 0,4 · puntuación
   unaria de la prenda nueva. Se evalúan O(P·B·K) parciales, en lugar del producto
   cartesiano. Con 280 prendas se evalúan menos del 1 % de las combinaciones, en
   milisegundos (está probado).
6. **Puntuación del outfit:** promedio ponderado de 9 componentes:

   | Componente | Cálculo | Peso inicial |
   |---|---|---|
   | color | `outfitColor`: media de pares en la rueda HSL (neutros 0,9; análogos 0,8; mismo color 0,75; complementarios 0,7; intermedios 0,55; choque 0,4), −0,15 por cada color de acento por encima de 2 y ×0,75 si hay más de un estampado | 1,2 |
   | style | media de `styleCompatibility` entre pares | 1,0 |
   | event | media de `event` | 1,5 |
   | weather | media de `weather` | 1,2 |
   | preference | media de `preference` | 0,8 |
   | rotation | media de `rotation` | 0,5 |
   | recency | media de `recency` | 0,6 |
   | diversity | 1 − máxima similitud de Jaccard con los outfits usados en la ventana | 0,7 |
   | rating | calificación exacta de la combinación o media de `rating` | 0,8 |

7. **Reglas de conjunto:**
   - **coherencia** = (color + estilo)/2 ≥ 0,6. Esta compuerta va **antes** del total:
     la rotación nunca puede rescatar un conjunto incoherente (está probado con pesos de
     rotación ×50);
   - se descarta cualquier conjunto que contenga una combinación bloqueada;
   - se descarta una repetición exacta de un outfit usado dentro de la ventana configurada.
8. **Accesorios opcionales:** se añaden si no bajan la coherencia más de 0,03.
9. **Selección diversa:** se devuelven 6 resultados que no comparten más del 50 % de las
   prendas (Jaccard); solo si faltan alternativas se rellena con las más parecidas.
10. **Explicación:** cada frase lleva la etiqueta del componente del que sale
    (`ExplanationLine.factor`) y se arma con los valores calculados. Una prueba verifica
    que no aparezcan factores inexistentes.

**Pesos y umbrales:** son valores iniciales elegidos por criterio de diseño, **no
calibrados con datos**. Se pueden ajustar desde *Ajustes → Motor (avanzado)* o en
`config.ts`.

## Datos para evaluar y mejorar

Cada recomendación mostrada se guarda en `recommendations`, con sus componentes,
explicación, fuente del clima y estado (`mostrada → aceptada | rechazada`). El uso real
queda en `wears`, con `recommendationId` cuando proviene de una recomendación, y las
calificaciones en `ratings`. El respaldo ZIP (`data.json`) contiene todo esto y se puede
cargar en pandas:

```python
import json, zipfile, pandas as pd
d = json.load(zipfile.ZipFile('respaldo.zip').open('data.json'))
recs = pd.json_normalize(d['recommendations'])  # columnas components.color, components.event, …
recs['aceptada'] = recs.status.eq('aceptada')
# p. ej. regresión logística aceptada ~ componentes → pesos calibrados empíricamente
```

## Cómo agregar un modelo nuevo

Implementa la interfaz `Recommender` (`types.ts`) y cámbiala en `defaultRecommender`
(`engine.ts`). Caminos razonables, en orden de datos necesarios:

1. **Calibrar pesos** con regresión logística sobre aceptada/rechazada (decenas de eventos).
2. **Content-based:** perfil del usuario como promedio de vectores de atributos de las
   prendas aceptadas, con similitud coseno con los candidatos.
3. **Ranking aprendido** (LightGBM/LambdaMART) sobre los 9 componentes + contexto
   (cientos de eventos). Se entrenaría fuera de línea y se exportaría como coeficientes o
   árbol a JSON.
4. **Visión** (embeddings de imagen, detección de categoría/color): requiere un modelo en
   el navegador (ONNX/TensorFlow.js) o un backend. Hoy solo existe una sugerencia
   heurística de color dominante (`images.ts → suggestColor`).
