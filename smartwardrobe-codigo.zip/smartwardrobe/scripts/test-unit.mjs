// Ejecuta las pruebas unitarias del dominio: compila cada tests/unit/*.test.ts con esbuild
// y las corre con el runner nativo de Node (`node --test`). Sin dependencias extra.
import * as esbuild from 'esbuild';
import fs from 'node:fs';
import path from 'node:path';
import { spawnSync } from 'node:child_process';

const root = path.resolve(path.dirname(new URL(import.meta.url).pathname), '..');
const out = path.join(root, '.test-build');
fs.rmSync(out, { recursive: true, force: true });
const entries = fs.readdirSync(path.join(root, 'tests/unit')).filter((f) => f.endsWith('.test.ts')).map((f) => path.join(root, 'tests/unit', f));
await esbuild.build({ entryPoints: entries, bundle: true, platform: 'node', format: 'esm', outdir: out, outExtension: { '.js': '.mjs' }, logLevel: 'warning' });
const files = fs.readdirSync(out).filter((f) => f.endsWith('.mjs')).map((f) => path.join(out, f));
const r = spawnSync(process.execPath, ['--test', ...files], { stdio: 'inherit' });
process.exit(r.status ?? 1);
