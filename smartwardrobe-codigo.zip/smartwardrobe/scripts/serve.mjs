// Servidor estático mínimo para desarrollo y pruebas (sin dependencias).
// Uso: node scripts/serve.mjs [puerto] [--lan]
//  --lan  escucha en 0.0.0.0 para abrirlo desde el celular en la misma red (HTTP: sin instalación PWA).
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';

const root = path.resolve(path.dirname(new URL(import.meta.url).pathname), '..', 'dist');
const port = Number(process.argv.find((a) => /^\d+$/.test(a)) ?? 5173);
const host = process.argv.includes('--lan') ? '0.0.0.0' : '127.0.0.1';
const types = {
  '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8',
  '.json': 'application/json', '.webmanifest': 'application/manifest+json', '.png': 'image/png',
  '.svg': 'image/svg+xml', '.map': 'application/json', '.ico': 'image/x-icon',
};

http
  .createServer((req, res) => {
    const url = new URL(req.url ?? '/', 'http://x');
    // Protección contra rutas maliciosas: normaliza y exige que quede dentro de dist/.
    const rel = path.normalize(decodeURIComponent(url.pathname)).replace(/^(\.\.[/\\])+/, '');
    let file = path.join(root, rel);
    if (!file.startsWith(root)) { res.writeHead(403).end(); return; }
    if (fs.existsSync(file) && fs.statSync(file).isDirectory()) file = path.join(file, 'index.html');
    if (!fs.existsSync(file)) { res.writeHead(404).end('No encontrado'); return; }
    res.writeHead(200, { 'Content-Type': types[path.extname(file)] ?? 'application/octet-stream', 'Cache-Control': 'no-cache' });
    fs.createReadStream(file).pipe(res);
  })
  .listen(port, host, () => {
    console.log(`SmartWardrobe en http://${host === '0.0.0.0' ? 'localhost' : host}:${port}`);
    if (host === '0.0.0.0') {
      for (const ifs of Object.values(os.networkInterfaces()))
        for (const i of ifs ?? []) if (i.family === 'IPv4' && !i.internal) console.log(`  desde el celular: http://${i.address}:${port}`);
    }
  });
