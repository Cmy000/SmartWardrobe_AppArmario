// Build de SmartWardrobe: esbuild (TS/TSX -> JS) + Tailwind v4 (API `compile`).
// Genera `dist/`, una carpeta 100 % estática lista para GitHub Pages o Cloudflare Pages.
// Uso: node scripts/build.mjs [--watch]
import * as esbuild from 'esbuild';
import { compile } from 'tailwindcss';
import fs from 'node:fs';
import path from 'node:path';
import { createRequire } from 'node:module';
import crypto from 'node:crypto';

const root = path.resolve(path.dirname(new URL(import.meta.url).pathname), '..');
const dist = path.join(root, 'dist');
const require = createRequire(import.meta.url);
const watch = process.argv.includes('--watch');

function walk(dir, exts, out = []) {
  for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
    const p = path.join(dir, e.name);
    if (e.isDirectory()) walk(p, exts, out);
    else if (exts.includes(path.extname(e.name))) out.push(p);
  }
  return out;
}

async function buildCss() {
  const tailwindDir = path.dirname(require.resolve('tailwindcss/package.json'));
  const input = fs.readFileSync(path.join(root, 'src/styles.css'), 'utf8');
  const compiler = await compile(input, {
    base: path.join(root, 'src'),
    loadStylesheet: async (id, base) => {
      const p = id === 'tailwindcss' ? path.join(tailwindDir, 'index.css') : path.resolve(base, id);
      return { path: p, base: path.dirname(p), content: fs.readFileSync(p, 'utf8') };
    },
  });
  // Extracción de candidatos: tokens de las fuentes (equivalente simple al escáner de Tailwind).
  const candidates = new Set();
  for (const f of walk(path.join(root, 'src'), ['.tsx', '.ts', '.html'])) {
    const src = fs.readFileSync(f, 'utf8');
    for (const m of src.matchAll(/[A-Za-z0-9_\-:\/\.\[\]#%()!@,'=]+/g)) {
      const t = m[0].replace(/^['"`]+|['"`,]+$/g, '');
      if (t.length > 0 && t.length < 80) candidates.add(t);
    }
  }
  return compiler.build([...candidates]);
}

async function buildOnce() {
  fs.rmSync(dist, { recursive: true, force: true });
  fs.mkdirSync(dist, { recursive: true });
  const result = await esbuild.build({
    entryPoints: [path.join(root, 'src/main.tsx')],
    bundle: true,
    minify: true,
    sourcemap: true,
    format: 'esm',
    target: ['es2022', 'safari16'],
    jsx: 'automatic',
    outfile: path.join(dist, 'app.js'),
    define: { 'process.env.NODE_ENV': '"production"' },
    metafile: true,
    logLevel: 'warning',
  });
  const css = await buildCss();
  fs.writeFileSync(path.join(dist, 'app.css'), css);

  // Copia de /public y versionado de recursos para invalidar la caché del service worker.
  const js = fs.readFileSync(path.join(dist, 'app.js'));
  const hash = crypto.createHash('sha256').update(js).update(css).digest('hex').slice(0, 10);
  fs.cpSync(path.join(root, 'public'), dist, { recursive: true });
  for (const f of ['index.html', 'sw.js']) {
    const p = path.join(dist, f);
    fs.writeFileSync(p, fs.readFileSync(p, 'utf8').replaceAll('__BUILD__', hash));
  }
  fs.writeFileSync(path.join(dist, '.nojekyll'), '');
  const kb = (fs.statSync(path.join(dist, 'app.js')).size / 1024).toFixed(0);
  console.log(`build ${hash}: app.js ${kb} KB, app.css ${(css.length / 1024).toFixed(0)} KB`);
  return result;
}

await buildOnce();
if (watch) {
  console.log('Observando cambios en src/ y public/ …');
  let t;
  for (const d of ['src', 'public']) {
    fs.watch(path.join(root, d), { recursive: true }, () => {
      clearTimeout(t);
      t = setTimeout(() => buildOnce().catch((e) => console.error(e.message)), 150);
    });
  }
}
