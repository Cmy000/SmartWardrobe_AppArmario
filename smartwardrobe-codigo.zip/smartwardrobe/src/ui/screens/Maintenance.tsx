import { useState, type ReactNode } from 'react';
import type { Garment } from '../../domain/types';
import { Empty, GarmentImg, Icon, PageHeader, Segmented } from '../components/ui';
import { useAction, useData, useSession } from '../store';

export function Maintenance() {
  const data = useData();
  const { repo } = useSession();
  const act = useAction();
  const [tab, setTab] = useState<'pendiente' | 'historial'>('pendiente');
  const byId = new Map(data.garments.map((g) => [g.id, g]));
  const laundry = data.garments.filter((g) => g.status === 'lavanderia');
  const repair = data.garments.filter((g) => g.status === 'reparacion');
  const used = data.garments.filter((g) => g.status === 'usada');
  const openRecord = (g: Garment) => data.maintenance.find((m) => m.garmentId === g.id && !m.resolvedAt);
  const resolved = data.maintenance.filter((m) => m.resolvedAt).sort((a, b) => b.resolvedAt!.localeCompare(a.resolvedAt!));

  const Row = ({ g, children }: { g: Garment; children: ReactNode }) => {
    const m = openRecord(g);
    return (
      <li className="flex items-center gap-3 py-3" data-testid="maint-row">
        <a href={`#/prenda/${g.id}`}><GarmentImg imageId={g.imageId} alt="" color={g.colorPrimary} className="h-14 w-14 rounded-2xl" /></a>
        <div className="min-w-0 flex-1">
          <a href={`#/prenda/${g.id}`} className="block truncate text-sm font-medium">{g.name}</a>
          {m && <div className="truncate text-xs text-ink-soft">{m.reason ? `${m.reason} · ` : ''}desde {new Date(m.reportedAt).toLocaleDateString('es-CO')}</div>}
        </div>
        <div className="flex shrink-0 gap-1.5">{children}</div>
      </li>
    );
  };

  return (
    <div className="fade-up">
      <PageHeader eyebrow="Mantenimiento" title="Lavandería y reparaciones" />
      <div className="mb-4"><Segmented label="Vista" value={tab} onChange={setTab} options={[{ value: 'pendiente', label: 'Pendiente' }, { value: 'historial', label: 'Historial' }]} /></div>
      {tab === 'pendiente' ? (
        laundry.length + repair.length + used.length === 0 ? (
          <Empty icon="wash" title="Todo al día" text="No tienes prendas en lavandería, en reparación ni pendientes de decidir." />
        ) : (
          <div className="grid gap-4 lg:grid-cols-3">
            <section className="card p-4">
              <h2 className="flex items-center gap-2 text-xl"><Icon name="wash" className="h-5 w-5 text-clay" />En lavandería <span className="text-sm text-ink-soft">({laundry.length})</span></h2>
              {laundry.length > 1 && <button className="btn-outline btn-sm mt-2" onClick={() => act(async () => { for (const g of laundry) await repo.changeStatus(g.id, 'disponible', { note: 'Lavada' }); }, 'Todas marcadas como limpias')}>Todo limpio</button>}
              <ul className="divide-y divide-sand-100">{laundry.map((g) => <Row key={g.id} g={g}><button className="btn-primary btn-sm" onClick={() => act(() => repo.changeStatus(g.id, 'disponible', { note: 'Lavada' }), `${g.name}: limpia y disponible`)}>Limpia</button></Row>)}</ul>
            </section>
            <section className="card p-4">
              <h2 className="flex items-center gap-2 text-xl"><Icon name="wrench" className="h-5 w-5 text-clay" />En reparación <span className="text-sm text-ink-soft">({repair.length})</span></h2>
              <ul className="divide-y divide-sand-100">{repair.map((g) => <Row key={g.id} g={g}><button className="btn-primary btn-sm" onClick={() => act(() => repo.changeStatus(g.id, 'disponible', { note: 'Reparación completada' }), `${g.name}: reparada`)}>Reparada</button></Row>)}</ul>
            </section>
            <section className="card p-4">
              <h2 className="text-xl">Usadas · por decidir <span className="text-sm text-ink-soft">({used.length})</span></h2>
              <ul className="divide-y divide-sand-100">{used.map((g) => <Row key={g.id} g={g}>
                <button className="btn-outline btn-sm" onClick={() => act(() => repo.changeStatus(g.id, 'disponible'), `${g.name}: disponible`)}>Disponible</button>
                <button className="btn-primary btn-sm" onClick={() => act(() => repo.changeStatus(g.id, 'lavanderia'), `${g.name}: a lavandería`)}>Lavar</button>
              </Row>)}</ul>
            </section>
          </div>
        )
      ) : resolved.length === 0 ? <Empty icon="wrench" title="Sin historial" text="Aquí verás las lavanderías y reparaciones completadas." /> : (
        <ul className="card divide-y divide-sand-100 p-2">
          {resolved.map((m) => {
            const g = byId.get(m.garmentId);
            const days = Math.max(0, Math.round((new Date(m.resolvedAt!).getTime() - new Date(m.reportedAt).getTime()) / 86400000));
            return (
              <li key={m.id} className="flex items-center gap-3 p-2 text-sm">
                <span className="rounded-full bg-sand-100 p-2 text-clay"><Icon name={m.kind === 'reparacion' ? 'wrench' : 'wash'} className="h-4 w-4" /></span>
                <div className="min-w-0 flex-1"><div className="truncate font-medium">{g?.name ?? 'Prenda eliminada'}</div><div className="text-xs text-ink-soft">{m.reason ? `${m.reason} · ` : ''}{new Date(m.reportedAt).toLocaleDateString('es-CO')} → {new Date(m.resolvedAt!).toLocaleDateString('es-CO')} ({days} días){m.notes ? ` · ${m.notes}` : ''}</div></div>
              </li>
            );
          })}
        </ul>
      )}
    </div>
  );
}
