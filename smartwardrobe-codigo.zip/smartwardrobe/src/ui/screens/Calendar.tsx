import { useMemo, useState } from 'react';
import { EVENTS } from '../../domain/catalog';
import { formatLong, formatMonth, toISODate, today } from '../../domain/dates';
import { planConflicts } from '../../domain/planning';
import type { Garment } from '../../domain/types';
import { OutfitCollage, useGarmentMap } from '../components/outfit';
import { Icon, PageHeader, useConfirm } from '../components/ui';
import { useAction, useData, useSession } from '../store';

const WD = ['L', 'M', 'X', 'J', 'V', 'S', 'D'];

export function CalendarScreen() {
  const data = useData();
  const { repo } = useSession();
  const act = useAction();
  const { ask, dialog } = useConfirm();
  const t = today();
  const [cursor, setCursor] = useState(() => t.slice(0, 7));
  const [sel, setSel] = useState(t);
  const [pickOutfit, setPickOutfit] = useState('');
  const byId = useGarmentMap(data.garments);
  const conflicts = planConflicts(data.planned, data.garments, t);

  const days = useMemo(() => {
    const [y, m] = cursor.split('-').map(Number);
    const first = new Date(y, m - 1, 1);
    const offset = (first.getDay() + 6) % 7; // semana inicia en lunes
    const n = new Date(y, m, 0).getDate();
    const cells: Array<string | null> = Array(offset).fill(null);
    for (let d = 1; d <= n; d++) cells.push(toISODate(new Date(y, m - 1, d)));
    while (cells.length % 7) cells.push(null);
    return cells;
  }, [cursor]);
  const shift = (k: number) => { const [y, m] = cursor.split('-').map(Number); setCursor(toISODate(new Date(y, m - 1 + k, 1)).slice(0, 7)); };

  const wearsOn = (d: string) => data.wears.filter((w) => w.date === d);
  const plansOn = (d: string) => data.planned.filter((p) => p.date === d);
  const items = (ids: string[]) => ids.map((id) => byId.get(id)).filter(Boolean) as Garment[];

  return (
    <div className="fade-up">
      <PageHeader eyebrow="Historial y planes" title="Calendario" />
      <div className="grid gap-5 lg:grid-cols-[minmax(0,1fr)_360px]">
        <div className="card p-4">
          <div className="mb-3 flex items-center justify-between">
            <button className="btn-ghost btn-sm !px-2" onClick={() => shift(-1)} aria-label="Mes anterior"><Icon name="back" /></button>
            <h2 className="text-xl capitalize">{formatMonth(cursor)}</h2>
            <button className="btn-ghost btn-sm !px-2" onClick={() => shift(1)} aria-label="Mes siguiente"><Icon name="chevron" /></button>
          </div>
          <div className="grid grid-cols-7 gap-1 text-center text-[11px] font-semibold text-ink-soft">{WD.map((d) => <div key={d} className="py-1">{d}</div>)}</div>
          <div className="grid grid-cols-7 gap-1" role="grid">
            {days.map((d, i) => d === null ? <div key={i} /> : (
              <button key={d} onClick={() => setSel(d)} aria-pressed={sel === d} aria-label={formatLong(d)} data-testid={`day-${d}`}
                className={`flex aspect-square flex-col items-center justify-center rounded-xl text-sm transition ${sel === d ? 'bg-ink text-paper' : d === t ? 'bg-sand-100 font-semibold' : 'hover:bg-sand-50'}`}>
                {Number(d.slice(8))}
                <span className="mt-0.5 flex h-1.5 gap-0.5">
                  {wearsOn(d).length > 0 && <span className={`h-1.5 w-1.5 rounded-full ${sel === d ? 'bg-paper' : 'bg-clay'}`} />}
                  {plansOn(d).length > 0 && <span className={`h-1.5 w-1.5 rounded-full ring-1 ${sel === d ? 'ring-paper' : 'ring-moss'} ${conflicts.some((c) => c.date === d) ? 'bg-amber-500' : ''}`} />}
                </span>
              </button>
            ))}
          </div>
          <div className="mt-3 flex gap-4 text-[11px] text-ink-soft"><span className="flex items-center gap-1"><span className="h-2 w-2 rounded-full bg-clay" />Usado</span><span className="flex items-center gap-1"><span className="h-2 w-2 rounded-full ring-1 ring-moss" />Planificado</span><span className="flex items-center gap-1"><span className="h-2 w-2 rounded-full bg-amber-500" />Conflicto</span></div>
        </div>

        <div className="space-y-3">
          <h2 className="text-2xl capitalize">{formatLong(sel)}</h2>
          {wearsOn(sel).map((w) => (
            <div key={w.id} className="card flex gap-3 p-3" data-testid="wear-entry">
              <OutfitCollage items={items(w.itemIds)} className="h-24 w-20 shrink-0" />
              <div className="min-w-0 flex-1">
                <div className="eyebrow">Usado</div>
                <div className="text-sm">{items(w.itemIds).map((g) => g.name).join(', ')}</div>
                {w.eventType && <div className="text-xs text-ink-soft">{EVENTS[w.eventType]?.label}</div>}
                <button className="mt-1 text-xs text-rose" onClick={async () => { if (await ask('¿Eliminar este registro de uso? Se recalcularán los conteos de uso de las prendas.', true)) act(() => repo.deleteWear(w.id), 'Registro eliminado'); }}>Eliminar registro</button>
              </div>
            </div>
          ))}
          {plansOn(sel).map((p) => {
            const cs = conflicts.filter((c) => c.planId === p.id);
            return (
              <div key={p.id} className="card flex gap-3 p-3" data-testid="plan-entry">
                <OutfitCollage items={items(p.itemIds)} className="h-24 w-20 shrink-0" />
                <div className="min-w-0 flex-1">
                  <div className="eyebrow !text-moss">Planificado</div>
                  <div className="text-sm">{items(p.itemIds).map((g) => g.name).join(', ')}</div>
                  {p.eventType && <div className="text-xs text-ink-soft">{EVENTS[p.eventType]?.label}</div>}
                  {cs.map((c, i) => <div key={i} className="mt-1 text-xs text-amber-800">⚠ {c.message}</div>)}
                  <div className="mt-2 flex flex-wrap gap-2">
                    {sel <= t && <button className="btn-primary btn-sm" disabled={cs.some((c) => c.kind !== 'doble_reserva')} onClick={() => act(async () => { await repo.registerWear({ date: sel, itemIds: p.itemIds, outfitId: p.outfitId, eventType: p.eventType }, data.prefs.afterWear); await repo.deletePlan(p.id); }, 'Uso registrado')}>Lo usé</button>}
                    <button className="btn-ghost btn-sm text-rose" onClick={() => act(() => repo.deletePlan(p.id), 'Plan eliminado')}>Quitar plan</button>
                  </div>
                </div>
              </div>
            );
          })}
          {wearsOn(sel).length === 0 && plansOn(sel).length === 0 && <p className="card p-4 text-sm text-ink-soft">Nada registrado este día.</p>}
          {sel <= t && data.outfits.length > 0 && (
            <form className="card space-y-2 p-3" onSubmit={async (e) => { e.preventDefault(); const o = data.outfits.find((x) => x.id === pickOutfit); if (o && await act(() => repo.registerWear({ date: sel, itemIds: o.itemIds, outfitId: o.id, eventType: o.eventType }, sel === t ? data.prefs.afterWear : 'disponible'), 'Uso registrado')) setPickOutfit(''); }}>
              <label className="field-label" htmlFor="pick">Registrar un outfit guardado este día</label>
              <div className="flex gap-2">
                <select id="pick" className="input" value={pickOutfit} onChange={(e) => setPickOutfit(e.target.value)}><option value="">Elegir…</option>{data.outfits.map((o) => <option key={o.id} value={o.id}>{o.name}</option>)}</select>
                <button className="btn-primary btn-sm" disabled={!pickOutfit}>Registrar</button>
              </div>
            </form>
          )}
          {sel > t && <a href="#/generar" className="btn-outline w-full">Generar un outfit para planificar</a>}
        </div>
      </div>
      {dialog}
    </div>
  );
}
