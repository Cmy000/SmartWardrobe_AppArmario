// Generador de outfits + resultado de recomendaciones.
import { useState } from 'react';
import { EVENTS } from '../../domain/catalog';
import { formatLong, today } from '../../domain/dates';
import { comboKey } from '../../domain/recommender/engine';
import type { RecommendationResult, ScoredOutfit } from '../../domain/recommender/types';
import type { RecommendationRecord, WeatherSnapshot } from '../../domain/types';
import { OutfitCard, useGarmentMap } from '../components/outfit';
import { Chips, Empty, Icon, PageHeader, Stars } from '../components/ui';
import { WeatherPicker } from '../components/weather';
import { recommend, useForecast } from '../hooks';
import { useAction, useData, useSession } from '../store';

const EXCLUSION_LABEL: Record<string, string> = { estado: 'no disponibles', temperatura: 'fuera de rango de temperatura', formalidad: 'sin la formalidad requerida', color_evitado: 'de colores que evitas', reservada: 'reservadas en otro plan' };

export function Generator() {
  const data = useData();
  const { repo } = useSession();
  const act = useAction();
  const t = today();
  const [date, setDate] = useState(t);
  const [eventKey, setEventKey] = useState('diario');
  const [nonce, setNonce] = useState(0);
  const api = useForecast(data.prefs.location, date, nonce);
  const [weather, setWeather] = useState<WeatherSnapshot | null>(null);
  const [acc, setAcc] = useState(true);
  const [respect, setRespect] = useState(true);
  const [result, setResult] = useState<{ r: RecommendationResult; recs: RecommendationRecord[]; date: string; eventKey: string } | null>(null);
  const [busy, setBusy] = useState(false);
  const [done, setDone] = useState<Record<string, string>>({});
  const byId = useGarmentMap(data.garments);

  const generate = async () => {
    setBusy(true);
    const r = recommend(data, { date, eventKey, weather, includeAccessories: acc, respectReservations: respect });
    // Registro de lo mostrado (permite distinguir mostrada / aceptada / rechazada / usada).
    const recs = r.outfits.length
      ? await repo.logRecommendations(r.outfits.map((o) => ({ forDate: date, eventType: eventKey, itemIds: o.itemIds, score: o.score, components: o.components, explanation: o.explanation.map((l) => l.text), weatherSource: weather?.source ?? 'none' })))
      : [];
    setResult({ r, recs, date, eventKey });
    setDone({});
    setBusy(false);
    setTimeout(() => document.getElementById('resultados')?.scrollIntoView({ behavior: 'smooth', block: 'start' }), 50);
  };

  const mark = (key: string, label: string) => setDone((d) => ({ ...d, [key]: label }));
  const isFuture = (result?.date ?? date) > t;
  const ratingOf = (o: ScoredOutfit) => data.ratings.find((x) => x.comboKey === comboKey(o.itemIds))?.rating ?? 0;

  return (
    <div className="fade-up">
      <PageHeader eyebrow="Generador" title="¿Qué me pongo?" />
      <div className="grid gap-4 lg:grid-cols-2">
        <div className="card space-y-4 p-4">
          <div>
            <label className="field-label" htmlFor="gen-date">Fecha</label>
            <input id="gen-date" type="date" className="input" value={date} min={t} onChange={(e) => setDate(e.target.value || t)} />
            <div className="mt-1 text-xs text-ink-soft">{formatLong(date)}</div>
          </div>
          <div>
            <span className="field-label">Evento</span>
            <Chips label="Tipo de evento" value={[eventKey]} onChange={(v) => setEventKey(v[0])} options={Object.entries(EVENTS).map(([k, e]) => ({ value: k, label: e.label }))} />
            <p className="mt-2 text-xs text-ink-soft">Formalidad buscada: {EVENTS[eventKey].formality}/5 {EVENTS[eventKey].strict ? '· obligatoria (filtro estricto)' : '· preferencia'}</p>
          </div>
          <div className="flex flex-col gap-2 text-sm">
            <label className="flex items-center gap-2"><input type="checkbox" checked={acc} onChange={(e) => setAcc(e.target.checked)} className="h-4 w-4 accent-[#8a5a3b]" />Sugerir accesorios</label>
            <label className="flex items-center gap-2"><input type="checkbox" checked={respect} onChange={(e) => setRespect(e.target.checked)} className="h-4 w-4 accent-[#8a5a3b]" />Respetar prendas reservadas en planes de ese día</label>
          </div>
        </div>
        <div className="space-y-4">
          <WeatherPicker date={date} api={api} onChange={setWeather} onRetry={() => setNonce((n) => n + 1)} />
          <button className="btn-primary w-full !py-3.5 text-base" onClick={generate} disabled={busy || api.status === 'loading' && !weather} data-testid="generate">
            <Icon name="sparkles" />{busy ? 'Generando…' : 'Generar recomendaciones'}
          </button>
        </div>
      </div>

      {result && (
        <section id="resultados" className="mt-8 scroll-mt-4" aria-live="polite">
          <div className="mb-3 flex flex-wrap items-end justify-between gap-2">
            <h2 className="text-3xl">Recomendaciones</h2>
            <p className="text-xs text-ink-soft" data-testid="gen-meta">
              {result.r.eligibleCount} prendas elegibles · {result.r.candidatesEvaluated} combinaciones parciales evaluadas
            </p>
          </div>
          {Object.entries(result.r.excluded).some(([, n]) => n > 0) && (
            <p className="mb-3 text-xs text-ink-soft" data-testid="excluded">
              Excluidas: {Object.entries(result.r.excluded).filter(([, n]) => n > 0).map(([k, n]) => `${n} ${EXCLUSION_LABEL[k] ?? k}`).join(' · ')}
            </p>
          )}
          {result.r.warnings.map((w, i) => <p key={i} className="mb-3 rounded-2xl bg-amber-50 p-3 text-sm text-amber-900" role="alert">{w}</p>)}
          {result.r.outfits.length === 0 ? (
            <Empty icon="hanger" title="No encontramos un outfit completo" text="Revisa que tengas disponibles al menos una parte superior, una inferior (o un vestido) y un calzado adecuados para el clima y el evento." action={<a className="btn-outline" href="#/armario">Ir al armario</a>} />
          ) : (
            <div className="space-y-4" data-testid="results">
              {result.r.outfits.map((o, i) => {
                const rec = result.recs[i];
                const key = comboKey(o.itemIds);
                const items = o.itemIds.map((id) => byId.get(id)!).filter(Boolean);
                return (
                  <OutfitCard key={key} testId="result-card" items={items} title={i === 0 ? 'Mejor opción' : `Opción ${i + 1}`} score={o.score} explanation={o.explanation} components={o.components} weights={data.prefs.weights}
                    actions={done[key] ? <span className="rounded-full bg-moss/10 px-3 py-1.5 text-xs font-semibold text-moss">{done[key]}</span> : (
                      <>
                        {isFuture ? (
                          <button className="btn-primary btn-sm" data-testid="plan-btn" onClick={async () => { if (await act(async () => { await repo.plan({ date: result.date, itemIds: o.itemIds, eventType: result.eventKey }); if (rec) await repo.setRecommendationStatus(rec.id, 'aceptada'); }, `Planificado para ${formatLong(result.date)}`)) mark(key, 'Planificado'); }}>
                            <Icon name="calendar" className="h-4 w-4" />Planificar
                          </button>
                        ) : (
                          <button className="btn-primary btn-sm" data-testid="wear-btn" onClick={async () => { if (await act(() => repo.registerWear({ date: result.date, itemIds: o.itemIds, recommendationId: rec?.id, eventType: result.eventKey }, data.prefs.afterWear), 'Uso registrado')) mark(key, 'Registrado como usado'); }}>
                            <Icon name="check" className="h-4 w-4" />Lo usé
                          </button>
                        )}
                        <button className="btn-outline btn-sm" data-testid="save-btn" onClick={async () => { if (await act(async () => { await repo.saveOutfit({ name: `${EVENTS[result.eventKey].label} · ${formatLong(result.date)}`, itemIds: o.itemIds, source: 'recomendado', favorite: false, eventType: result.eventKey }); if (rec) await repo.setRecommendationStatus(rec.id, 'aceptada'); }, 'Outfit guardado')) mark(key, 'Guardado'); }}>
                          <Icon name="bookmark" className="h-4 w-4" />Guardar
                        </button>
                        <button className="btn-ghost btn-sm" onClick={async () => { if (rec && await act(() => repo.setRecommendationStatus(rec.id, 'rechazada'), 'Descartado')) mark(key, 'Descartado'); }}>Descartar</button>
                        <button className="btn-ghost btn-sm text-rose" data-testid="block-btn" onClick={async () => { if (await act(async () => { await repo.block(o.itemIds); if (rec) await repo.setRecommendationStatus(rec.id, 'rechazada'); }, 'No volveremos a sugerir esta combinación')) mark(key, 'Bloqueado'); }}>
                          <Icon name="ban" className="h-4 w-4" />No sugerir más
                        </button>
                      </>
                    )}
                    footer={
                      <div className="flex items-center justify-between border-t border-sand-100 px-4 py-2.5">
                        <span className="text-xs text-ink-soft">Califica esta combinación</span>
                        <Stars value={ratingOf(o)} onChange={(n) => act(() => repo.rate(o.itemIds, n), 'Gracias, tendremos en cuenta tu calificación')} size="h-5 w-5" />
                      </div>
                    }
                  />
                );
              })}
            </div>
          )}
        </section>
      )}
    </div>
  );
}
