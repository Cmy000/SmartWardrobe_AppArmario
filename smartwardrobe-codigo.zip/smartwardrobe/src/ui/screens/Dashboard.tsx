import { useMemo } from 'react';
import { CATEGORIES, EVENTS } from '../../domain/catalog';
import { formatLong, today } from '../../domain/dates';
import { planConflicts } from '../../domain/planning';
import { leastUsed } from '../../domain/stats';
import { OutfitCard, useGarmentMap } from '../components/outfit';
import { GarmentImg, Icon, StatusBadge } from '../components/ui';
import { SourceBadge, WeatherSummary } from '../components/weather';
import { recommend, useForecast } from '../hooks';
import { useAction, useData, useSession } from '../store';

export function Dashboard() {
  const data = useData();
  const { profile, repo } = useSession();
  const act = useAction();
  const t = today();
  const api = useForecast(data.prefs.location, t);
  const byId = useGarmentMap(data.garments);
  const weather = api.status === 'ok' ? api.snapshot : null;
  const top = useMemo(() => (api.status === 'loading' ? null : recommend(data, { date: t, eventKey: 'diario', weather, limit: 1 })), [data, api.status, weather, t]);
  const available = data.garments.filter((g) => g.status === 'disponible');
  const pendingUsed = data.garments.filter((g) => g.status === 'usada');
  const inMaint = data.garments.filter((g) => g.status === 'lavanderia' || g.status === 'reparacion');
  const least = leastUsed(data.garments.filter((g) => g.status === 'disponible'), t, 6);
  const conflicts = planConflicts(data.planned, data.garments, t);
  const todayPlan = data.planned.find((p) => p.date === t);
  const hour = new Date().getHours();
  const hello = hour < 12 ? 'Buenos días' : hour < 19 ? 'Buenas tardes' : 'Buenas noches';

  if (data.garments.length === 0)
    return (
      <div className="fade-up">
        <div className="eyebrow mb-1">{formatLong(t)}</div>
        <h1 className="mb-6 text-4xl">{hello}, {profile.name}</h1>
        <div className="card overflow-hidden p-8 text-center sm:p-12">
          <div className="mx-auto mb-4 w-fit rounded-full bg-sand-100 p-5 text-clay"><Icon name="hanger" className="h-9 w-9" /></div>
          <h2 className="text-3xl">Empieza a digitalizar tu armario</h2>
          <p className="mx-auto mt-2 max-w-md text-sm text-ink-soft">Fotografía tus prendas desde el celular. Con al menos una parte superior, una inferior y un calzado ya puedes recibir recomendaciones.</p>
          <a href="#/prenda/nueva" className="btn-accent mt-6"><Icon name="camera" />Registrar mi primera prenda</a>
        </div>
      </div>
    );

  return (
    <div className="fade-up space-y-6">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <div className="eyebrow mb-1">{formatLong(t)}</div>
          <h1 className="text-4xl">{hello}, {profile.name}</h1>
        </div>
        <a href="#/generar" className="btn-primary"><Icon name="sparkles" />Crear outfit</a>
      </div>

      <div className="grid gap-4 sm:grid-cols-3">
        <div className="card p-4 sm:col-span-1" data-testid="dash-weather">
          <div className="mb-3 flex items-center justify-between"><div className="eyebrow">Clima de hoy</div>{api.status === 'ok' && <SourceBadge source="api" />}</div>
          {api.status === 'loading' && <div className="skeleton h-14 rounded-2xl" />}
          {api.status === 'ok' && <WeatherSummary w={api.snapshot} />}
          {api.status === 'error' && (
            <div className="text-sm text-ink-soft">
              <p>{api.message}</p>
              <a className="mt-2 inline-block font-medium text-clay" href={api.kind === 'sin_ubicacion' ? '#/ajustes' : '#/generar'}>{api.kind === 'sin_ubicacion' ? 'Configurar ubicación' : 'Ingresar el clima manualmente'} →</a>
            </div>
          )}
        </div>
        <a href="#/armario?filtro=disponible" className="card p-4 transition hover:-translate-y-0.5">
          <div className="eyebrow mb-2">Disponibles</div>
          <div className="text-4xl font-semibold tabular-nums">{available.length}<span className="ml-1 text-base font-normal text-ink-soft">/ {data.garments.filter((g) => g.status !== 'retirada').length}</span></div>
          <div className="mt-1 text-xs text-ink-soft">prendas listas para usar</div>
        </a>
        <a href="#/mantenimiento" className="card p-4 transition hover:-translate-y-0.5">
          <div className="eyebrow mb-2">Mantenimiento</div>
          <div className="text-4xl font-semibold tabular-nums">{inMaint.length}</div>
          <div className="mt-1 text-xs text-ink-soft">{data.garments.filter((g) => g.status === 'lavanderia').length} en lavandería · {data.garments.filter((g) => g.status === 'reparacion').length} en reparación</div>
        </a>
      </div>

      {pendingUsed.length > 0 && (
        <section className="card p-4" aria-labelledby="pend">
          <h2 id="pend" className="mb-1 text-xl">¿Qué hacemos con lo que usaste?</h2>
          <p className="mb-3 text-xs text-ink-soft">Estas prendas no se recomendarán hasta que decidas si están listas o necesitan lavado.</p>
          <ul className="divide-y divide-sand-100">
            {pendingUsed.map((g) => (
              <li key={g.id} className="flex items-center gap-3 py-2">
                <GarmentImg imageId={g.imageId} alt="" color={g.colorPrimary} className="h-11 w-11 rounded-xl" />
                <span className="min-w-0 flex-1 truncate text-sm">{g.name}</span>
                <button className="btn-outline btn-sm" onClick={() => act(() => repo.changeStatus(g.id, 'disponible'), `${g.name}: disponible`)}>Disponible</button>
                <button className="btn-primary btn-sm" onClick={() => act(() => repo.changeStatus(g.id, 'lavanderia'), `${g.name}: a lavandería`)}>Lavar</button>
              </li>
            ))}
          </ul>
        </section>
      )}

      {conflicts.length > 0 && (
        <section className="rounded-3xl border border-amber-200 bg-amber-50 p-4" role="alert">
          <h2 className="mb-1 flex items-center gap-2 text-lg text-amber-900"><Icon name="info" />Conflictos en tus planes</h2>
          <ul className="list-disc pl-5 text-sm text-amber-900">
            {conflicts.slice(0, 5).map((c, i) => <li key={i}>{formatLong(c.date)}: {c.message}</li>)}
          </ul>
          <a href="#/calendario" className="mt-2 inline-block text-sm font-medium text-amber-900 underline">Revisar calendario</a>
        </section>
      )}

      <section>
        <div className="mb-3 flex items-end justify-between">
          <h2 className="text-2xl">{todayPlan ? 'Tu plan para hoy' : 'Recomendación del día'}</h2>
          <a href="#/generar" className="text-sm font-medium text-clay">Más opciones →</a>
        </div>
        {todayPlan ? (
          <OutfitCard items={todayPlan.itemIds.map((id) => byId.get(id)!).filter(Boolean)} title={todayPlan.eventType ? EVENTS[todayPlan.eventType]?.label : 'Planificado'} actions={<a className="btn-outline btn-sm" href="#/calendario">Ver en calendario</a>} />
        ) : !top ? <div className="card skeleton h-64" /> : top.outfits[0] ? (
          <OutfitCard testId="dash-top" items={top.outfits[0].itemIds.map((id) => byId.get(id)!)} title="Para tu día a día" score={top.outfits[0].score}
            explanation={top.outfits[0].explanation} components={top.outfits[0].components} weights={data.prefs.weights}
            actions={<a className="btn-primary btn-sm" href="#/generar">Elegir y registrar</a>} />
        ) : (
          <div className="card p-5 text-sm text-ink-soft">{top.warnings[0] ?? 'No hay suficientes prendas disponibles para armar un outfit.'} <a href="#/armario" className="font-medium text-clay">Revisar armario</a></div>
        )}
      </section>

      {least.length > 0 && (
        <section>
          <div className="mb-3 flex items-end justify-between">
            <h2 className="text-2xl">Prendas que esperan su turno</h2>
            <a href="#/armario?filtro=poco_usadas" className="text-sm font-medium text-clay">Ver todas →</a>
          </div>
          <div className="-mx-4 flex gap-3 overflow-x-auto px-4 pb-2 sm:mx-0 sm:grid sm:grid-cols-6 sm:px-0">
            {least.map((g) => (
              <a key={g.id} href={`#/prenda/${g.id}`} className="w-32 shrink-0 sm:w-auto">
                <GarmentImg imageId={g.imageId} alt={g.name} color={g.colorPrimary} className="aspect-[4/5] w-full rounded-2xl" />
                <div className="mt-1.5 truncate text-xs font-medium">{g.name}</div>
                <div className="text-[11px] text-ink-soft">{g.wearCount === 0 ? 'Sin usos registrados' : `${g.wearCount} uso(s)`} · {CATEGORIES[g.category].label}</div>
              </a>
            ))}
          </div>
        </section>
      )}

      {inMaint.length > 0 && (
        <section className="card p-4">
          <div className="mb-2 flex items-center justify-between"><h2 className="text-xl">Pendientes de mantenimiento</h2><a href="#/mantenimiento" className="text-sm font-medium text-clay">Gestionar →</a></div>
          <div className="flex flex-wrap gap-2">{inMaint.map((g) => <a key={g.id} href={`#/prenda/${g.id}`} className="chip">{g.name}<StatusBadge status={g.status} /></a>)}</div>
        </section>
      )}
    </div>
  );
}
