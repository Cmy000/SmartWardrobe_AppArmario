import { useState } from 'react';
import { CATEGORIES, COLORS, FORMALITY_LABEL, PATTERNS, SEASONS, STATUS_LABEL, STYLES } from '../../domain/catalog';
import { daysBetween, formatLong, today } from '../../domain/dates';
import { TRANSITIONS } from '../../domain/status';
import type { GarmentStatus } from '../../domain/types';
import { navigate } from '../router';
import { ColorDot, Field, GarmentImg, Icon, Modal, StatusBadge, useConfirm } from '../components/ui';
import { useAction, useData, useSession } from '../store';

const ACTION_LABEL: Record<GarmentStatus, string> = {
  disponible: 'Marcar disponible', usada: 'Marcar como usada', lavanderia: 'Enviar a lavandería', reparacion: 'Requiere reparación', guardada: 'Guardar temporalmente', retirada: 'Retirar del armario',
};

export function GarmentDetail({ id }: { id: string }) {
  const data = useData();
  const { repo } = useSession();
  const act = useAction();
  const { ask, dialog } = useConfirm();
  const g = data.garments.find((x) => x.id === id);
  const [target, setTarget] = useState<GarmentStatus | null>(null);
  const [reason, setReason] = useState('');
  const [note, setNote] = useState('');

  // Si el id no pertenece al perfil activo, el repositorio no lo devuelve: no hay forma de verlo.
  if (!g) return <div className="py-20 text-center" data-testid="not-found"><h1 className="text-3xl">Prenda no encontrada</h1><p className="mt-2 text-sm text-ink-soft">No existe o no pertenece a tu perfil.</p><a href="#/armario" className="btn-outline mt-6">Volver al armario</a></div>;

  const history = data.history.filter((h) => h.garmentId === id).sort((a, b) => b.at.localeCompare(a.at));
  const maint = data.maintenance.filter((m) => m.garmentId === id).sort((a, b) => b.reportedAt.localeCompare(a.reportedAt));
  const wears = data.wears.filter((w) => w.itemIds.includes(id)).sort((a, b) => b.date.localeCompare(a.date));
  const days = g.lastWornAt ? daysBetween(g.lastWornAt, today()) : null;
  const t = today();

  const doTransition = async () => {
    if (!target) return;
    const ok = await act(() => repo.changeStatus(g.id, target, { reason, note }), `Estado: ${STATUS_LABEL[target]}`);
    if (ok) { setTarget(null); setReason(''); setNote(''); }
  };
  const remove = async () => {
    if (await ask(`¿Eliminar "${g.name}" y su foto? Esta acción no se puede deshacer. Si solo ya no la usas, puedes "Retirarla" para conservar el historial.`, true))
      if (await act(() => repo.deleteGarment(g.id), 'Prenda eliminada')) navigate('/armario', true);
  };
  const attrs: Array<[string, string | undefined]> = [
    ['Categoría', CATEGORIES[g.category].label + (g.subcategory ? ` · ${g.subcategory}` : '')],
    ['Estilo', STYLES[g.style]], ['Formalidad', `${g.formality} · ${FORMALITY_LABEL[g.formality]}`], ['Estampado', PATTERNS[g.pattern]],
    ['Temperatura', `${g.tempMin}° a ${g.tempMax}°${g.waterproof ? ' · impermeable' : ''}`], ['Temporada', g.seasons.map((s) => SEASONS[s]).join(', ')],
    ['Material', g.material], ['Marca', g.brand], ['Adquirida', g.acquiredAt], ['Costo', g.cost !== undefined ? `$${g.cost.toLocaleString('es-CO')}` : undefined],
    ['Costo por uso', g.cost !== undefined && g.wearCount > 0 ? `$${Math.round(g.cost / g.wearCount).toLocaleString('es-CO')}` : g.cost !== undefined ? 'Sin usos registrados' : undefined],
  ];

  return (
    <div className="fade-up">
      <a href="#/armario" className="-ml-1 mb-3 inline-flex items-center gap-1 text-sm text-ink-soft hover:text-ink"><Icon name="back" className="h-4 w-4" />Armario</a>
      <div className="grid gap-6 lg:grid-cols-[minmax(0,420px)_1fr]">
        <div className="relative">
          <GarmentImg imageId={g.imageId} alt={g.name} color={g.colorPrimary} full className="aspect-[4/5] w-full rounded-3xl" />
          <button onClick={() => act(() => repo.saveGarment({ ...g, favorite: !g.favorite }))} className="absolute right-3 top-3 rounded-full bg-white/90 p-2.5 text-rose shadow" aria-pressed={g.favorite} aria-label={g.favorite ? 'Quitar de favoritas' : 'Marcar como favorita'}>
            <Icon name="heart" filled={g.favorite} />
          </button>
        </div>
        <div className="space-y-5">
          <div>
            <div className="mb-2 flex items-center gap-2"><StatusBadge status={g.status} />{g.favorite && <span className="text-xs text-rose">Favorita</span>}</div>
            <h1 className="text-4xl" data-testid="garment-name">{g.name}</h1>
            <div className="mt-2 flex flex-wrap items-center gap-2 text-sm text-ink-soft">
              <ColorDot color={g.colorPrimary} /> {COLORS[g.colorPrimary]?.label}
              {g.colorsSecondary.map((c) => <span key={c} className="inline-flex items-center gap-1"><ColorDot color={c} className="h-3 w-3" />{COLORS[c]?.label}</span>)}
            </div>
          </div>
          <div className="grid grid-cols-3 gap-3">
            <div className="card p-3"><div className="text-2xl font-semibold tabular-nums">{g.wearCount}</div><div className="text-xs text-ink-soft">usos</div></div>
            <div className="card col-span-2 p-3"><div className="text-sm font-medium">{g.lastWornAt ? formatLong(g.lastWornAt) : 'Sin usos registrados'}</div><div className="text-xs text-ink-soft">{days !== null ? `último uso · hace ${days} días` : 'último uso'}</div></div>
          </div>

          <section className="card p-4">
            <div className="eyebrow mb-1">Estado actual</div>
            <div className="mb-3 text-lg">{STATUS_LABEL[g.status]}</div>
            <div className="flex flex-wrap gap-2" data-testid="status-actions">
              {TRANSITIONS[g.status].map((s) => (
                <button key={s} className={s === 'disponible' ? 'btn-primary btn-sm' : 'btn-outline btn-sm'} onClick={() => setTarget(s)} data-testid={`to-${s}`}>{ACTION_LABEL[s]}</button>
              ))}
            </div>
          </section>

          <section className="card divide-y divide-sand-100 p-1">
            {attrs.filter(([, v]) => v).map(([k, v]) => (
              <div key={k} className="flex justify-between gap-4 px-3 py-2.5 text-sm"><span className="text-ink-soft">{k}</span><span className="text-right font-medium">{v}</span></div>
            ))}
            {g.tags.length > 0 && <div className="flex flex-wrap gap-1.5 px-3 py-2.5">{g.tags.map((t) => <span key={t} className="chip">{t}</span>)}</div>}
            {g.notes && <p className="whitespace-pre-wrap px-3 py-2.5 text-sm text-ink-soft">{g.notes}</p>}
          </section>

          {maint.length > 0 && (
            <section>
              <h2 className="mb-2 text-xl">Mantenimiento</h2>
              <ul className="space-y-2">
                {maint.map((m) => (
                  <li key={m.id} className="card p-3 text-sm">
                    <div className="flex justify-between"><span className="font-medium">{m.kind === 'reparacion' ? 'Reparación' : 'Lavandería'}</span><span className={m.resolvedAt ? 'text-moss' : 'text-amber-700'}>{m.resolvedAt ? 'Resuelto' : 'Pendiente'}</span></div>
                    {m.reason && <div className="text-ink-soft">Motivo: {m.reason}</div>}
                    <div className="text-xs text-ink-soft">Reportado {new Date(m.reportedAt).toLocaleDateString('es-CO')}{m.resolvedAt && ` · solucionado ${new Date(m.resolvedAt).toLocaleDateString('es-CO')}`}</div>
                    {m.notes && <div className="mt-1 text-xs">{m.notes}</div>}
                  </li>
                ))}
              </ul>
            </section>
          )}

          <section>
            <h2 className="mb-2 text-xl">Historial</h2>
            <ol className="relative space-y-2 border-l border-sand-200 pl-4 text-sm">
              {[...history.map((h) => ({ at: h.at, text: `${h.from ? `${STATUS_LABEL[h.from]} → ` : ''}${STATUS_LABEL[h.to]}`, note: h.note })),
                ...wears.map((w) => ({ at: w.date + 'T12:00:00', text: `Usada${w.date > t ? ' (futuro)' : ''}`, note: formatLong(w.date) }))]
                .sort((a, b) => b.at.localeCompare(a.at)).slice(0, 25).map((h, i) => (
                  <li key={i}><span className="absolute -left-[5px] mt-1.5 h-2.5 w-2.5 rounded-full bg-sand-300" /><div>{h.text}</div><div className="text-xs text-ink-soft">{new Date(h.at).toLocaleString('es-CO', { dateStyle: 'medium', timeStyle: h.at.endsWith('T12:00:00') ? undefined : 'short' })}{h.note ? ` · ${h.note}` : ''}</div></li>
                ))}
            </ol>
          </section>

          <div className="flex flex-wrap gap-2 border-t border-sand-100 pt-4">
            <a href={`#/prenda/${g.id}/editar`} className="btn-outline" data-testid="edit-garment"><Icon name="edit" className="h-4 w-4" />Editar</a>
            <button className="btn-ghost text-rose" onClick={remove}><Icon name="trash" className="h-4 w-4" />Eliminar</button>
          </div>
        </div>
      </div>

      <Modal open={!!target} onClose={() => setTarget(null)} title={target ? ACTION_LABEL[target] : ''}>
        <form className="space-y-4" onSubmit={(e) => { e.preventDefault(); doTransition(); }}>
          {target === 'reparacion' && <Field label="Motivo de la reparación *"><input className="input" value={reason} onChange={(e) => setReason(e.target.value)} required placeholder="Ej. cremallera dañada" data-testid="repair-reason" /></Field>}
          <Field label="Notas (opcional)"><textarea className="input min-h-16" value={note} onChange={(e) => setNote(e.target.value)} placeholder={target === 'disponible' && (g.status === 'reparacion' || g.status === 'lavanderia') ? 'Ej. arreglada en la sastrería' : ''} /></Field>
          {(target === 'lavanderia' || target === 'reparacion' || target === 'guardada' || target === 'retirada') && <p className="text-xs text-ink-soft">Mientras esté en este estado no aparecerá en ninguna recomendación.</p>}
          <div className="flex justify-end gap-2"><button type="button" className="btn-ghost" onClick={() => setTarget(null)}>Cancelar</button><button className="btn-primary" disabled={target === 'reparacion' && !reason.trim()} data-testid="confirm-status">Confirmar</button></div>
        </form>
      </Modal>
      {dialog}
    </div>
  );
}
