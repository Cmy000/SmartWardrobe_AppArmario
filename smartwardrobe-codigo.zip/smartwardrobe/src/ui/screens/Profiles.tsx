// Pantalla de inicio: perfiles locales de este dispositivo (equivalente a "iniciar sesión").
import { useEffect, useState } from 'react';
import type { Profile } from '../../domain/types';
import { importBackup } from '../../data/backup';
import { createDemoProfile } from '../../data/demo';
import { createProfile, listProfiles, verifyPin } from '../../data/repo';
import { Field, Icon, Modal, Spinner } from '../components/ui';
import { useToast } from '../store';

export function ProfilesScreen({ onEnter }: { onEnter: (p: Profile) => void }) {
  const [profiles, setProfiles] = useState<Profile[] | null>(null);
  const [creating, setCreating] = useState(false);
  const [name, setName] = useState('');
  const [pin, setPin] = useState('');
  const [pinFor, setPinFor] = useState<Profile | null>(null);
  const [pinTry, setPinTry] = useState('');
  const [busy, setBusy] = useState(false);
  const toast = useToast();
  const load = () => listProfiles().then(setProfiles).catch(() => setProfiles([]));
  useEffect(() => { load(); }, []);

  const create = async () => {
    setBusy(true);
    try { onEnter(await createProfile(name, { pin: pin || undefined })); }
    catch (e) { toast((e as Error).message, 'error'); }
    finally { setBusy(false); }
  };
  const enter = async (p: Profile) => {
    if (p.pinHash) { setPinFor(p); setPinTry(''); return; }
    onEnter(p);
  };
  const checkPin = async () => {
    if (!pinFor) return;
    if (await verifyPin(pinFor, pinTry)) onEnter(pinFor);
    else toast('PIN incorrecto.', 'error');
  };
  const demo = async () => {
    setBusy(true);
    try { await createDemoProfile(); await load(); toast('Perfil de demostración creado.'); }
    catch (e) { toast((e as Error).message, 'error'); }
    finally { setBusy(false); }
  };
  const restore = async (f: File | undefined) => {
    if (!f) return;
    setBusy(true);
    try { const p = await importBackup(f); await load(); toast(`Respaldo restaurado como "${p.name}".`); }
    catch (e) { toast((e as Error).message, 'error'); }
    finally { setBusy(false); }
  };

  return (
    <div className="mx-auto flex min-h-dvh max-w-lg flex-col px-5 py-10">
      <div className="mb-10 text-center">
        <div className="eyebrow mb-3">Asistente personal de estilo</div>
        <h1 className="text-5xl">SmartWardrobe</h1>
        <p className="mx-auto mt-3 max-w-xs text-sm text-ink-soft">Tu armario digital. Los datos se guardan solo en este dispositivo.</p>
      </div>
      {profiles === null ? <Spinner /> : (
        <div className="space-y-3">
          {profiles.length > 0 && <div className="field-label">¿Quién eres?</div>}
          {profiles.map((p) => (
            <button key={p.id} onClick={() => enter(p)} className="card flex w-full items-center gap-4 p-4 text-left transition hover:-translate-y-0.5" data-testid={`profile-${p.name}`}>
              <span className="flex h-12 w-12 items-center justify-center rounded-full bg-sand-100 font-display text-xl text-clay">{p.name.charAt(0).toUpperCase()}</span>
              <span className="flex-1">
                <span className="block font-medium">{p.name}</span>
                <span className="text-xs text-ink-soft">{p.isDemo ? 'Datos de demostración' : p.pinHash ? 'Protegido con PIN' : 'Perfil personal'}</span>
              </span>
              <Icon name="chevron" className="h-5 w-5 text-ink-soft" />
            </button>
          ))}
          {creating ? (
            <form className="card space-y-4 p-5" onSubmit={(e) => { e.preventDefault(); create(); }}>
              <Field label="Tu nombre"><input className="input" value={name} onChange={(e) => setName(e.target.value)} required maxLength={40} autoFocus autoComplete="nickname" /></Field>
              <Field label="PIN (opcional)" hint="Útil si compartes el dispositivo. Es una barrera de conveniencia, no un cifrado.">
                <input className="input" value={pin} onChange={(e) => setPin(e.target.value.replace(/\D/g, ''))} inputMode="numeric" maxLength={8} type="password" autoComplete="new-password" placeholder="4 a 8 dígitos" />
              </Field>
              <div className="flex justify-end gap-2">
                <button type="button" className="btn-ghost" onClick={() => setCreating(false)}>Cancelar</button>
                <button className="btn-primary" disabled={busy || !name.trim()}>Crear perfil</button>
              </div>
            </form>
          ) : (
            <button className="btn-primary w-full !py-3.5" onClick={() => setCreating(true)}><Icon name="plus" />Crear perfil</button>
          )}
          <div className="flex flex-wrap justify-center gap-x-5 gap-y-2 pt-4 text-sm">
            {!profiles.some((p) => p.isDemo) && <button className="text-ink-soft underline-offset-4 hover:underline" disabled={busy} onClick={demo}>Probar con datos de demostración</button>}
            <label className="cursor-pointer text-ink-soft underline-offset-4 hover:underline">
              Restaurar un respaldo
              <input type="file" accept=".zip,application/zip" className="sr-only" onChange={(e) => restore(e.target.files?.[0])} />
            </label>
          </div>
          {busy && <Spinner label="Procesando…" />}
        </div>
      )}
      <Modal open={!!pinFor} onClose={() => setPinFor(null)} title={`Hola, ${pinFor?.name ?? ''}`}>
        <form onSubmit={(e) => { e.preventDefault(); checkPin(); }} className="space-y-4">
          <Field label="PIN"><input className="input text-center tracking-[.5em]" value={pinTry} onChange={(e) => setPinTry(e.target.value.replace(/\D/g, ''))} inputMode="numeric" type="password" maxLength={8} autoComplete="current-password" /></Field>
          <button className="btn-primary w-full">Entrar</button>
        </form>
      </Modal>
    </div>
  );
}
