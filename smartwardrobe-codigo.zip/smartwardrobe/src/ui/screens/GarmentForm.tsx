import { useEffect, useRef, useState } from 'react';
import { CATEGORIES, COLORS, FORMALITY_LABEL, PATTERNS, SEASONS, SLOT_LABEL, STYLES } from '../../domain/catalog';
import type { Category, Garment, GarmentImage, Pattern, Season, Style } from '../../domain/types';
import { processImage, suggestColor } from '../../data/images';
import { navigate } from '../router';
import { Chips, ColorDot, Field, GarmentImg, Icon, PageHeader } from '../components/ui';
import { useAction, useData, useSession, useToast } from '../store';

type Draft = Omit<Garment, 'id' | 'profileId' | 'createdAt' | 'updatedAt' | 'wearCount' | 'lastWornAt' | 'status'>;

const blank = (): Draft => ({
  name: '', category: 'camiseta', subcategory: '', colorPrimary: 'negro', colorsSecondary: [], material: '', pattern: 'liso', style: 'casual',
  formality: CATEGORIES.camiseta.defaultFormality, seasons: ['todo_el_ano'], tempMin: CATEGORIES.camiseta.defaultTemp[0], tempMax: CATEGORIES.camiseta.defaultTemp[1],
  waterproof: false, brand: '', acquiredAt: '', cost: undefined, notes: '', favorite: false, tags: [],
});

export function GarmentForm({ id }: { id?: string }) {
  const { garments } = useData();
  const { repo } = useSession();
  const act = useAction();
  const toast = useToast();
  const existing = id ? garments.find((g) => g.id === id) : undefined;
  const [d, setD] = useState<Draft>(() => (existing ? { ...existing } : blank()));
  const [img, setImg] = useState<Omit<GarmentImage, 'profileId'> | null>(null);
  const [preview, setPreview] = useState<string | null>(null);
  const [processing, setProcessing] = useState(false);
  const [saving, setSaving] = useState(false);
  const [tagText, setTagText] = useState('');
  const touched = useRef({ temp: !!existing, formality: !!existing });
  const set = <K extends keyof Draft>(k: K, v: Draft[K]) => setD((x) => ({ ...x, [k]: v }));

  useEffect(() => () => { if (preview) URL.revokeObjectURL(preview); }, [preview]);

  if (id && !existing)
    return <div className="py-20 text-center"><h1 className="text-3xl">Prenda no encontrada</h1><a href="#/armario" className="btn-outline mt-6">Volver al armario</a></div>;

  const onCategory = (c: Category) => {
    const info = CATEGORIES[c];
    setD((x) => ({
      ...x, category: c,
      ...(touched.current.temp ? {} : { tempMin: info.defaultTemp[0], tempMax: info.defaultTemp[1] }),
      ...(touched.current.formality ? {} : { formality: info.defaultFormality }),
    }));
  };

  const onPhoto = async (f: File | undefined) => {
    if (!f) return;
    setProcessing(true);
    try {
      const p = await processImage(f);
      setImg(p);
      setPreview(URL.createObjectURL(p.thumb));
      if (!existing) {
        const c = await suggestColor(p.thumb, COLORS);
        if (c) { set('colorPrimary', c); toast(`Color sugerido: ${COLORS[c].label} (puedes cambiarlo)`); }
      }
    } catch (e) {
      toast((e as Error).message, 'error');
    } finally {
      setProcessing(false);
    }
  };

  const save = async () => {
    setSaving(true);
    let savedId = '';
    const ok = await act(async () => {
      const clean: Draft = {
        ...d, name: d.name.trim(), subcategory: d.subcategory?.trim() || undefined, material: d.material?.trim() || undefined, brand: d.brand?.trim() || undefined,
        acquiredAt: d.acquiredAt || undefined, notes: d.notes?.trim() || undefined, cost: d.cost === undefined || Number.isNaN(d.cost) ? undefined : d.cost,
        seasons: d.seasons.length ? d.seasons : ['todo_el_ano'], colorsSecondary: d.colorsSecondary.filter((c) => c !== d.colorPrimary),
      };
      const g = await repo.saveGarment({ ...clean, id: existing?.id }, img ?? undefined);
      savedId = g.id;
    }, existing ? 'Cambios guardados' : 'Prenda agregada');
    setSaving(false);
    if (ok) navigate(`/prenda/${savedId}`, true);
  };

  const addTag = () => {
    const t = tagText.trim().toLowerCase();
    if (t && !d.tags.includes(t) && d.tags.length < 15) set('tags', [...d.tags, t]);
    setTagText('');
  };
  const slotGroups = Object.entries(SLOT_LABEL).map(([slot, label]) => ({ label, cats: (Object.keys(CATEGORIES) as Category[]).filter((c) => CATEGORIES[c].slot === slot) }));

  return (
    <div className="fade-up">
      <PageHeader back={existing ? `/prenda/${existing.id}` : '/armario'} title={existing ? 'Editar prenda' : 'Nueva prenda'} />
      <form className="grid gap-5 lg:grid-cols-[320px_1fr]" onSubmit={(e) => { e.preventDefault(); save(); }} noValidate>
        <div className="space-y-3">
          <label className="card group relative block aspect-[4/5] cursor-pointer overflow-hidden" data-testid="photo-drop">
            {preview ? <img src={preview} alt="Vista previa" className="h-full w-full object-cover" />
              : existing?.imageId ? <GarmentImg imageId={existing.imageId} alt={existing.name} className="h-full w-full" full />
              : (
                <div className="flex h-full flex-col items-center justify-center gap-2 text-ink-soft">
                  <div className="rounded-full bg-sand-100 p-4 text-clay"><Icon name="camera" className="h-8 w-8" /></div>
                  <span className="text-sm font-medium">Tomar o elegir foto</span>
                  <span className="text-xs">JPG, PNG o WebP · máx. 15 MB</span>
                </div>
              )}
            {processing && <div className="absolute inset-0 flex items-center justify-center bg-white/70 text-sm">Procesando foto…</div>}
            <input type="file" accept="image/*" capture="environment" className="sr-only" onChange={(e) => onPhoto(e.target.files?.[0])} aria-label="Foto de la prenda" data-testid="photo-input" />
          </label>
          <p className="text-xs text-ink-soft">La foto se reduce y se re-codifica en tu dispositivo: se eliminan los metadatos (incluida la ubicación GPS).</p>
        </div>

        <div className="card space-y-5 p-5">
          <Field label="Nombre *"><input className="input" required maxLength={80} value={d.name} onChange={(e) => set('name', e.target.value)} placeholder="Ej. Camisa de lino blanca" data-testid="name" /></Field>
          <Field label="Categoría *">
            <select className="input" value={d.category} onChange={(e) => onCategory(e.target.value as Category)} data-testid="category">
              {slotGroups.map((sg) => <optgroup key={sg.label} label={sg.label}>{sg.cats.map((c) => <option key={c} value={c}>{CATEGORIES[c].label}</option>)}</optgroup>)}
            </select>
          </Field>
          <div>
            <span className="field-label">Color principal *</span>
            <div className="flex flex-wrap gap-2" role="radiogroup" aria-label="Color principal">
              {Object.entries(COLORS).map(([k, c]) => (
                <button type="button" key={k} role="radio" aria-checked={d.colorPrimary === k} aria-label={c.label} title={c.label} onClick={() => set('colorPrimary', k)}
                  className={`rounded-full p-0.5 transition ${d.colorPrimary === k ? 'ring-2 ring-ink ring-offset-2' : ''}`}>
                  <ColorDot color={k} className="h-7 w-7" />
                </button>
              ))}
            </div>
            <div className="mt-1 text-xs text-ink-soft">{COLORS[d.colorPrimary]?.label}</div>
          </div>
          <div>
            <span className="field-label">Colores secundarios</span>
            <Chips label="Colores secundarios" multiple value={d.colorsSecondary} onChange={(v) => set('colorsSecondary', v.slice(0, 4))} options={Object.entries(COLORS).filter(([k]) => k !== d.colorPrimary).map(([k, c]) => ({ value: k, label: c.label, dot: k }))} />
          </div>
          <div className="grid gap-4 sm:grid-cols-2">
            <Field label="Estilo"><select className="input" value={d.style} onChange={(e) => set('style', e.target.value as Style)}>{Object.entries(STYLES).map(([k, v]) => <option key={k} value={k}>{v}</option>)}</select></Field>
            <Field label="Estampado"><select className="input" value={d.pattern} onChange={(e) => set('pattern', e.target.value as Pattern)}>{Object.entries(PATTERNS).map(([k, v]) => <option key={k} value={k}>{v}</option>)}</select></Field>
          </div>
          <Field label={`Formalidad: ${d.formality} · ${FORMALITY_LABEL[d.formality]}`}>
            <input type="range" min={1} max={5} step={1} value={d.formality} onChange={(e) => { touched.current.formality = true; set('formality', Number(e.target.value)); }} className="w-full accent-[#8a5a3b]" />
          </Field>
          <div>
            <span className="field-label">Rango de temperatura recomendado (°C)</span>
            <div className="flex items-center gap-3">
              <input type="number" className="input" value={d.tempMin} onChange={(e) => { touched.current.temp = true; set('tempMin', Number(e.target.value)); }} aria-label="Temperatura mínima" />
              <span className="text-ink-soft">a</span>
              <input type="number" className="input" value={d.tempMax} onChange={(e) => { touched.current.temp = true; set('tempMax', Number(e.target.value)); }} aria-label="Temperatura máxima" />
            </div>
            <label className="mt-2 flex items-center gap-2 text-sm"><input type="checkbox" checked={d.waterproof} onChange={(e) => set('waterproof', e.target.checked)} className="h-4 w-4 accent-[#8a5a3b]" />Apta para lluvia / impermeable</label>
          </div>
          <div>
            <span className="field-label">Temporada</span>
            <Chips label="Temporada" multiple value={d.seasons} onChange={(v) => set('seasons', v as Season[])} options={Object.entries(SEASONS).map(([k, v]) => ({ value: k as Season, label: v }))} />
          </div>
          <details className="group rounded-2xl bg-sand-50 p-4">
            <summary className="cursor-pointer text-sm font-medium">Más detalles (opcional)</summary>
            <div className="mt-4 grid gap-4 sm:grid-cols-2">
              <Field label="Subcategoría"><input className="input" value={d.subcategory ?? ''} onChange={(e) => set('subcategory', e.target.value)} placeholder="Ej. manga larga" /></Field>
              <Field label="Material"><input className="input" value={d.material ?? ''} onChange={(e) => set('material', e.target.value)} placeholder="Ej. algodón" /></Field>
              <Field label="Marca"><input className="input" value={d.brand ?? ''} onChange={(e) => set('brand', e.target.value)} /></Field>
              <Field label="Fecha de adquisición"><input type="date" className="input" value={d.acquiredAt ?? ''} onChange={(e) => set('acquiredAt', e.target.value)} /></Field>
              <Field label="Costo" hint="Para calcular el costo por uso."><input type="number" min={0} inputMode="decimal" className="input" value={d.cost ?? ''} onChange={(e) => set('cost', e.target.value === '' ? undefined : Number(e.target.value))} /></Field>
              <div>
                <span className="field-label">Etiquetas</span>
                <div className="flex gap-2"><input className="input" value={tagText} onChange={(e) => setTagText(e.target.value)} onKeyDown={(e) => { if (e.key === 'Enter') { e.preventDefault(); addTag(); } }} placeholder="Ej. oficina" aria-label="Nueva etiqueta" /><button type="button" className="btn-outline btn-sm" onClick={addTag}>Añadir</button></div>
                <div className="mt-2 flex flex-wrap gap-1.5">{d.tags.map((t) => <button type="button" key={t} className="chip" onClick={() => set('tags', d.tags.filter((x) => x !== t))} aria-label={`Quitar etiqueta ${t}`}>{t}<Icon name="x" className="h-3 w-3" /></button>)}</div>
              </div>
              <div className="sm:col-span-2"><Field label="Observaciones"><textarea className="input min-h-20" maxLength={1000} value={d.notes ?? ''} onChange={(e) => set('notes', e.target.value)} /></Field></div>
            </div>
          </details>
          <label className="flex items-center gap-2 text-sm"><input type="checkbox" checked={d.favorite} onChange={(e) => set('favorite', e.target.checked)} className="h-4 w-4 accent-[#8a5a3b]" />Marcar como favorita</label>
          <div className="flex justify-end gap-2 border-t border-sand-100 pt-4">
            <a href={existing ? `#/prenda/${existing.id}` : '#/armario'} className="btn-ghost">Cancelar</a>
            <button className="btn-primary" disabled={saving || processing || !d.name.trim()} data-testid="save-garment">{saving ? 'Guardando…' : 'Guardar prenda'}</button>
          </div>
        </div>
      </form>
    </div>
  );
}
