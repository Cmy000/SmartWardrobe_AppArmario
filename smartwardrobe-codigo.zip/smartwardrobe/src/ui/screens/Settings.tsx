import { useEffect, useState } from 'react';
import { COLORS, STYLES } from '../../domain/catalog';
import { DEFAULT_WEIGHTS, ENGINE, WEIGHT_LABELS } from '../../domain/recommender/config';
import type { ScoreWeights, Style, UserPreferences } from '../../domain/types';
import type { Location } from '../../domain/weather';
import { downloadBlob, exportProfile, garmentsToCSV, importBackup } from '../../data/backup';
import { storageEstimate } from '../../data/db';
import { deleteProfile, updateProfile } from '../../data/repo';
import { today } from '../../domain/dates';
import { weatherService } from '../hooks';
import { Chips, Field, Icon, PageHeader, Segmented, useConfirm } from '../components/ui';
import { useAction, useData, useSession, useToast } from '../store';

export function Settings() {
  const data = useData();
  const { repo, profile, setProfile, logout } = useSession();
  const act = useAction();
  const toast = useToast();
  const { ask, dialog } = useConfirm();
  const [p, setP] = useState<UserPreferences>(data.prefs);
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<Location[] | null>(null);
  const [searching, setSearching] = useState(false);
  const [name, setName] = useState(profile.name);
  const [pin, setPin] = useState('');
  const [storage, setStorage] = useState<Awaited<ReturnType<typeof storageEstimate>>>(null);
  const [busy, setBusy] = useState(false);
  useEffect(() => { storageEstimate().then(setStorage); }, []);
  const dirty = JSON.stringify(p) !== JSON.stringify(data.prefs);
  const set = <K extends keyof UserPreferences>(k: K, v: UserPreferences[K]) => setP((x) => ({ ...x, [k]: v }));
  const setW = (k: keyof ScoreWeights, v: number) => setP((x) => ({ ...x, weights: { ...x.weights, [k]: v } }));

  const search = async () => {
    if (!query.trim()) return;
    setSearching(true);
    try { setResults(await weatherService.geocode(query.trim())); }
    catch (e) { toast((e as Error).message + ' Puedes intentarlo más tarde o usar tu ubicación actual.', 'error'); }
    finally { setSearching(false); }
  };
  const geolocate = () => {
    if (!navigator.geolocation) return toast('Este navegador no permite obtener la ubicación.', 'error');
    navigator.geolocation.getCurrentPosition(
      (pos) => { set('location', { name: 'Mi ubicación actual', latitude: Math.round(pos.coords.latitude * 1000) / 1000, longitude: Math.round(pos.coords.longitude * 1000) / 1000 }); toast('Ubicación obtenida (redondeada a ~100 m). Recuerda guardar.'); },
      () => toast('No se pudo obtener la ubicación. Requiere HTTPS y tu permiso.', 'error'),
      { timeout: 10000 },
    );
  };
  const doExport = async () => {
    setBusy(true);
    try { downloadBlob(await exportProfile(profile), `smartwardrobe-${profile.name.toLowerCase().replace(/\W+/g, '-')}-${today()}.zip`); toast('Respaldo descargado. Guárdalo en un lugar seguro.'); }
    catch (e) { toast((e as Error).message, 'error'); }
    finally { setBusy(false); }
  };
  const doImport = async (f?: File) => {
    if (!f) return;
    setBusy(true);
    try { const np = await importBackup(f); toast(`Respaldo restaurado como el perfil "${np.name}". Cámbiate de perfil para verlo.`); }
    catch (e) { toast((e as Error).message, 'error'); }
    finally { setBusy(false); }
  };
  const remove = async () => {
    if (!(await ask(`Se eliminarán el perfil "${profile.name}", sus ${data.garments.length} prendas, fotos e historial de ESTE dispositivo. Descarga antes un respaldo si quieres conservarlos. ¿Continuar?`, true))) return;
    await deleteProfile(profile.id);
    logout();
  };

  const mb = (n: number) => `${(n / 1024 / 1024).toFixed(1)} MB`;

  return (
    <div className="fade-up space-y-5">
      <PageHeader eyebrow="Preferencias" title="Ajustes" action={dirty ? <button className="btn-primary" onClick={() => act(() => repo.savePreferences(p), 'Preferencias guardadas')} data-testid="save-prefs">Guardar cambios</button> : undefined} />

      <section className="card space-y-4 p-5">
        <h2 className="text-2xl">Ubicación para el clima</h2>
        <p className="text-sm text-ink-soft">Actual: <strong data-testid="current-location">{p.location?.name ?? 'sin configurar'}</strong>{p.location && ` (${p.location.latitude}, ${p.location.longitude})`}</p>
        <form className="flex gap-2" onSubmit={(e) => { e.preventDefault(); search(); }}>
          <input className="input" placeholder="Busca tu ciudad" value={query} onChange={(e) => setQuery(e.target.value)} aria-label="Ciudad" />
          <button className="btn-outline" disabled={searching}>{searching ? 'Buscando…' : 'Buscar'}</button>
        </form>
        {results && (results.length === 0 ? <p className="text-sm text-ink-soft">Sin resultados.</p> : (
          <ul className="divide-y divide-sand-100 rounded-2xl border border-sand-100">
            {results.map((r) => <li key={`${r.latitude},${r.longitude}`}><button className="w-full px-3 py-2 text-left text-sm hover:bg-sand-50" onClick={() => { set('location', r); setResults(null); setQuery(''); }}>{r.name}</button></li>)}
          </ul>
        ))}
        <div className="flex flex-wrap gap-2">
          <button className="btn-ghost btn-sm" onClick={geolocate}>Usar mi ubicación actual</button>
          {p.location && <button className="btn-ghost btn-sm text-rose" onClick={() => set('location', undefined)}>Quitar ubicación</button>}
        </div>
        <p className="text-xs text-ink-soft">Datos meteorológicos de Open-Meteo (open-meteo.com, licencia CC BY 4.0), uso no comercial. Si el servicio no responde, podrás ingresar el clima manualmente.</p>
      </section>

      <section className="card space-y-5 p-5">
        <h2 className="text-2xl">Estilo y recomendaciones</h2>
        <div><span className="field-label">Estilos preferidos</span><Chips label="Estilos preferidos" multiple value={p.preferredStyles} onChange={(v) => set('preferredStyles', v as Style[])} options={Object.entries(STYLES).map(([k, v]) => ({ value: k as Style, label: v }))} /></div>
        <div><span className="field-label">Colores que prefiero no recibir</span><Chips label="Colores a evitar" multiple value={p.avoidColors} onChange={(v) => set('avoidColors', v)} options={Object.entries(COLORS).map(([k, c]) => ({ value: k, label: c.label, dot: k }))} /></div>
        <Field label={`No repetir outfits usados en los últimos ${p.repeatWindowDays} días`}>
          <input type="range" min={0} max={30} value={p.repeatWindowDays} onChange={(e) => set('repeatWindowDays', Number(e.target.value))} className="w-full accent-[#8a5a3b]" />
        </Field>
        <div>
          <span className="field-label">Después de registrar un uso</span>
          <Segmented label="Estado tras el uso" value={p.afterWear} onChange={(v) => set('afterWear', v)} options={[{ value: 'preguntar', label: 'Preguntarme si lavar' }, { value: 'disponible', label: 'Mantener disponible' }]} />
          <p className="mt-1 text-xs text-ink-soft">"Preguntarme" deja las prendas como "Usada" hasta que decidas si van a lavandería.</p>
        </div>
        <label className="flex items-start gap-2 text-sm"><input type="checkbox" checked={p.allowUsedPending} onChange={(e) => set('allowUsedPending', e.target.checked)} className="mt-0.5 h-4 w-4 accent-[#8a5a3b]" /><span>Incluir prendas "usadas, pendientes de decidir" en las recomendaciones<span className="block text-xs text-ink-soft">Las prendas en lavandería, reparación, guardadas o retiradas nunca se incluyen.</span></span></label>
      </section>

      <details className="card p-5">
        <summary className="cursor-pointer text-2xl font-display">Motor de recomendación (avanzado)</summary>
        <p className="mt-3 text-sm text-ink-soft">Pesos de cada componente de la puntuación. Son valores iniciales razonados, no calibrados con datos: ajústalos según tu experiencia. La puntuación final es el promedio ponderado.</p>
        <div className="mt-4 grid gap-3 sm:grid-cols-2">
          {(Object.keys(WEIGHT_LABELS) as Array<keyof ScoreWeights>).map((k) => (
            <label key={k} className="grid grid-cols-[110px_1fr_36px] items-center gap-2 text-sm">
              <span>{WEIGHT_LABELS[k]}</span>
              <input type="range" min={0} max={3} step={0.1} value={p.weights[k]} onChange={(e) => setW(k, Number(e.target.value))} className="accent-[#8a5a3b]" aria-label={`Peso ${WEIGHT_LABELS[k]}`} />
              <span className="text-right tabular-nums text-ink-soft">{p.weights[k].toFixed(1)}</span>
            </label>
          ))}
          <label className="grid grid-cols-[110px_1fr_36px] items-center gap-2 text-sm sm:col-span-2">
            <span>Coherencia mínima</span>
            <input type="range" min={0.3} max={0.9} step={0.05} value={p.minCoherence} onChange={(e) => set('minCoherence', Number(e.target.value))} className="accent-[#8a5a3b]" aria-label="Coherencia mínima" />
            <span className="text-right tabular-nums text-ink-soft">{p.minCoherence.toFixed(2)}</span>
          </label>
        </div>
        <button className="btn-ghost btn-sm mt-3" onClick={() => setP((x) => ({ ...x, weights: { ...DEFAULT_WEIGHTS }, minCoherence: ENGINE.minCoherence }))}>Restablecer valores iniciales</button>
      </details>

      <section className="card space-y-4 p-5">
        <h2 className="text-2xl">Copias de seguridad</h2>
        <p className="text-sm text-ink-soft">Tus datos viven solo en este navegador. Si borras los datos del navegador, cambias de celular o desinstalas la app, se pierden. Descarga un respaldo con frecuencia (incluye las fotos).</p>
        <div className="flex flex-wrap gap-2">
          <button className="btn-primary" onClick={doExport} disabled={busy} data-testid="export"><Icon name="download" className="h-4 w-4" />Descargar respaldo (.zip)</button>
          <label className="btn-outline cursor-pointer"><Icon name="upload" className="h-4 w-4" />Restaurar respaldo<input type="file" accept=".zip,application/zip" className="sr-only" onChange={(e) => doImport(e.target.files?.[0])} data-testid="import" /></label>
          <button className="btn-ghost" onClick={() => downloadBlob(new Blob([garmentsToCSV(data.garments)], { type: 'text/csv;charset=utf-8' }), `inventario-${today()}.csv`)}>Exportar inventario (CSV)</button>
        </div>
        {storage && <p className="text-xs text-ink-soft">Espacio usado: {mb(storage.usage)} de {mb(storage.quota)} disponibles · almacenamiento {storage.persisted ? 'persistente (el navegador no lo borrará por falta de espacio)' : 'no persistente: el navegador podría liberarlo si falta espacio. Instalar la app ayuda.'}</p>}
      </section>

      <section className="card space-y-4 p-5">
        <h2 className="text-2xl">Perfil</h2>
        <form className="grid gap-3 sm:grid-cols-[1fr_auto]" onSubmit={async (e) => { e.preventDefault(); try { setProfile(await updateProfile(profile, { name })); toast('Nombre actualizado'); } catch (er) { toast((er as Error).message, 'error'); } }}>
          <Field label="Nombre"><input className="input" value={name} onChange={(e) => setName(e.target.value)} maxLength={40} /></Field>
          <button className="btn-outline self-end" disabled={!name.trim() || name === profile.name}>Guardar</button>
        </form>
        <form className="grid gap-3 sm:grid-cols-[1fr_auto]" onSubmit={async (e) => { e.preventDefault(); try { setProfile(await updateProfile(profile, { pin })); setPin(''); toast('PIN actualizado'); } catch (er) { toast((er as Error).message, 'error'); } }}>
          <Field label={profile.pinHash ? 'Cambiar PIN' : 'Agregar PIN'} hint="Barrera de conveniencia si compartes el dispositivo; no es cifrado."><input className="input" type="password" inputMode="numeric" value={pin} onChange={(e) => setPin(e.target.value.replace(/\D/g, ''))} maxLength={8} autoComplete="new-password" /></Field>
          <div className="flex gap-2 self-end">
            <button className="btn-outline" disabled={pin.length < 4}>Guardar PIN</button>
            {profile.pinHash && <button type="button" className="btn-ghost" onClick={async () => { setProfile(await updateProfile(profile, { pin: null })); toast('PIN eliminado'); }}>Quitar</button>}
          </div>
        </form>
        <div className="flex flex-wrap gap-2 border-t border-sand-100 pt-4">
          <button className="btn-outline" onClick={logout}><Icon name="logout" className="h-4 w-4" />Cerrar sesión</button>
          <button className="btn-ghost text-rose" onClick={remove}><Icon name="trash" className="h-4 w-4" />Eliminar perfil y datos</button>
        </div>
      </section>

      <section className="card p-5 text-sm text-ink-soft">
        <h2 className="mb-2 text-2xl text-ink">Instalar en el celular</h2>
        <p><strong>Android (Chrome):</strong> menú ⋮ → "Instalar aplicación" o "Agregar a la pantalla principal".</p>
        <p className="mt-1"><strong>iPhone (Safari):</strong> botón Compartir → "Agregar a inicio".</p>
        <p className="mt-2 text-xs">La instalación requiere que la app se abra por HTTPS (GitHub Pages o Cloudflare Pages lo dan automáticamente). Cada dispositivo tiene sus propios datos: usa respaldo y restauración para pasar tu armario de uno a otro.</p>
      </section>
      {dialog}
    </div>
  );
}
