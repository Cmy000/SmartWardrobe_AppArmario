import { useMemo, useState } from 'react';
import { CATEGORIES, STATUS_LABEL } from '../../domain/catalog';
import { formatMonth, today } from '../../domain/dates';
import { computeStats, type Metric } from '../../domain/stats';
import type { GarmentStatus } from '../../domain/types';
import { ColumnChart, HBarChart } from '../components/charts';
import { Empty, PageHeader, Segmented } from '../components/ui';
import { useData } from '../store';

type Period = '30' | '90' | '365' | 'todo';

function Kpi({ label, value, hint, testId }: { label: string; value: string; hint?: string; testId?: string }) {
  return (
    <div className="card p-4" data-testid={testId}>
      <div className="eyebrow mb-1.5 !tracking-[.12em]">{label}</div>
      <div className="text-3xl font-semibold tabular-nums">{value}</div>
      {hint && <div className="mt-1 text-xs text-ink-soft">{hint}</div>}
    </div>
  );
}

function metricText<T>(m: Metric<T>, fmt: (v: T) => string): { value: string; hint?: string } {
  return m.value === null ? { value: '—', hint: `Datos insuficientes: ${(m as { reason: string }).reason}` } : { value: fmt(m.value) };
}

export function Stats() {
  const data = useData();
  const [period, setPeriod] = useState<Period>('90');
  const [cat, setCat] = useState<string | null>(null);
  const t = today();
  const s = useMemo(() => computeStats(data.garments, data.wears, data.maintenance, t, period === 'todo' ? null : Number(period)), [data, t, period]);
  const catOf = new Map(data.garments.map((g) => [g.id, g.category]));
  if (data.garments.length === 0) return <div className="fade-up"><PageHeader title="Estadísticas" /><Empty icon="chart" title="Aún no hay datos" text="Registra prendas y su uso para ver tus indicadores." /></div>;

  const used = metricText(s.usedShare, (v) => `${Math.round(v * 100)} %`);
  const never = metricText(s.neverWorn, (v) => String(v.count));
  const unused = metricText(s.unusedInPeriod, (v) => String(v.count));
  const freq = s.frequency.filter((f) => !cat || catOf.get(f.id) === cat);
  const periodLabel = period === 'todo' ? 'todo el historial' : `últimos ${period} días`;

  return (
    <div className="fade-up space-y-5">
      <PageHeader eyebrow="Analítica" title="Estadísticas" />
      <div className="flex flex-wrap items-center gap-3">
        <Segmented label="Periodo" value={period} onChange={setPeriod} options={[{ value: '30', label: '30 días' }, { value: '90', label: '90 días' }, { value: '365', label: '1 año' }, { value: 'todo', label: 'Todo' }]} />
        <span className="text-xs text-ink-soft">{s.trackingDays === null ? 'Aún no hay registros de uso.' : `Registrando uso desde hace ${s.trackingDays} día(s).`}</span>
      </div>

      <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
        <Kpi label="Prendas" value={String(s.totalGarments)} hint={`${s.available} disponibles${s.retired ? ` · ${s.retired} retiradas` : ''}`} testId="kpi-total" />
        <Kpi label="Armario usado" value={used.value} hint={used.hint ?? periodLabel} testId="kpi-used" />
        <Kpi label="Outfits registrados" value={String(s.wearsInPeriod)} hint={`${periodLabel} · ${s.outfitsRegistered} en total`} testId="kpi-wears" />
        <Kpi label="Mantenimiento" value={String(s.pendingMaintenance)} hint="pendiente" />
        <Kpi label="Nunca usadas" value={never.value} hint={never.hint ?? 'sin ningún uso registrado'} />
        <Kpi label="Sin uso en el periodo" value={unused.value} hint={unused.hint ?? periodLabel} />
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        <section className="card p-4">
          <h2 className="mb-1 text-xl">Frecuencia de uso por prenda</h2>
          <p className="mb-3 text-xs text-ink-soft">{periodLabel}{cat ? ` · ${CATEGORIES[cat as keyof typeof CATEGORIES].label}` : ''} · top 12</p>
          <HBarChart data={freq.slice(0, 12).map((f) => ({ key: f.id, label: f.name, value: f.uses }))} unit="" emptyText="Sin prendas en esta categoría" />
        </section>
        <section className="card p-4">
          <h2 className="mb-1 text-xl">Categorías predominantes</h2>
          <p className="mb-3 text-xs text-ink-soft">Toca una categoría para filtrar la frecuencia de uso{cat && <> · <button className="font-medium text-clay" onClick={() => setCat(null)}>quitar filtro</button></>}</p>
          <HBarChart data={s.byCategory.map((c) => ({ key: c.key, label: c.label, value: c.count }))} onSelect={(k) => setCat(cat === k ? null : k)} selected={cat} />
        </section>
        <section className="card p-4">
          <h2 className="mb-1 text-xl">Distribución de colores</h2>
          <p className="mb-3 text-xs text-ink-soft">Color principal de las prendas activas (cada barra muestra el color que representa)</p>
          <HBarChart data={s.byColor.map((c) => ({ key: c.key, label: c.label, value: c.count, color: c.hex }))} />
        </section>
        <section className="card p-4">
          <h2 className="mb-1 text-xl">Rotación mensual</h2>
          <p className="mb-3 text-xs text-ink-soft">Prendas distintas usadas cada mes · {periodLabel}</p>
          <ColumnChart data={s.monthlyRotation.map((m) => ({ key: m.month, label: formatMonth(m.month), value: m.distinctItems, sub: `${m.wears} outfits` }))} />
        </section>
        <section className="card p-4">
          <h2 className="mb-1 text-xl">Estados</h2>
          <HBarChart data={Object.entries(s.byStatus).map(([k, v]) => ({ key: k, label: STATUS_LABEL[k as GarmentStatus].split(' ·')[0], value: v }))} />
        </section>
        <section className="card p-4">
          <h2 className="mb-1 text-xl">Costo por uso</h2>
          <p className="mb-3 text-xs text-ink-soft">Solo prendas con precio registrado. Costo ÷ usos históricos.</p>
          {s.costPerWear.length === 0 ? <p className="py-6 text-center text-sm text-ink-soft">Sin datos: registra el costo de tus prendas para calcularlo.</p> : (
            <table className="w-full text-sm" data-testid="cpw">
              <thead><tr className="text-left text-xs text-ink-soft"><th className="py-1 font-medium">Prenda</th><th className="py-1 text-right font-medium">Costo</th><th className="py-1 text-right font-medium">Usos</th><th className="py-1 text-right font-medium">Por uso</th></tr></thead>
              <tbody>{s.costPerWear.slice(0, 12).map((c) => (
                <tr key={c.id} className="border-t border-sand-100"><td className="max-w-[140px] truncate py-1.5"><a href={`#/prenda/${c.id}`}>{c.name}</a></td><td className="py-1.5 text-right tabular-nums">${c.cost.toLocaleString('es-CO')}</td><td className="py-1.5 text-right tabular-nums">{c.uses}</td><td className="py-1.5 text-right tabular-nums">{c.cpw === null ? <span className="text-xs text-ink-soft">sin usos</span> : `$${Math.round(c.cpw).toLocaleString('es-CO')}`}</td></tr>
              ))}</tbody>
            </table>
          )}
        </section>
      </div>
    </div>
  );
}
