import { useState } from 'react';
import { CATEGORIES, EVENTS, SLOT_LABEL } from '../../domain/catalog';
import { checkNewPlan } from '../../domain/planning';
import { comboKey } from '../../domain/recommender/engine';
import { today } from '../../domain/dates';
import type { Garment, Outfit, Slot } from '../../domain/types';
import { OutfitCard, OutfitCollage, useGarmentMap } from '../components/outfit';
import { Empty, Field, GarmentImg, Icon, Modal, PageHeader, Segmented, Stars, useConfirm } from '../components/ui';
import { useAction, useData, useSession } from '../store';

export function Outfits() {
  const data = useData();
  const { repo } = useSession();
  const act = useAction();
  const { ask, dialog } = useConfirm();
  const byId = useGarmentMap(data.garments);
  const [tab, setTab] = useState<'todos' | 'favoritos' | 'bloqueados'>('todos');
  const [building, setBuilding] = useState(false);
  const [planFor, setPlanFor] = useState<Outfit | null>(null);
  const [planDate, setPlanDate] = useState(today());
  const list = data.outfits.filter((o) => tab !== 'favoritos' || o.favorite).sort((a, b) => b.createdAt.localeCompare(a.createdAt));
  const unavailable = (o: Outfit) => o.itemIds.map((id) => byId.get(id)).filter((g) => !g || g.status !== 'disponible');
  const planConflicts = planFor ? checkNewPlan(planFor.itemIds, planDate, data.planned, data.garments) : [];

  return (
    <div className="fade-up">
      <PageHeader eyebrow={`${data.outfits.length} guardados`} title="Mis outfits" action={<button className="btn-primary" onClick={() => setBuilding(true)} data-testid="new-outfit"><Icon name="plus" /><span className="hidden sm:inline">Crear manualmente</span></button>} />
      <div className="mb-4"><Segmented label="Vista" value={tab} onChange={setTab} options={[{ value: 'todos', label: 'Todos' }, { value: 'favoritos', label: 'Favoritos' }, { value: 'bloqueados', label: `Bloqueados (${data.blocked.length})` }]} /></div>

      {tab === 'bloqueados' ? (
        data.blocked.length === 0 ? <Empty icon="ban" title="Sin combinaciones bloqueadas" text='Desde una recomendación puedes elegir "No sugerir más" para que esa combinación no vuelva a aparecer.' /> : (
          <ul className="grid gap-3 sm:grid-cols-2">
            {data.blocked.map((b) => {
              const items = b.itemIds.map((id) => byId.get(id)).filter(Boolean) as Garment[];
              return (
                <li key={b.id} className="card flex items-center gap-3 p-3">
                  <OutfitCollage items={items} className="h-20 w-16 shrink-0" />
                  <div className="min-w-0 flex-1 text-sm">{items.map((g) => g.name).join(' + ') || 'Prendas eliminadas'}</div>
                  <button className="btn-outline btn-sm" onClick={() => act(() => repo.unblock(b.id), 'Combinación desbloqueada')}>Desbloquear</button>
                </li>
              );
            })}
          </ul>
        )
      ) : list.length === 0 ? (
        <Empty icon="bookmark" title={tab === 'favoritos' ? 'Aún no tienes favoritos' : 'Aún no guardas outfits'} text="Guarda recomendaciones que te gusten o crea combinaciones propias para reutilizarlas." action={<a href="#/generar" className="btn-accent"><Icon name="sparkles" />Generar outfits</a>} />
      ) : (
        <div className="grid gap-4 xl:grid-cols-2">
          {list.map((o) => {
            const items = o.itemIds.map((id) => byId.get(id)).filter(Boolean) as Garment[];
            const un = unavailable(o);
            const rating = data.ratings.find((r) => r.comboKey === comboKey(o.itemIds))?.rating ?? 0;
            return (
              <OutfitCard key={o.id} testId="saved-outfit" items={items} title={o.name}
                actions={
                  <>
                    <button className="btn-primary btn-sm" disabled={un.length > 0} title={un.length ? 'Hay prendas no disponibles' : ''} onClick={() => act(() => repo.registerWear({ date: today(), itemIds: o.itemIds, outfitId: o.id, eventType: o.eventType }, data.prefs.afterWear), 'Uso registrado para hoy')}><Icon name="check" className="h-4 w-4" />Usar hoy</button>
                    <button className="btn-outline btn-sm" onClick={() => { setPlanFor(o); setPlanDate(today()); }}><Icon name="calendar" className="h-4 w-4" />Planificar</button>
                    <button className="btn-ghost btn-sm" aria-pressed={o.favorite} onClick={() => act(() => repo.saveOutfit({ ...o, favorite: !o.favorite }))}><Icon name="heart" filled={o.favorite} className="h-4 w-4 text-rose" />{o.favorite ? 'Favorito' : 'Favorito'}</button>
                    <button className="btn-ghost btn-sm text-rose" aria-label="Eliminar outfit" onClick={async () => { if (await ask(`¿Eliminar "${o.name}"? El historial de uso se conserva.`, true)) act(() => repo.deleteOutfit(o.id), 'Outfit eliminado'); }}><Icon name="trash" className="h-4 w-4" /></button>
                  </>
                }
                footer={
                  <div className="flex flex-wrap items-center justify-between gap-2 border-t border-sand-100 px-4 py-2.5">
                    <span className="text-xs text-ink-soft">{o.source === 'manual' ? 'Creado por ti' : 'Recomendado'}{o.eventType ? ` · ${EVENTS[o.eventType]?.label}` : ''}{un.length ? ` · ${un.length} prenda(s) no disponible(s)` : ''}</span>
                    <Stars value={rating} onChange={(n) => act(() => repo.rate(o.itemIds, n))} size="h-5 w-5" />
                  </div>
                }
              />
            );
          })}
        </div>
      )}

      <OutfitBuilder open={building} onClose={() => setBuilding(false)} />

      <Modal open={!!planFor} onClose={() => setPlanFor(null)} title="Planificar outfit">
        <form className="space-y-4" onSubmit={async (e) => { e.preventDefault(); if (planFor && await act(() => repo.plan({ date: planDate, itemIds: planFor.itemIds, outfitId: planFor.id, eventType: planFor.eventType }), 'Outfit planificado')) setPlanFor(null); }}>
          <Field label="Fecha"><input type="date" className="input" min={today()} value={planDate} onChange={(e) => setPlanDate(e.target.value)} required /></Field>
          {planConflicts.length > 0 && <ul className="rounded-2xl bg-amber-50 p-3 text-sm text-amber-900" role="alert">{planConflicts.map((c, i) => <li key={i}>⚠ {c.message}</li>)}</ul>}
          <div className="flex justify-end gap-2"><button type="button" className="btn-ghost" onClick={() => setPlanFor(null)}>Cancelar</button><button className="btn-primary">{planConflicts.length ? 'Planificar de todos modos' : 'Planificar'}</button></div>
        </form>
      </Modal>
      {dialog}
    </div>
  );
}

const BUILD_SLOTS: Slot[] = ['top', 'bottom', 'onepiece', 'outer', 'shoes', 'accessory'];

function OutfitBuilder({ open, onClose }: { open: boolean; onClose: () => void }) {
  const { garments } = useData();
  const { repo } = useSession();
  const act = useAction();
  const [sel, setSel] = useState<string[]>([]);
  const [name, setName] = useState('');
  const [slot, setSlot] = useState<Slot>('top');
  const pool = garments.filter((g) => g.status !== 'retirada' && CATEGORIES[g.category].slot === slot);
  const toggle = (id: string) => setSel((s) => (s.includes(id) ? s.filter((x) => x !== id) : [...s, id]));
  const save = async () => {
    if (await act(() => repo.saveOutfit({ name: name.trim() || 'Mi outfit', itemIds: sel, source: 'manual', favorite: false }), 'Outfit guardado')) { setSel([]); setName(''); onClose(); }
  };
  return (
    <Modal open={open} onClose={onClose} title="Crear outfit" wide>
      <div className="space-y-4">
        <Field label="Nombre"><input className="input" value={name} onChange={(e) => setName(e.target.value)} placeholder="Ej. Viernes en la oficina" data-testid="outfit-name" /></Field>
        <div className="-mx-1 flex gap-1 overflow-x-auto px-1 pb-1">
          {BUILD_SLOTS.map((s) => <button key={s} type="button" className={`chip shrink-0 ${slot === s ? 'chip-on' : ''}`} onClick={() => setSlot(s)}>{SLOT_LABEL[s]}</button>)}
        </div>
        {pool.length === 0 ? <p className="text-sm text-ink-soft">No tienes prendas de este tipo.</p> : (
          <div className="grid grid-cols-3 gap-2 sm:grid-cols-4">
            {pool.map((g) => (
              <button type="button" key={g.id} onClick={() => toggle(g.id)} aria-pressed={sel.includes(g.id)} className={`relative overflow-hidden rounded-2xl text-left ring-2 transition ${sel.includes(g.id) ? 'ring-ink' : 'ring-transparent'}`} data-testid="builder-item">
                <GarmentImg imageId={g.imageId} alt={g.name} color={g.colorPrimary} className="aspect-square w-full" />
                <span className="block truncate p-1.5 text-[11px]">{g.name}</span>
                {sel.includes(g.id) && <span className="absolute right-1.5 top-1.5 rounded-full bg-ink p-1 text-paper"><Icon name="check" className="h-3 w-3" /></span>}
              </button>
            ))}
          </div>
        )}
        <div className="flex items-center justify-between border-t border-sand-100 pt-4">
          <span className="text-sm text-ink-soft">{sel.length} prenda(s) seleccionada(s)</span>
          <button className="btn-primary" disabled={sel.length < 2} onClick={save} data-testid="save-outfit">Guardar outfit</button>
        </div>
      </div>
    </Modal>
  );
}
