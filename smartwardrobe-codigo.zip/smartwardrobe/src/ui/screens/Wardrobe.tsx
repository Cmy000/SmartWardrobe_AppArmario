import { useMemo, useState } from 'react';
import { CATEGORIES, COLORS, SLOT_LABEL, STATUS_LABEL } from '../../domain/catalog';
import { daysBetween, today } from '../../domain/dates';
import type { Garment, GarmentStatus, Slot } from '../../domain/types';
import { Chips, ColorDot, Empty, GarmentImg, Icon, PageHeader, Segmented, StatusBadge } from '../components/ui';
import { useData } from '../store';

type Group = 'ninguno' | 'categoria' | 'color' | 'estado';
const UNUSED_DAYS = 30;

export function isLittleUsed(g: Garment, t: string) {
  return g.status !== 'retirada' && (!g.lastWornAt || daysBetween(g.lastWornAt, t) >= UNUSED_DAYS);
}

export function Wardrobe({ initialFilter }: { initialFilter?: string }) {
  const { garments } = useData();
  const [q, setQ] = useState('');
  const [slots, setSlots] = useState<Slot[]>([]);
  const [status, setStatus] = useState<GarmentStatus | 'activas' | 'todas'>(initialFilter === 'disponible' ? 'disponible' : 'activas');
  const [color, setColor] = useState<string>('');
  const [onlyFav, setOnlyFav] = useState(false);
  const [littleUsed, setLittleUsed] = useState(initialFilter === 'poco_usadas');
  const [group, setGroup] = useState<Group>('ninguno');
  const t = today();

  const filtered = useMemo(() => {
    const needle = q.trim().toLowerCase();
    return garments.filter((g) => {
      if (status === 'activas' && g.status === 'retirada') return false;
      if (status !== 'activas' && status !== 'todas' && g.status !== status) return false;
      if (slots.length && !slots.includes(CATEGORIES[g.category].slot)) return false;
      if (color && g.colorPrimary !== color && !g.colorsSecondary.includes(color)) return false;
      if (onlyFav && !g.favorite) return false;
      if (littleUsed && !isLittleUsed(g, t)) return false;
      if (needle && ![g.name, g.brand, g.material, g.subcategory, CATEGORIES[g.category].label, ...g.tags].some((x) => x?.toLowerCase().includes(needle))) return false;
      return true;
    });
  }, [garments, q, slots, status, color, onlyFav, littleUsed, t]);

  const groups = useMemo(() => {
    if (group === 'ninguno') return [{ key: 'all', label: '', items: filtered }];
    const m = new Map<string, Garment[]>();
    for (const g of filtered) {
      const k = group === 'categoria' ? CATEGORIES[g.category].label : group === 'color' ? COLORS[g.colorPrimary]?.label ?? g.colorPrimary : STATUS_LABEL[g.status];
      (m.get(k) ?? m.set(k, []).get(k)!).push(g);
    }
    return [...m].sort((a, b) => b[1].length - a[1].length).map(([key, items]) => ({ key, label: key, items }));
  }, [filtered, group]);

  const usedColors = [...new Set(garments.map((g) => g.colorPrimary))];

  return (
    <div className="fade-up">
      <PageHeader eyebrow={`${garments.filter((g) => g.status !== 'retirada').length} prendas`} title="Mi armario" action={<a href="#/prenda/nueva" className="btn-primary" data-testid="add-garment"><Icon name="plus" /><span className="hidden sm:inline">Agregar prenda</span></a>} />
      {garments.length === 0 ? (
        <Empty icon="hanger" title="Tu armario está vacío" text="Agrega tus prendas con una foto desde el celular para empezar." action={<a className="btn-accent" href="#/prenda/nueva"><Icon name="camera" />Agregar prenda</a>} />
      ) : (
        <>
          <div className="card mb-5 space-y-3 p-4">
            <div className="relative">
              <Icon name="search" className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-ink-soft" />
              <input className="input !pl-10" placeholder="Buscar por nombre, marca, etiqueta…" value={q} onChange={(e) => setQ(e.target.value)} aria-label="Buscar prendas" type="search" />
            </div>
            <Chips label="Tipo" multiple value={slots} onChange={setSlots} options={(Object.keys(SLOT_LABEL) as Slot[]).map((s) => ({ value: s, label: SLOT_LABEL[s] }))} />
            <div className="flex flex-wrap items-center gap-2">
              <select className="input !w-auto !py-1.5 text-sm" value={status} onChange={(e) => setStatus(e.target.value as typeof status)} aria-label="Estado">
                <option value="activas">Activas</option>
                <option value="todas">Todas (incl. retiradas)</option>
                {(Object.keys(STATUS_LABEL) as GarmentStatus[]).map((s) => <option key={s} value={s}>{STATUS_LABEL[s]}</option>)}
              </select>
              <select className="input !w-auto !py-1.5 text-sm" value={color} onChange={(e) => setColor(e.target.value)} aria-label="Color">
                <option value="">Todos los colores</option>
                {usedColors.map((c) => <option key={c} value={c}>{COLORS[c]?.label ?? c}</option>)}
              </select>
              <button className={`chip ${onlyFav ? 'chip-on' : ''}`} aria-pressed={onlyFav} onClick={() => setOnlyFav(!onlyFav)}><Icon name="heart" className="h-3.5 w-3.5" filled={onlyFav} />Favoritas</button>
              <button className={`chip ${littleUsed ? 'chip-on' : ''}`} aria-pressed={littleUsed} onClick={() => setLittleUsed(!littleUsed)}>Poco usadas (+{UNUSED_DAYS} días)</button>
            </div>
            <div className="flex items-center gap-2 text-xs text-ink-soft">
              Agrupar:
              <Segmented label="Agrupar por" value={group} onChange={setGroup} options={[{ value: 'ninguno', label: 'No' }, { value: 'categoria', label: 'Categoría' }, { value: 'color', label: 'Color' }, { value: 'estado', label: 'Estado' }]} />
            </div>
          </div>
          {filtered.length === 0 ? (
            <Empty icon="search" title="Sin resultados" text="Ninguna prenda coincide con los filtros." action={<button className="btn-outline" onClick={() => { setQ(''); setSlots([]); setColor(''); setOnlyFav(false); setLittleUsed(false); setStatus('activas'); }}>Limpiar filtros</button>} />
          ) : groups.map((gr) => (
            <section key={gr.key} className="mb-6">
              {gr.label && <h2 className="mb-3 text-xl">{gr.label} <span className="text-sm text-ink-soft">({gr.items.length})</span></h2>}
              <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4" data-testid="garment-grid">
                {gr.items.map((g) => <GarmentTile key={g.id} g={g} />)}
              </div>
            </section>
          ))}
        </>
      )}
    </div>
  );
}

function GarmentTile({ g }: { g: Garment }) {
  return (
    <a href={`#/prenda/${g.id}`} className="group block" data-testid="garment-tile">
      <div className="relative overflow-hidden rounded-3xl">
        <GarmentImg imageId={g.imageId} alt={g.name} color={g.colorPrimary} className="aspect-[4/5] w-full transition duration-300 group-hover:scale-[1.03]" />
        <div className="absolute left-2 top-2"><StatusBadge status={g.status} /></div>
        {g.favorite && <div className="absolute right-2 top-2 rounded-full bg-white/90 p-1.5 text-rose"><Icon name="heart" filled className="h-3.5 w-3.5" /></div>}
      </div>
      <div className="mt-2 flex items-center gap-1.5 px-1">
        <ColorDot color={g.colorPrimary} className="h-3 w-3" />
        <span className="truncate text-sm font-medium">{g.name}</span>
      </div>
      <div className="px-1 text-xs text-ink-soft">{CATEGORIES[g.category].label} · {g.wearCount} uso{g.wearCount === 1 ? '' : 's'}</div>
    </a>
  );
}
