import { useEffect, useState, type ReactNode } from 'react';
import type { Profile } from '../domain/types';
import { listProfiles } from '../data/repo';
import { requestPersistence } from '../data/db';
import { navigate, useRoute } from './router';
import { SESSION_KEY, SessionProvider, ToastProvider, useSession } from './store';
import { Icon, Modal, Spinner } from './components/ui';
import { ProfilesScreen } from './screens/Profiles';
import { Dashboard } from './screens/Dashboard';
import { Wardrobe } from './screens/Wardrobe';
import { GarmentForm } from './screens/GarmentForm';
import { GarmentDetail } from './screens/GarmentDetail';
import { Generator } from './screens/Generator';
import { Outfits } from './screens/Outfits';
import { CalendarScreen } from './screens/Calendar';
import { Maintenance } from './screens/Maintenance';
import { Stats } from './screens/Stats';
import { Settings } from './screens/Settings';

const NAV = [
  { href: '/', label: 'Inicio', icon: 'home' },
  { href: '/armario', label: 'Armario', icon: 'hanger' },
  { href: '/generar', label: 'Crear outfit', icon: 'sparkles' },
  { href: '/outfits', label: 'Mis outfits', icon: 'bookmark' },
  { href: '/calendario', label: 'Calendario', icon: 'calendar' },
  { href: '/mantenimiento', label: 'Lavandería', icon: 'wash' },
  { href: '/estadisticas', label: 'Estadísticas', icon: 'chart' },
  { href: '/ajustes', label: 'Ajustes', icon: 'settings' },
];
const MOBILE = ['/', '/armario', '/generar', '/calendario'];

function isActive(href: string, path: string) {
  return href === '/' ? path === '/' : path.startsWith(href) || (href === '/armario' && path.startsWith('/prenda'));
}

function Shell({ children }: { children: ReactNode }) {
  const { path } = useRoute();
  const { profile, logout } = useSession();
  const [more, setMore] = useState(false);
  return (
    <div className="min-h-dvh lg:pl-64">
      <aside className="fixed inset-y-0 left-0 hidden w-64 flex-col border-r border-sand-100 bg-white/60 p-5 backdrop-blur lg:flex">
        <a href="#/" className="mb-8 block"><span className="font-display text-2xl">SmartWardrobe</span></a>
        <nav className="flex-1 space-y-1" aria-label="Principal">
          {NAV.map((n) => (
            <a key={n.href} href={`#${n.href}`} aria-current={isActive(n.href, path) ? 'page' : undefined}
              className={`flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm transition ${isActive(n.href, path) ? 'bg-ink text-paper' : 'text-ink-soft hover:bg-sand-100 hover:text-ink'}`}>
              <Icon name={n.icon} />{n.label}
            </a>
          ))}
        </nav>
        <div className="flex items-center justify-between rounded-2xl bg-sand-50 p-3 text-sm">
          <span className="truncate">{profile.name}{profile.isDemo && <span className="ml-1 text-xs text-clay">(demo)</span>}</span>
          <button className="btn-ghost btn-sm !px-2" onClick={logout} aria-label="Cerrar sesión" title="Cambiar de perfil"><Icon name="logout" className="h-4 w-4" /></button>
        </div>
      </aside>
      {profile.isDemo && <div className="bg-clay px-4 py-1.5 text-center text-xs font-medium text-white">Estás viendo datos de demostración (ilustraciones, no fotos reales)</div>}
      <main className="mx-auto max-w-5xl px-4 pb-28 pt-6 sm:px-6 lg:pb-12 lg:pt-10">{children}</main>
      <nav className="safe-bottom fixed inset-x-0 bottom-0 z-40 border-t border-sand-100 bg-paper/95 backdrop-blur lg:hidden" aria-label="Principal móvil">
        <div className="mx-auto grid max-w-md grid-cols-5">
          {NAV.filter((n) => MOBILE.includes(n.href)).map((n) => (
            <a key={n.href} href={`#${n.href}`} aria-current={isActive(n.href, path) ? 'page' : undefined}
              className={`flex flex-col items-center gap-0.5 py-2 text-[10px] font-medium ${isActive(n.href, path) ? 'text-ink' : 'text-ink-soft'}`}>
              {n.href === '/generar'
                ? <span className="-mt-5 flex h-12 w-12 items-center justify-center rounded-full bg-ink text-paper shadow-lg"><Icon name={n.icon} /></span>
                : <Icon name={n.icon} />}
              {n.href === '/generar' ? 'Crear' : n.label}
            </a>
          ))}
          <button onClick={() => setMore(true)} className="flex flex-col items-center gap-0.5 py-2 text-[10px] font-medium text-ink-soft"><Icon name="more" />Más</button>
        </div>
      </nav>
      <Modal open={more} onClose={() => setMore(false)} title="Más">
        <div className="grid grid-cols-2 gap-2">
          {NAV.filter((n) => !MOBILE.includes(n.href)).map((n) => (
            <a key={n.href} href={`#${n.href}`} onClick={() => setMore(false)} className="card flex flex-col items-start gap-2 p-4 text-sm"><Icon name={n.icon} className="h-6 w-6 text-clay" />{n.label}</a>
          ))}
          <button onClick={() => { setMore(false); logout(); }} className="card flex flex-col items-start gap-2 p-4 text-left text-sm"><Icon name="logout" className="h-6 w-6 text-clay" />Cambiar perfil</button>
        </div>
      </Modal>
    </div>
  );
}

function Routes() {
  const { parts, query } = useRoute();
  const { data } = useSession();
  if (!data) return <Spinner label="Abriendo tu armario…" />;
  const [a, b, c] = parts;
  if (!a) return <Dashboard />;
  if (a === 'armario') return <Wardrobe initialFilter={query.get('filtro') ?? undefined} />;
  if (a === 'prenda' && b === 'nueva') return <GarmentForm key="new" />;
  if (a === 'prenda' && b && c === 'editar') return <GarmentForm key={b} id={b} />;
  if (a === 'prenda' && b) return <GarmentDetail key={b} id={b} />;
  if (a === 'generar') return <Generator />;
  if (a === 'outfits') return <Outfits />;
  if (a === 'calendario') return <CalendarScreen />;
  if (a === 'mantenimiento') return <Maintenance />;
  if (a === 'estadisticas') return <Stats />;
  if (a === 'ajustes') return <Settings />;
  return <div className="py-20 text-center"><h1 className="text-3xl">Página no encontrada</h1><a className="btn-outline mt-6" href="#/">Ir al inicio</a></div>;
}

export function App() {
  const [profile, setProfile] = useState<Profile | null | undefined>(undefined);
  useEffect(() => {
    requestPersistence();
    const id = sessionStorage.getItem(SESSION_KEY) ?? localStorage.getItem(SESSION_KEY);
    listProfiles().then((ps) => setProfile(ps.find((p) => p.id === id) ?? null)).catch(() => setProfile(null));
  }, []);
  const enter = (p: Profile) => {
    // Perfiles con PIN: la sesión termina al cerrar el navegador. Sin PIN: se recuerda en el dispositivo.
    (p.pinHash ? sessionStorage : localStorage).setItem(SESSION_KEY, p.id); setProfile(p); navigate('/', true); };
  const logout = () => { sessionStorage.removeItem(SESSION_KEY); localStorage.removeItem(SESSION_KEY); setProfile(null); navigate('/', true); };
  return (
    <ToastProvider>
      {profile === undefined ? <Spinner /> : profile === null ? <ProfilesScreen onEnter={enter} /> : (
        <SessionProvider key={profile.id} profile={profile} onLogout={logout} onProfileChange={setProfile}>
          <Shell><Routes /></Shell>
        </SessionProvider>
      )}
    </ToastProvider>
  );
}
