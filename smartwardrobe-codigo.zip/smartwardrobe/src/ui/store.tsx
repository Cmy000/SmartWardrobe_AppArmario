// Estado de la sesión: perfil activo, repositorio con aislamiento y caché en memoria de sus datos.
// Tras cada mutación se llama a `reload()`; el volumen de datos de un armario personal
// (cientos de registros) hace que recargar todo sea simple y suficientemente rápido.
import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from 'react';
import type {
  BlockedCombo, Garment, MaintenanceRecord, Outfit, OutfitRating, PlannedOutfit, Profile, RecommendationRecord, StatusChange, UserPreferences, WearRecord,
} from '../domain/types';
import { ProfileRepo } from '../data/repo';

export interface ProfileData {
  garments: Garment[];
  outfits: Outfit[];
  wears: WearRecord[];
  planned: PlannedOutfit[];
  maintenance: MaintenanceRecord[];
  ratings: OutfitRating[];
  blocked: BlockedCombo[];
  history: StatusChange[];
  recommendations: RecommendationRecord[];
  prefs: UserPreferences;
}

interface Ctx {
  profile: Profile;
  repo: ProfileRepo;
  data: ProfileData | null;
  reload: () => Promise<void>;
  logout: () => void;
  setProfile: (p: Profile) => void;
}

const SessionCtx = createContext<Ctx | null>(null);
export const SESSION_KEY = 'sw-active-profile';

export function SessionProvider({ profile, onLogout, onProfileChange, children }: { profile: Profile; onLogout: () => void; onProfileChange: (p: Profile) => void; children: ReactNode }) {
  const repo = useMemo(() => new ProfileRepo(profile.id), [profile.id]);
  const [data, setData] = useState<ProfileData | null>(null);
  const reload = useCallback(async () => {
    const [garments, outfits, wears, planned, maintenance, ratings, blocked, history, recommendations, prefs] = await Promise.all([
      repo.garments(), repo.outfits(), repo.wears(), repo.planned(), repo.maintenance(), repo.ratings(), repo.blocked(), repo.statusHistory(), repo.recommendations(), repo.preferences(),
    ]);
    garments.sort((a, b) => b.createdAt.localeCompare(a.createdAt));
    setData({ garments, outfits, wears, planned, maintenance, ratings, blocked, history, recommendations, prefs });
  }, [repo]);
  useEffect(() => { setData(null); reload(); }, [reload]);
  return <SessionCtx.Provider value={{ profile, repo, data, reload, logout: onLogout, setProfile: onProfileChange }}>{children}</SessionCtx.Provider>;
}

export function useSession(): Ctx {
  const c = useContext(SessionCtx);
  if (!c) throw new Error('useSession fuera de SessionProvider');
  return c;
}

/** Datos ya cargados (las pantallas se renderizan solo cuando existen). */
export function useData(): ProfileData {
  const d = useSession().data;
  if (!d) throw new Error('Datos no cargados');
  return d;
}

// ---------------- Avisos (toasts) ----------------
type Toast = { id: number; text: string; kind: 'ok' | 'error' };
const ToastCtx = createContext<(text: string, kind?: Toast['kind']) => void>(() => {});
export function ToastProvider({ children }: { children: ReactNode }) {
  const [toasts, setToasts] = useState<Toast[]>([]);
  const push = useCallback((text: string, kind: Toast['kind'] = 'ok') => {
    const id = Date.now() + Math.random();
    setToasts((t) => [...t, { id, text, kind }]);
    setTimeout(() => setToasts((t) => t.filter((x) => x.id !== id)), 3800);
  }, []);
  return (
    <ToastCtx.Provider value={push}>
      {children}
      <div className="pointer-events-none fixed inset-x-0 top-3 z-[60] flex flex-col items-center gap-2 px-4" role="status" aria-live="polite">
        {toasts.map((t) => (
          <div key={t.id} className={`fade-up pointer-events-auto max-w-md rounded-2xl px-4 py-3 text-sm shadow-lg ${t.kind === 'error' ? 'bg-rose text-white' : 'bg-ink text-paper'}`}>{t.text}</div>
        ))}
      </div>
    </ToastCtx.Provider>
  );
}
export const useToast = () => useContext(ToastCtx);

/** Ejecuta una acción mostrando el error al usuario si falla. */
export function useAction() {
  const toast = useToast();
  const { reload } = useSession();
  return useCallback(async (fn: () => Promise<unknown>, okMsg?: string) => {
    try {
      await fn();
      await reload();
      if (okMsg) toast(okMsg);
      return true;
    } catch (e) {
      toast(e instanceof Error ? e.message : 'Ocurrió un error inesperado.', 'error');
      return false;
    }
  }, [toast, reload]);
}
