import { useState, type ReactNode } from 'react';
import { CATEGORIES } from '../../domain/catalog';
import { WEIGHT_LABELS } from '../../domain/recommender/config';
import type { ExplanationLine } from '../../domain/recommender/types';
import type { Garment, ID, ScoreWeights } from '../../domain/types';
import { GarmentImg, Icon } from './ui';

const SLOT_ORDER = ['outer', 'top', 'onepiece', 'bottom', 'shoes', 'accessory'];

export function sortBySlot(items: Garment[]): Garment[] {
  return [...items].sort((a, b) => SLOT_ORDER.indexOf(CATEGORIES[a.category].slot) - SLOT_ORDER.indexOf(CATEGORIES[b.category].slot));
}

export function OutfitCollage({ items, className = '' }: { items: Garment[]; className?: string }) {
  const s = sortBySlot(items);
  const main = s.slice(0, 4);
  return (
    <div className={`grid gap-1 overflow-hidden rounded-2xl bg-sand-100 ${main.length <= 2 ? 'grid-cols-2' : 'grid-cols-2 grid-rows-2'} ${className}`}>
      {main.map((g, i) => (
        <div key={g.id} className={`relative overflow-hidden ${main.length === 3 && i === 0 ? 'row-span-2' : ''}`}>
          <GarmentImg imageId={g.imageId} alt={g.name} color={g.colorPrimary} className="h-full w-full" />
        </div>
      ))}
      {s.length > 4 && <div className="sr-only">y {s.length - 4} más</div>}
    </div>
  );
}

export function ItemList({ items }: { items: Garment[] }) {
  return (
    <ul className="space-y-1.5">
      {sortBySlot(items).map((g) => (
        <li key={g.id}>
          <a href={`#/prenda/${g.id}`} className="flex items-center gap-2.5 rounded-xl p-1 hover:bg-sand-50">
            <GarmentImg imageId={g.imageId} alt="" color={g.colorPrimary} className="h-10 w-10 shrink-0 rounded-lg" />
            <span className="min-w-0">
              <span className="block truncate text-sm font-medium">{g.name}</span>
              <span className="block text-xs text-ink-soft">{CATEGORIES[g.category].label}</span>
            </span>
          </a>
        </li>
      ))}
    </ul>
  );
}

export function OutfitCard({ items, title, score, explanation, components, weights, actions, footer, testId }: {
  items: Garment[]; title?: string; score?: number; explanation?: ExplanationLine[]; components?: Record<string, number>; weights?: ScoreWeights;
  actions?: ReactNode; footer?: ReactNode; testId?: string;
}) {
  const [showDetail, setShowDetail] = useState(false);
  return (
    <article className="card fade-up overflow-hidden" data-testid={testId}>
      <div className="grid gap-4 p-4 sm:grid-cols-[minmax(0,0.8fr)_minmax(0,1.2fr)]">
        <OutfitCollage items={items} className="aspect-[4/3] w-full sm:aspect-[4/5]" />
        <div className="flex min-w-0 flex-col">
          <div className="mb-2 flex items-start justify-between gap-2">
            <h3 className="text-xl leading-snug">{title ?? 'Outfit'}</h3>
            {score !== undefined && (
              <span className="shrink-0 rounded-full bg-sand-100 px-2.5 py-1 text-xs font-semibold text-clay" title="Puntuación del motor (0–100)">{Math.round(score * 100)}</span>
            )}
          </div>
          <ItemList items={items} />
          {explanation && (
            <div className="mt-3 rounded-2xl bg-sand-50 p-3">
              <div className="eyebrow mb-1.5">Por qué este outfit</div>
              <ul className="space-y-1 text-[13px] leading-snug text-ink-soft" data-testid="explanation">
                {explanation.filter((l) => l.factor !== 'plantilla').map((l, i) => (
                  <li key={i} className="flex gap-1.5"><Icon name="check" className="mt-0.5 h-3.5 w-3.5 shrink-0 text-moss" />{l.text}</li>
                ))}
              </ul>
              {components && (
                <button className="mt-2 text-xs font-medium text-clay underline-offset-2 hover:underline" onClick={() => setShowDetail((v) => !v)} aria-expanded={showDetail}>
                  {showDetail ? 'Ocultar' : 'Ver'} desglose de la puntuación
                </button>
              )}
              {showDetail && components && <ScoreBreakdown components={components} weights={weights} />}
            </div>
          )}
          {actions && <div className="mt-auto flex flex-wrap gap-2 pt-4">{actions}</div>}
        </div>
      </div>
      {footer}
    </article>
  );
}

export function ScoreBreakdown({ components, weights }: { components: Record<string, number>; weights?: ScoreWeights }) {
  return (
    <dl className="mt-2 space-y-1.5">
      {(Object.keys(WEIGHT_LABELS) as Array<keyof ScoreWeights>).map((k) => (
        <div key={k} className="grid grid-cols-[96px_1fr_34px] items-center gap-2 text-[11px]">
          <dt className="text-ink-soft">{WEIGHT_LABELS[k]}{weights ? ` ×${weights[k]}` : ''}</dt>
          <dd className="h-1.5 overflow-hidden rounded-full bg-sand-200"><div className="h-full rounded-full bg-clay" style={{ width: `${Math.round((components[k] ?? 0) * 100)}%` }} /></dd>
          <dd className="text-right tabular-nums text-ink-soft">{Math.round((components[k] ?? 0) * 100)}</dd>
        </div>
      ))}
    </dl>
  );
}

export function useGarmentMap(garments: Garment[]) {
  const m = new Map<ID, Garment>();
  for (const g of garments) m.set(g.id, g);
  return m;
}
