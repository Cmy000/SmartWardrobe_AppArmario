// Gráficos ligeros en HTML/SVG (sin librerías): barras horizontales y columnas, una sola serie,
// con tooltip por barra (hover y foco de teclado) y vista de tabla alternativa.
import { useState } from 'react';

export interface Bar { key: string; label: string; value: number; color?: string; sub?: string }

function Tip({ x, y, title, value }: { x: number; y: number; title: string; value: string }) {
  return (
    <div className="pointer-events-none absolute z-10 -translate-x-1/2 -translate-y-full rounded-xl bg-ink px-2.5 py-1.5 text-xs text-paper shadow-lg" style={{ left: x, top: y - 6 }} role="tooltip">
      <div className="font-semibold tabular-nums">{value}</div>
      <div className="opacity-80">{title}</div>
    </div>
  );
}

export function HBarChart({ data, unit = '', onSelect, selected, max: maxOverride, emptyText = 'Sin datos' }: {
  data: Bar[]; unit?: string; onSelect?: (key: string) => void; selected?: string | null; max?: number; emptyText?: string;
}) {
  const [hover, setHover] = useState<{ i: number; x: number; y: number } | null>(null);
  const [table, setTable] = useState(false);
  if (data.length === 0) return <p className="py-6 text-center text-sm text-ink-soft">{emptyText}</p>;
  const max = maxOverride ?? Math.max(1, ...data.map((d) => d.value));
  const total = data.reduce((s, d) => s + d.value, 0);
  return (
    <div>
      {table ? (
        <table className="w-full text-sm">
          <thead><tr className="text-left text-xs text-ink-soft"><th className="py-1 font-medium">Elemento</th><th className="py-1 text-right font-medium">Valor</th><th className="py-1 text-right font-medium">%</th></tr></thead>
          <tbody>{data.map((d) => <tr key={d.key} className="border-t border-sand-100"><td className="py-1.5">{d.label}</td><td className="py-1.5 text-right tabular-nums">{d.value}{unit}</td><td className="py-1.5 text-right tabular-nums text-ink-soft">{total ? Math.round((d.value / total) * 100) : 0}%</td></tr>)}</tbody>
        </table>
      ) : (
        <ul className="relative space-y-[2px]" onPointerLeave={() => setHover(null)}>
          {data.map((d, i) => {
            const pct = (d.value / max) * 100;
            const show = (e: { currentTarget: HTMLElement }) => {
              const r = e.currentTarget.getBoundingClientRect();
              const pr = e.currentTarget.parentElement!.getBoundingClientRect();
              setHover({ i, x: r.left - pr.left + Math.max(40, (r.width * pct) / 100) / 2 + 112, y: r.top - pr.top });
            };
            return (
              <li key={d.key}>
                <button type="button" onPointerEnter={show} onFocus={show} onBlur={() => setHover(null)} onClick={() => onSelect?.(d.key)}
                  aria-label={`${d.label}: ${d.value}${unit}`} aria-pressed={selected === d.key}
                  className={`group grid w-full grid-cols-[104px_1fr_44px] items-center gap-2 rounded-lg py-1 text-left ${onSelect ? 'cursor-pointer' : 'cursor-default'} ${selected && selected !== d.key ? 'opacity-50' : ''}`}>
                  <span className="truncate text-xs text-ink-soft">{d.label}</span>
                  <span className="relative h-5">
                    <span className={`absolute inset-y-0 left-0 rounded-r-[4px] transition-[filter] group-hover:brightness-110 ${d.color ? 'ring-1 ring-inset ring-black/10' : 'bg-clay'}`}
                      style={{ width: `${Math.max(pct, d.value > 0 ? 1.5 : 0)}%`, background: d.color }} />
                  </span>
                  <span className="text-right text-xs font-semibold tabular-nums">{d.value}{unit}</span>
                </button>
              </li>
            );
          })}
          {hover && <Tip x={Math.min(hover.x, 260)} y={hover.y} title={data[hover.i].sub ?? data[hover.i].label} value={`${data[hover.i].value}${unit} · ${total ? Math.round((data[hover.i].value / total) * 100) : 0}% del total`} />}
        </ul>
      )}
      <button className="mt-2 text-[11px] font-medium text-ink-soft underline-offset-2 hover:underline" onClick={() => setTable((t) => !t)}>{table ? 'Ver gráfico' : 'Ver como tabla'}</button>
    </div>
  );
}

export function ColumnChart({ data, unit = '', height = 160 }: { data: Bar[]; unit?: string; height?: number }) {
  const [hover, setHover] = useState<number | null>(null);
  const [table, setTable] = useState(false);
  if (data.length === 0) return <p className="py-6 text-center text-sm text-ink-soft">Sin datos en el periodo</p>;
  const max = Math.max(1, ...data.map((d) => d.value));
  return (
    <div>
      {table ? (
        <table className="w-full text-sm"><tbody>{data.map((d) => <tr key={d.key} className="border-t border-sand-100"><td className="py-1.5 capitalize">{d.label}</td><td className="py-1.5 text-right tabular-nums">{d.value}{unit}</td><td className="py-1.5 text-right text-xs text-ink-soft">{d.sub}</td></tr>)}</tbody></table>
      ) : (
        <div className="relative">
          <div className="flex items-end gap-[2px] border-b border-sand-200" style={{ height }} onPointerLeave={() => setHover(null)}>
            {data.map((d, i) => (
              <button key={d.key} type="button" className="group relative flex h-full flex-1 items-end" onPointerEnter={() => setHover(i)} onFocus={() => setHover(i)} onBlur={() => setHover(null)} aria-label={`${d.label}: ${d.value}${unit}`}>
                <span className="w-full rounded-t-[4px] bg-clay transition-[filter] group-hover:brightness-110" style={{ height: `${(d.value / max) * 100}%`, minHeight: d.value > 0 ? 3 : 0 }} />
                {hover === i && (
                  <span className="pointer-events-none absolute bottom-full left-1/2 z-10 mb-1 -translate-x-1/2 whitespace-nowrap rounded-xl bg-ink px-2.5 py-1.5 text-xs text-paper shadow-lg" role="tooltip">
                    <span className="block font-semibold tabular-nums">{d.value}{unit}</span><span className="block capitalize opacity-80">{d.label}{d.sub ? ` · ${d.sub}` : ''}</span>
                  </span>
                )}
              </button>
            ))}
          </div>
          <div className="mt-1 flex gap-[2px]">{data.map((d) => <span key={d.key} className="flex-1 truncate text-center text-[10px] capitalize text-ink-soft">{d.label.slice(0, 3)}</span>)}</div>
        </div>
      )}
      <button className="mt-2 text-[11px] font-medium text-ink-soft underline-offset-2 hover:underline" onClick={() => setTable((t) => !t)}>{table ? 'Ver gráfico' : 'Ver como tabla'}</button>
    </div>
  );
}
