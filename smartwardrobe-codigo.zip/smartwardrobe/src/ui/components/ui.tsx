// Componentes de interfaz reutilizables.
import { useEffect, useRef, useState, type ReactNode } from 'react';
import { COLORS } from '../../domain/catalog';
import type { ID } from '../../domain/types';
import { useSession } from '../store';

// ---------- Iconos (trazos propios, estilo lineal) ----------
const PATHS: Record<string, string> = {
  home: 'M3 10.5 12 3l9 7.5M5 9v11h5v-6h4v6h5V9',
  hanger: 'M12 6a2 2 0 1 1 2 2c-1 .3-2 1-2 2v1m0 0L3 17.5c-.8.5-.4 1.5.5 1.5h17c.9 0 1.3-1 .5-1.5L12 11Z',
  sparkles: 'M12 3l1.8 4.7L18.5 9.5l-4.7 1.8L12 16l-1.8-4.7L5.5 9.5l4.7-1.8L12 3ZM19 15l.8 2.2L22 18l-2.2.8L19 21l-.8-2.2L16 18l2.2-.8L19 15Z',
  calendar: 'M4 6h16v14H4zM4 10h16M8 3v4M16 3v4',
  more: 'M5 12h.01M12 12h.01M19 12h.01',
  plus: 'M12 5v14M5 12h14',
  camera: 'M4 8h3l2-3h6l2 3h3v11H4zM12 17a4 4 0 1 0 0-8 4 4 0 0 0 0 8Z',
  search: 'M11 18a7 7 0 1 0 0-14 7 7 0 0 0 0 14ZM20 20l-4-4',
  heart: 'M12 20s-7-4.4-7-10a4 4 0 0 1 7-2.6A4 4 0 0 1 19 10c0 5.6-7 10-7 10Z',
  star: 'm12 3 2.7 5.6 6.1.9-4.4 4.3 1 6.1L12 17l-5.4 2.9 1-6.1-4.4-4.3 6.1-.9L12 3Z',
  x: 'M6 6l12 12M18 6 6 18',
  check: 'M5 12.5 10 17 19 7',
  trash: 'M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3',
  edit: 'M4 20h4L19 9l-4-4L4 16v4ZM13.5 6.5l4 4',
  sun: 'M12 16a4 4 0 1 0 0-8 4 4 0 0 0 0 8ZM12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4',
  cloud: 'M7 18h10a4 4 0 0 0 .5-8A6 6 0 0 0 6 9.5 4.3 4.3 0 0 0 7 18Z',
  rain: 'M7 14h10a4 4 0 0 0 .5-8A6 6 0 0 0 6 5.5 4.3 4.3 0 0 0 7 14ZM8 17l-1 3M12 17l-1 3M16 17l-1 3',
  wash: 'M5 3h14v18H5zM5 7h14M8 5h.01M12 17a4 4 0 1 0 0-8 4 4 0 0 0 0 8Z',
  wrench: 'M14.7 6.3a4 4 0 0 0-5.4 5.4L3 18l3 3 6.3-6.3a4 4 0 0 0 5.4-5.4l-2.5 2.5-2.4-.6-.6-2.4 2.5-2.5Z',
  chart: 'M4 20V10M10 20V4M16 20v-7M22 20H2',
  settings: 'M12 15a3 3 0 1 0 0-6 3 3 0 0 0 0 6ZM19.4 15a1.7 1.7 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.8-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1.1-1.5 1.7 1.7 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.8 1.7 1.7 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.5-1.1 1.7 1.7 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.8.3H9a1.7 1.7 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.8V9a1.7 1.7 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1Z',
  back: 'M15 18 9 12l6-6',
  chevron: 'm9 6 6 6-6 6',
  logout: 'M15 4h4v16h-4M10 16l4-4-4-4M14 12H4',
  download: 'M12 4v11M7 10l5 5 5-5M4 20h16',
  upload: 'M12 20V9M7 14l5-5 5 5M4 4h16',
  ban: 'M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18ZM5.6 5.6l12.8 12.8',
  bookmark: 'M6 3h12v18l-6-4-6 4z',
  thermo: 'M14 14.8V5a2 2 0 1 0-4 0v9.8a4 4 0 1 0 4 0Z',
  info: 'M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18ZM12 11v5M12 8h.01',
};
export function Icon({ name, className = 'h-5 w-5', filled = false }: { name: keyof typeof PATHS | string; className?: string; filled?: boolean }) {
  return (
    <svg viewBox="0 0 24 24" className={className} fill={filled ? 'currentColor' : 'none'} stroke="currentColor" strokeWidth={1.7} strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <path d={PATHS[name] ?? ''} />
    </svg>
  );
}

// ---------- Imágenes de prendas (Blob en IndexedDB → object URL) ----------
const urlCache = new Map<string, string>();
export function GarmentImg({ imageId, alt, className = '', full = false, color }: { imageId?: ID; alt: string; className?: string; full?: boolean; color?: string }) {
  const { repo } = useSession();
  const key = imageId ? `${imageId}:${full ? 'f' : 't'}` : '';
  const [url, setUrl] = useState<string | null>(key ? urlCache.get(key) ?? null : null);
  useEffect(() => {
    let alive = true;
    if (!imageId) { setUrl(null); return; }
    if (urlCache.has(key)) { setUrl(urlCache.get(key)!); return; }
    repo.image(imageId).then((img) => {
      if (!img || !alive) return;
      const u = URL.createObjectURL(full ? img.full : img.thumb);
      urlCache.set(key, u);
      setUrl(u);
    });
    return () => { alive = false; };
  }, [imageId, key, full, repo]);
  if (!imageId || !url)
    return (
      <div className={`flex items-center justify-center bg-sand-100 ${className}`} aria-label={alt}>
        {imageId ? <div className="skeleton h-full w-full" /> : <div className="h-1/3 w-1/3 rounded-xl opacity-80" style={{ background: COLORS[color ?? '']?.hex ?? '#d6cbb9' }} />}
      </div>
    );
  return <img src={url} alt={alt} className={`object-cover ${className}`} loading="lazy" draggable={false} />;
}

export function ColorDot({ color, className = 'h-3.5 w-3.5' }: { color: string; className?: string }) {
  return <span className={`inline-block shrink-0 rounded-full ring-1 ring-black/10 ${className}`} style={{ background: COLORS[color]?.hex ?? '#ccc' }} title={COLORS[color]?.label} />;
}

// ---------- Estructura ----------
export function PageHeader({ eyebrow, title, action, back }: { eyebrow?: string; title: string; action?: ReactNode; back?: string }) {
  return (
    <header className="mb-5 flex items-end justify-between gap-3">
      <div className="min-w-0">
        {back && (
          <a href={`#${back}`} className="-ml-1 mb-1 inline-flex items-center gap-1 text-sm text-ink-soft hover:text-ink"><Icon name="back" className="h-4 w-4" />Volver</a>
        )}
        {eyebrow && <div className="eyebrow mb-1">{eyebrow}</div>}
        <h1 className="truncate text-[28px] leading-tight sm:text-4xl">{title}</h1>
      </div>
      {action && <div className="shrink-0">{action}</div>}
    </header>
  );
}

export function Empty({ icon, title, text, action }: { icon: string; title: string; text: string; action?: ReactNode }) {
  return (
    <div className="card flex flex-col items-center px-6 py-12 text-center">
      <div className="mb-3 rounded-full bg-sand-100 p-4 text-clay"><Icon name={icon} className="h-7 w-7" /></div>
      <h3 className="text-xl">{title}</h3>
      <p className="mt-1 max-w-sm text-sm text-ink-soft">{text}</p>
      {action && <div className="mt-5">{action}</div>}
    </div>
  );
}

export function Spinner({ label = 'Cargando…' }: { label?: string }) {
  return (
    <div className="flex items-center justify-center gap-3 py-16 text-ink-soft" role="status">
      <span className="h-5 w-5 animate-spin rounded-full border-2 border-sand-300 border-t-clay" />
      <span className="text-sm">{label}</span>
    </div>
  );
}

// ---------- Diálogos ----------
export function Modal({ open, onClose, title, children, wide = false }: { open: boolean; onClose: () => void; title: string; children: ReactNode; wide?: boolean }) {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    if (!open) return;
    const prev = document.activeElement as HTMLElement | null;
    const k = (e: KeyboardEvent) => { if (e.key === 'Escape') onClose(); };
    window.addEventListener('keydown', k);
    document.body.style.overflow = 'hidden';
    setTimeout(() => ref.current?.querySelector<HTMLElement>('input,select,textarea,button')?.focus(), 30);
    return () => { window.removeEventListener('keydown', k); document.body.style.overflow = ''; prev?.focus?.(); };
  }, [open, onClose]);
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-ink/40 backdrop-blur-[2px] sm:items-center" onMouseDown={(e) => e.target === e.currentTarget && onClose()}>
      <div ref={ref} role="dialog" aria-modal="true" aria-label={title} className={`fade-up max-h-[92vh] w-full overflow-y-auto rounded-t-3xl bg-paper p-5 shadow-2xl sm:rounded-3xl ${wide ? 'sm:max-w-2xl' : 'sm:max-w-md'}`}>
        <div className="mb-4 flex items-center justify-between">
          <h2 className="text-2xl">{title}</h2>
          <button className="btn-ghost btn-sm !px-2" onClick={onClose} aria-label="Cerrar"><Icon name="x" /></button>
        </div>
        {children}
      </div>
    </div>
  );
}

export function useConfirm() {
  const [state, setState] = useState<{ text: string; danger: boolean; resolve: (v: boolean) => void } | null>(null);
  const ask = (text: string, danger = false) => new Promise<boolean>((resolve) => setState({ text, danger, resolve }));
  const close = (v: boolean) => { state?.resolve(v); setState(null); };
  const dialog = (
    <Modal open={!!state} onClose={() => close(false)} title="Confirmar">
      <p className="text-sm text-ink-soft">{state?.text}</p>
      <div className="mt-6 flex justify-end gap-2">
        <button className="btn-outline" onClick={() => close(false)}>Cancelar</button>
        <button className={state?.danger ? 'btn-danger' : 'btn-primary'} onClick={() => close(true)}>Confirmar</button>
      </div>
    </Modal>
  );
  return { ask, dialog };
}

// ---------- Controles ----------
export function Chips<T extends string>({ options, value, onChange, multiple = false, label }: {
  options: Array<{ value: T; label: string; dot?: string }>; value: T[]; onChange: (v: T[]) => void; multiple?: boolean; label?: string;
}) {
  return (
    <div role="group" aria-label={label} className="flex flex-wrap gap-2">
      {options.map((o) => {
        const on = value.includes(o.value);
        return (
          <button type="button" key={o.value} aria-pressed={on} className={`chip ${on ? 'chip-on' : ''}`}
            onClick={() => onChange(multiple ? (on ? value.filter((v) => v !== o.value) : [...value, o.value]) : [o.value])}>
            {o.dot && <ColorDot color={o.dot} className="h-3 w-3" />}{o.label}
          </button>
        );
      })}
    </div>
  );
}

export function Stars({ value, onChange, size = 'h-6 w-6' }: { value: number; onChange?: (n: number) => void; size?: string }) {
  return (
    <div className="flex gap-0.5" role={onChange ? 'radiogroup' : undefined} aria-label="Calificación">
      {[1, 2, 3, 4, 5].map((n) => (
        <button key={n} type="button" disabled={!onChange} onClick={() => onChange?.(n)} aria-label={`${n} de 5`} role={onChange ? 'radio' : undefined} aria-checked={value === n}
          className={`${n <= value ? 'text-clay' : 'text-sand-300'} ${onChange ? 'hover:scale-110' : ''} transition`}>
          <Icon name="star" filled={n <= value} className={size} />
        </button>
      ))}
    </div>
  );
}

export function Field({ label, children, hint }: { label: string; children: ReactNode; hint?: string }) {
  return (
    <label className="block">
      <span className="field-label">{label}</span>
      {children}
      {hint && <span className="mt-1 block text-xs text-ink-soft">{hint}</span>}
    </label>
  );
}

export function Segmented<T extends string>({ options, value, onChange, label }: { options: Array<{ value: T; label: string }>; value: T; onChange: (v: T) => void; label: string }) {
  return (
    <div role="radiogroup" aria-label={label} className="inline-flex rounded-full bg-sand-100 p-1">
      {options.map((o) => (
        <button key={o.value} type="button" role="radio" aria-checked={value === o.value} onClick={() => onChange(o.value)}
          className={`rounded-full px-3.5 py-1.5 text-xs font-medium transition ${value === o.value ? 'bg-white text-ink shadow-sm' : 'text-ink-soft'}`}>{o.label}</button>
      ))}
    </div>
  );
}

export function StatusBadge({ status }: { status: string }) {
  const map: Record<string, string> = {
    disponible: 'bg-moss/10 text-moss', usada: 'bg-amber-100 text-amber-800', lavanderia: 'bg-sky-100 text-sky-800',
    reparacion: 'bg-rose/10 text-rose', guardada: 'bg-stone-200 text-stone-700', retirada: 'bg-stone-100 text-stone-500',
  };
  const label: Record<string, string> = { disponible: 'Disponible', usada: 'Usada', lavanderia: 'Lavandería', reparacion: 'Reparación', guardada: 'Guardada', retirada: 'Retirada' };
  return <span className={`inline-flex items-center rounded-full px-2.5 py-0.5 text-[11px] font-semibold ${map[status] ?? ''}`}>{label[status] ?? status}</span>;
}
