// Panel de clima: muestra el pronóstico de la API o, si falla / no hay ubicación / se prefiere,
// un selector manual. Siempre indica la procedencia del dato.
import { useEffect, useState } from 'react';
import type { ISODate, WeatherSnapshot } from '../../domain/types';
import { manualWeather } from '../../domain/weather';
import type { WeatherState } from '../hooks';
import { Icon, Segmented } from './ui';

export function weatherIcon(c: WeatherSnapshot['condition']) {
  return c === 'lluvioso' ? 'rain' : c === 'nublado' ? 'cloud' : 'sun';
}

export function WeatherSummary({ w }: { w: WeatherSnapshot }) {
  return (
    <div className="flex items-center gap-3">
      <div className="rounded-2xl bg-sand-100 p-2.5 text-clay"><Icon name={weatherIcon(w.condition)} className="h-7 w-7" /></div>
      <div>
        <div className="text-2xl font-semibold tabular-nums leading-none">{Math.round(w.tempC)}°<span className="ml-1 text-sm font-normal text-ink-soft">efectiva</span></div>
        <div className="mt-1 text-xs text-ink-soft">
          {w.description}
          {w.tempMin !== undefined && w.tempMax !== undefined && ` · ${Math.round(w.tempMin)}° / ${Math.round(w.tempMax)}°`}
          {w.source === 'api' && ` · lluvia ${w.precipProbability}%`}
          {w.feelsLikeC !== undefined && ` · sensación ${Math.round(w.feelsLikeC)}°`}
        </div>
      </div>
    </div>
  );
}

export function SourceBadge({ source }: { source: 'api' | 'manual' | 'none' }) {
  const t = { api: 'Fuente: Open-Meteo', manual: 'Fuente: ingreso manual', none: 'Sin clima' }[source];
  return <span data-testid="weather-source" className={`rounded-full px-2.5 py-0.5 text-[11px] font-semibold ${source === 'api' ? 'bg-moss/10 text-moss' : source === 'manual' ? 'bg-amber-100 text-amber-800' : 'bg-stone-100 text-stone-500'}`}>{t}</span>;
}

/** Selector de clima con modo manual. Llama a `onChange` con el clima efectivo a usar. */
export function WeatherPicker({ date, api, onChange, onRetry }: { date: ISODate; api: WeatherState; onChange: (w: WeatherSnapshot | null) => void; onRetry: () => void }) {
  const [mode, setMode] = useState<'api' | 'manual'>('api');
  const [temp, setTemp] = useState(16);
  const [cond, setCond] = useState<WeatherSnapshot['condition']>('nublado');
  const [feels, setFeels] = useState<string>('');
  const apiFailed = api.status === 'error';
  const effectiveMode = apiFailed ? 'manual' : mode;

  useEffect(() => {
    if (effectiveMode === 'api') onChange(api.status === 'ok' ? api.snapshot : null);
    else onChange(manualWeather(date, temp, cond, feels === '' ? undefined : Number(feels)));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [effectiveMode, api, temp, cond, feels, date]);

  return (
    <div className="card p-4" data-testid="weather-picker">
      <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
        <div className="eyebrow">Clima</div>
        {!apiFailed && <Segmented label="Fuente del clima" value={mode} onChange={setMode} options={[{ value: 'api', label: 'Pronóstico' }, { value: 'manual', label: 'Manual' }]} />}
      </div>
      {effectiveMode === 'api' && api.status === 'loading' && <div className="skeleton h-14 rounded-2xl" aria-label="Cargando clima" />}
      {effectiveMode === 'api' && api.status === 'ok' && (
        <div className="flex flex-wrap items-center justify-between gap-2"><WeatherSummary w={api.snapshot} /><SourceBadge source="api" /></div>
      )}
      {effectiveMode === 'manual' && (
        <div className="space-y-3">
          {apiFailed && (
            <div className="flex items-start gap-2 rounded-2xl bg-amber-50 p-3 text-xs text-amber-900" role="alert">
              <Icon name="info" className="h-4 w-4 shrink-0" />
              <div className="flex-1">{api.message} Puedes ingresar el clima manualmente; las recomendaciones siguen funcionando.</div>
              {api.kind !== 'sin_ubicacion' && api.kind !== 'fuera_de_rango' && <button className="font-semibold underline" onClick={onRetry}>Reintentar</button>}
            </div>
          )}
          <div className="flex items-center gap-3">
            <Icon name="thermo" className="h-5 w-5 text-clay" />
            <input aria-label="Temperatura aproximada" type="range" min={-5} max={38} value={temp} onChange={(e) => setTemp(Number(e.target.value))} className="flex-1 accent-[#8a5a3b]" />
            <span className="w-12 text-right text-lg font-semibold tabular-nums" data-testid="manual-temp">{temp}°</span>
          </div>
          <div className="flex flex-wrap items-center justify-between gap-2">
            <Segmented label="Condición" value={cond} onChange={setCond} options={[{ value: 'soleado', label: 'Soleado' }, { value: 'nublado', label: 'Nublado' }, { value: 'lluvioso', label: 'Lluvioso' }]} />
            <label className="flex items-center gap-2 text-xs text-ink-soft">
              Sensación térmica
              <input type="number" inputMode="numeric" placeholder="opc." value={feels} onChange={(e) => setFeels(e.target.value)} className="input !w-20 !py-1.5" aria-label="Sensación térmica opcional" />
            </label>
          </div>
          <SourceBadge source="manual" />
        </div>
      )}
    </div>
  );
}
