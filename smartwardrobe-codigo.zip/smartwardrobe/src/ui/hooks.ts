// Hooks de integración entre la interfaz y el dominio.
import { useEffect, useState } from 'react';
import { EVENTS } from '../domain/catalog';
import { defaultRecommender } from '../domain/recommender/engine';
import type { RecommendationInput, RecommendationResult } from '../domain/recommender/types';
import { today } from '../domain/dates';
import type { ISODate, UserPreferences, WeatherSnapshot } from '../domain/types';
import { LocalStorageCache, WeatherError, WeatherService } from '../domain/weather';
import type { ProfileData } from './store';

export const weatherService = new WeatherService((url, init) => fetch(url, init), new LocalStorageCache());

export type WeatherState =
  | { status: 'loading' }
  | { status: 'ok'; snapshot: WeatherSnapshot }
  | { status: 'error'; message: string; kind: string };

/** Pronóstico de la API para una fecha. Nunca lanza: devuelve un estado de error para activar el modo manual. */
export function useForecast(location: UserPreferences['location'], date: ISODate, nonce = 0): WeatherState {
  const [state, setState] = useState<WeatherState>({ status: 'loading' });
  useEffect(() => {
    let alive = true;
    setState({ status: 'loading' });
    weatherService
      .forecast(location, date)
      .then((snapshot) => alive && setState({ status: 'ok', snapshot }))
      .catch((e) => alive && setState({ status: 'error', message: e instanceof Error ? e.message : 'Error de clima', kind: e instanceof WeatherError ? e.kind : 'red' }));
    return () => { alive = false; };
  }, [location?.latitude, location?.longitude, date, nonce]);
  return state;
}

export function buildInput(data: ProfileData, opts: { date: ISODate; eventKey: string; weather: WeatherSnapshot | null; includeAccessories?: boolean; respectReservations?: boolean; limit?: number }): RecommendationInput {
  const ev = EVENTS[opts.eventKey] ?? EVENTS.diario;
  return {
    garments: data.garments,
    date: opts.date,
    today: today(),
    event: { key: opts.eventKey, ...ev },
    weather: opts.weather,
    prefs: data.prefs,
    wears: data.wears,
    ratings: data.ratings,
    blocked: data.blocked,
    planned: data.planned,
    respectReservations: opts.respectReservations ?? true,
    includeAccessories: opts.includeAccessories ?? true,
    limit: opts.limit,
  };
}

export function recommend(data: ProfileData, opts: Parameters<typeof buildInput>[1]): RecommendationResult {
  return defaultRecommender.recommend(buildInput(data, opts));
}
