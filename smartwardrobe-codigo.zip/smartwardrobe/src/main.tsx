import { createRoot } from 'react-dom/client';
import { App } from './ui/App';

createRoot(document.getElementById('root')!).render(<App />);

// Service worker (PWA): solo en contextos seguros (HTTPS o localhost).
if ('serviceWorker' in navigator && window.isSecureContext && !navigator.webdriver) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('./sw.js').catch(() => { /* la app funciona igual sin SW */ });
  });
}
