// Máquina de estados de las prendas.
// Regla obligatoria del producto: solo 'disponible' (y, si el usuario lo habilita, 'usada')
// es elegible para recomendaciones. Esta función es la única fuente de verdad de esa regla.
import type { GarmentStatus } from './types';

export const TRANSITIONS: Record<GarmentStatus, GarmentStatus[]> = {
  disponible: ['usada', 'lavanderia', 'reparacion', 'guardada', 'retirada'],
  usada: ['disponible', 'lavanderia', 'reparacion', 'guardada', 'retirada'],
  lavanderia: ['disponible', 'reparacion', 'retirada'],
  reparacion: ['disponible', 'lavanderia', 'retirada'],
  guardada: ['disponible', 'lavanderia', 'retirada'],
  retirada: ['disponible', 'guardada'],
};

/** Estados que nunca pueden aparecer en un outfit recomendado ni planificado como disponible. */
export const BLOCKING_STATUSES: ReadonlySet<GarmentStatus> = new Set(['lavanderia', 'reparacion', 'guardada', 'retirada']);

export function canTransition(from: GarmentStatus, to: GarmentStatus): boolean {
  return TRANSITIONS[from].includes(to);
}

export class InvalidTransitionError extends Error {
  constructor(public from: GarmentStatus, public to: GarmentStatus) {
    super(`Transición no permitida: ${from} → ${to}`);
  }
}

export interface TransitionInput {
  to: GarmentStatus;
  reason?: string; // obligatorio para 'reparacion'
  note?: string;
}

/** Valida una transición y devuelve qué efectos de mantenimiento implica. */
export function planTransition(from: GarmentStatus, input: TransitionInput): {
  openMaintenance?: 'lavanderia' | 'reparacion';
  closeMaintenance: boolean;
} {
  if (from === input.to) throw new InvalidTransitionError(from, input.to);
  if (!canTransition(from, input.to)) throw new InvalidTransitionError(from, input.to);
  if (input.to === 'reparacion' && !input.reason?.trim()) throw new Error('Indica el motivo de la reparación.');
  const leavingMaintenance = from === 'lavanderia' || from === 'reparacion';
  const entering = input.to === 'lavanderia' || input.to === 'reparacion' ? input.to : undefined;
  return { openMaintenance: entering, closeMaintenance: leavingMaintenance };
}

/** Elegibilidad para recomendaciones. Regla estricta (filtro), nunca una penalización. */
export function isRecommendable(status: GarmentStatus, allowUsedPending: boolean): boolean {
  if (status === 'disponible') return true;
  if (status === 'usada') return allowUsedPending;
  return false;
}
