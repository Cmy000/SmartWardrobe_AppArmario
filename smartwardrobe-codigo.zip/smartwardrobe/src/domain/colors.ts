// Compatibilidad cromática basada en reglas de teoría del color (rueda HSL).
// Es deliberadamente simple y explicable; cada valor es un parámetro ajustable.
import { COLORS } from './catalog';
import type { Garment } from './types';

export const COLOR_RULES = {
  neutralWithAny: 0.9,
  sameColor: 0.75, // monocromático
  analogous: 0.8, // diferencia de tono ≤ 30°
  complementary: 0.7, // 150°–180°
  intermediate: 0.55, // 30°–90°
  clash: 0.4, // 90°–150° entre dos colores saturados
  maxAccentColors: 2, // más colores no neutros que esto penaliza
  tooManyColorsPenalty: 0.15,
  multiplePatternsFactor: 0.75, // más de una prenda estampada
};

export type ColorRelation = 'neutral' | 'mismo' | 'analogo' | 'complementario' | 'intermedio' | 'choque';

export function hueDistance(a: number, b: number): number {
  const d = Math.abs(a - b) % 360;
  return d > 180 ? 360 - d : d;
}

export function colorPair(a: string, b: string): { score: number; relation: ColorRelation } {
  const ca = COLORS[a];
  const cb = COLORS[b];
  if (!ca || !cb) return { score: 0.6, relation: 'intermedio' }; // color desconocido: neutralidad prudente
  if (ca.neutral || cb.neutral) return { score: COLOR_RULES.neutralWithAny, relation: 'neutral' };
  if (a === b) return { score: COLOR_RULES.sameColor, relation: 'mismo' };
  const d = hueDistance(ca.hue ?? 0, cb.hue ?? 0);
  if (d <= 30) return { score: COLOR_RULES.analogous, relation: 'analogo' };
  if (d >= 150) return { score: COLOR_RULES.complementary, relation: 'complementario' };
  if (d < 90) return { score: COLOR_RULES.intermediate, relation: 'intermedio' };
  return { score: COLOR_RULES.clash, relation: 'choque' };
}

export interface OutfitColorResult {
  score: number;
  relations: ColorRelation[];
  accentColors: string[];
  patterned: number;
  summary: string;
}

/** Puntuación cromática del conjunto: promedio de pares + penalizaciones globales. */
export function outfitColor(items: Pick<Garment, 'colorPrimary' | 'pattern'>[]): OutfitColorResult {
  const relations: ColorRelation[] = [];
  let sum = 0;
  let n = 0;
  for (let i = 0; i < items.length; i++)
    for (let j = i + 1; j < items.length; j++) {
      const r = colorPair(items[i].colorPrimary, items[j].colorPrimary);
      sum += r.score;
      n++;
      relations.push(r.relation);
    }
  let score = n ? sum / n : 1;
  const accentColors = [...new Set(items.map((g) => g.colorPrimary).filter((c) => COLORS[c] && !COLORS[c].neutral))];
  if (accentColors.length > COLOR_RULES.maxAccentColors) score -= COLOR_RULES.tooManyColorsPenalty * (accentColors.length - COLOR_RULES.maxAccentColors);
  const patterned = items.filter((g) => g.pattern !== 'liso').length;
  if (patterned > 1) score *= COLOR_RULES.multiplePatternsFactor;
  score = Math.max(0, Math.min(1, score));

  let summary: string;
  if (accentColors.length === 0) summary = 'paleta neutra';
  else if (accentColors.length === 1) summary = `base neutra con acento ${COLORS[accentColors[0]].label.toLowerCase()}`;
  else if (relations.includes('choque')) summary = 'colores con contraste fuerte';
  else if (relations.includes('complementario')) summary = 'colores complementarios';
  else summary = 'colores armónicos';
  if (patterned > 1) summary += ', con más de un estampado';
  return { score, relations, accentColors, patterned, summary };
}
