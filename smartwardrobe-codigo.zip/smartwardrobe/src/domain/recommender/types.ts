// Contratos del motor. `Recommender` es la interfaz que permitirá sustituir o combinar el
// motor de reglas con modelos futuros (content-based, ranking aprendido, embeddings de imágenes)
// sin cambiar la interfaz de usuario.
import type {
  BlockedCombo, Garment, ID, ISODate, OutfitRating, PlannedOutfit, ScoreWeights, Style, UserPreferences, WearRecord, WeatherSnapshot,
} from '../types';

export interface EventContext {
  key: string;
  label: string;
  formality: number;
  strict: boolean;
  preferredStyles: Style[];
}

export interface RecommendationInput {
  garments: Garment[]; // ya filtradas por perfil
  date: ISODate;
  today: ISODate;
  event: EventContext;
  weather: WeatherSnapshot | null;
  prefs: Pick<UserPreferences, 'preferredStyles' | 'avoidColors' | 'allowUsedPending' | 'repeatWindowDays' | 'minCoherence'> & { weights: ScoreWeights };
  wears: WearRecord[];
  ratings: OutfitRating[];
  blocked: BlockedCombo[];
  planned: PlannedOutfit[];
  respectReservations: boolean;
  includeAccessories: boolean;
  limit?: number;
}

export type ComponentKey = keyof ScoreWeights;

export interface ExplanationLine {
  factor: ComponentKey | 'disponibilidad' | 'plantilla';
  text: string;
}

export interface ScoredOutfit {
  itemIds: ID[];
  templateId: string;
  score: number; // 0..1
  coherence: number;
  components: Record<ComponentKey, number>;
  explanation: ExplanationLine[];
}

export interface RecommendationResult {
  outfits: ScoredOutfit[];
  eligibleCount: number;
  excluded: Record<string, number>;
  candidatesEvaluated: number;
  warnings: string[];
}

export interface Recommender {
  readonly id: string;
  recommend(input: RecommendationInput): RecommendationResult;
}
