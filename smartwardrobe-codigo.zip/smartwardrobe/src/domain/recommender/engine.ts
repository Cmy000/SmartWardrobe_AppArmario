// Motor de recomendación basado en reglas y puntuaciones (v1, explicable).
//
// Flujo:
//   1. hardFilter        — exclusión estricta (estado, reservas, temperatura, formalidad obligatoria, colores vetados)
//   2. features          — puntuación unaria de cada prenda elegible
//   3. selectTemplates   — plantillas válidas según el clima (capa exterior obligatoria/prohibida)
//   4. pools top-K       — poda: solo las K mejores prendas por posición
//   5. beamSearch        — combina posiciones manteniendo los B mejores parciales por coherencia
//   6. scoreOutfit       — suma ponderada de 9 componentes normalizados (0..1)
//   7. reglas de conjunto— umbral de coherencia, combinaciones bloqueadas, repeticiones recientes
//   8. selección diversa — evita devolver variantes casi idénticas
//   9. explain           — frases construidas solo a partir de los valores calculados
//
// Complejidad: con P posiciones, K candidatas por posición y haz B, se evalúan O(P·B·K)
// parciales en lugar de las ∏|pool| combinaciones del producto cartesiano.
import { styleCompatibility } from '../catalog';
import { outfitColor } from '../colors';
import { daysBetween } from '../dates';
import type { Garment, ScoreWeights, Slot } from '../types';
import { ENGINE, TEMPLATES, type OutfitTemplate } from './config';
import { explain } from './explain';
import { computeFeatures, hardFilter, indexItemRatings, isRainy, slotOf, type GarmentFeatures } from './features';
import type { ComponentKey, RecommendationInput, RecommendationResult, Recommender, ScoredOutfit } from './types';

export const comboKey = (ids: string[]) => [...ids].sort().join('|');

export function jaccard(a: string[], b: string[]): number {
  const sa = new Set(a);
  const sb = new Set(b);
  let inter = 0;
  for (const x of sa) if (sb.has(x)) inter++;
  const union = sa.size + sb.size - inter;
  return union ? inter / union : 0;
}

/** Plantillas aplicables al clima. Devuelve además si se exigió capa exterior. */
export function selectTemplates(input: Pick<RecommendationInput, 'weather'>, pools: Map<Slot, Garment[]>): { templates: OutfitTemplate[]; outerRequired: boolean; warnings: string[] } {
  const w = input.weather;
  const warnings: string[] = [];
  const hasOuter = (pools.get('outer')?.length ?? 0) > 0;
  let outerRequired = !!w && (w.tempC < ENGINE.coldThreshold || isRainy(w));
  const outerForbidden = !!w && w.tempC > ENGINE.warmThreshold && !isRainy(w);
  if (outerRequired && !hasOuter) {
    warnings.push('Hace frío o llueve, pero no tienes chaquetas o abrigos disponibles: se muestran outfits sin capa exterior.');
    outerRequired = false;
  }
  const templates = TEMPLATES.filter((t) => {
    const hasOuterSlot = t.slots.includes('outer');
    if (outerRequired && !hasOuterSlot) return false;
    if (outerForbidden && hasOuterSlot) return false;
    return t.slots.every((s) => (pools.get(s)?.length ?? 0) > 0);
  });
  return { templates, outerRequired, warnings };
}

function pairCoherence(a: Garment, b: Garment): number {
  // Coherencia de un par usada para guiar la búsqueda (mismas reglas que la puntuación final).
  const c = outfitColor([a, b]).score;
  return (c + styleCompatibility(a.style, b.style)) / 2;
}

function meanStyle(items: Garment[]): number {
  let s = 0, n = 0;
  for (let i = 0; i < items.length; i++) for (let j = i + 1; j < items.length; j++) { s += styleCompatibility(items[i].style, items[j].style); n++; }
  return n ? s / n : 1;
}

function weightedTotal(c: Record<ComponentKey, number>, w: ScoreWeights): number {
  let num = 0, den = 0;
  for (const k of Object.keys(w) as ComponentKey[]) { num += w[k] * c[k]; den += w[k]; }
  return den ? num / den : 0;
}

export class RuleBasedRecommender implements Recommender {
  readonly id = 'reglas-v1';

  recommend(input: RecommendationInput): RecommendationResult {
    const warnings: string[] = [];
    // Prendas reservadas en planes del mismo día.
    const reservedIds = new Set<string>();
    if (input.respectReservations) for (const p of input.planned) if (p.date === input.date) p.itemIds.forEach((id) => reservedIds.add(id));

    // 1. Filtro estricto
    const f = hardFilter(input.garments, { event: input.event, weather: input.weather, prefs: input.prefs, reservedIds });
    if (!input.weather) warnings.push('Sin datos de clima: no se aplicó el filtro de temperatura.');

    // 2. Características unarias
    const itemRatings = indexItemRatings(input.ratings);
    const maxWears = new Map<Slot, number>();
    for (const g of input.garments) maxWears.set(slotOf(g), Math.max(maxWears.get(slotOf(g)) ?? 0, g.wearCount));
    const feats = new Map<string, GarmentFeatures>();
    for (const g of f.eligible)
      feats.set(g.id, computeFeatures(g, { event: input.event, weather: input.weather, prefs: input.prefs, today: input.today, maxWearsInSlot: maxWears.get(slotOf(g)) ?? 0, itemRatings }));

    const w = input.prefs.weights;
    const unary = (g: Garment) => {
      const x = feats.get(g.id)!;
      return (w.event * x.event + w.weather * x.weather + w.preference * x.preference + w.rotation * x.rotation + w.recency * x.recency + w.rating * x.rating) /
        (w.event + w.weather + w.preference + w.rotation + w.recency + w.rating || 1);
    };

    // 3–4. Pools por posición (poda top-K)
    const pools = new Map<Slot, Garment[]>();
    for (const g of f.eligible) (pools.get(slotOf(g)) ?? pools.set(slotOf(g), []).get(slotOf(g))!).push(g);
    for (const [slot, list] of pools) pools.set(slot, list.sort((a, b) => unary(b) - unary(a)).slice(0, ENGINE.topKPerSlot));
    const { templates, outerRequired, warnings: tw } = selectTemplates(input, pools);
    warnings.push(...tw);

    // Historial reciente para diversidad y prevención de repeticiones.
    const recentWears = input.wears.filter((x) => { const d = daysBetween(x.date, input.date); return d >= 0 && d <= input.prefs.repeatWindowDays; });
    const recentKeys = new Set(recentWears.map((x) => comboKey(x.itemIds)));
    const ratingByCombo = new Map<string, number>();
    for (const r of [...input.ratings].sort((a, b) => a.at.localeCompare(b.at))) ratingByCombo.set(r.comboKey, r.rating);
    const blocked = input.blocked.map((b) => b.itemIds);

    // 5–7. Búsqueda por haz + puntuación + reglas de conjunto
    const byKey = new Map<string, ScoredOutfit>();
    let evaluated = 0;
    for (const t of templates) {
      let beam: Garment[][] = [[]];
      for (const slot of t.slots) {
        const next: Array<{ items: Garment[]; s: number }> = [];
        for (const partial of beam)
          for (const g of pools.get(slot) ?? []) {
            const items = [...partial, g];
            let coh = 0;
            for (const p of partial) coh += pairCoherence(p, g);
            const s = (partial.length ? coh / partial.length : 1) * 0.6 + unary(g) * 0.4;
            next.push({ items, s });
            evaluated++;
          }
        next.sort((a, b) => b.s - a.s);
        beam = next.slice(0, ENGINE.beamWidth).map((x) => x.items);
      }
      for (const items of beam) {
        const ids = items.map((g) => g.id);
        const key = comboKey(ids);
        if (byKey.has(key)) continue;
        if (blocked.some((b) => b.every((id) => ids.includes(id)))) continue; // combinación vetada
        if (recentKeys.has(key)) continue; // repetición exacta dentro de la ventana configurada
        const scored = this.score(items, t.id, input, feats, recentWears, ratingByCombo, outerRequired);
        if (scored.coherence < input.prefs.minCoherence) continue; // la rotación nunca rescata un conjunto incoherente
        byKey.set(key, scored);
      }
    }

    // Accesorios opcionales: se añaden solo si no reducen la coherencia de forma apreciable.
    let outfits = [...byKey.values()].sort((a, b) => b.score - a.score);
    if (input.includeAccessories && (pools.get('accessory')?.length ?? 0) > 0) {
      const byId = new Map(f.eligible.map((g) => [g.id, g]));
      outfits = outfits.map((o) => {
        const base = o.itemIds.map((id) => byId.get(id)!);
        let best: ScoredOutfit | null = null;
        for (const acc of pools.get('accessory')!) {
          const items = [...base, acc];
          const s = this.score(items, o.templateId, input, feats, recentWears, ratingByCombo, outerRequired);
          if (s.coherence >= o.coherence - 0.03 && s.coherence >= input.prefs.minCoherence && (!best || s.score > best.score)) best = s;
        }
        return best ?? o;
      });
    }

    // 8. Selección final con variedad
    const limit = input.limit ?? ENGINE.results;
    const chosen: ScoredOutfit[] = [];
    for (const o of outfits) {
      if (chosen.length >= limit) break;
      if (chosen.some((c) => jaccard(c.itemIds, o.itemIds) > ENGINE.maxResultOverlap)) continue;
      chosen.push(o);
    }
    for (const o of outfits) { if (chosen.length >= limit) break; if (!chosen.includes(o)) chosen.push(o); }
    chosen.sort((a, b) => b.score - a.score);

    if (f.eligible.length === 0) warnings.push('No hay prendas elegibles con los filtros actuales.');
    else if (templates.length === 0) warnings.push('Faltan prendas para completar un outfit (p. ej. calzado o parte inferior disponibles).');
    else if (chosen.length === 0) warnings.push('Ninguna combinación superó el umbral de coherencia o todas están bloqueadas o repetidas.');

    return { outfits: chosen, eligibleCount: f.eligible.length, excluded: f.excluded, candidatesEvaluated: evaluated, warnings };
  }

  private score(
    items: Garment[], templateId: string, input: RecommendationInput, feats: Map<string, GarmentFeatures>,
    recentWears: RecommendationInput['wears'], ratingByCombo: Map<string, number>, outerRequired: boolean,
  ): ScoredOutfit {
    const mean = (k: keyof GarmentFeatures) => items.reduce((a, g) => a + (feats.get(g.id)![k] as number), 0) / items.length;
    const color = outfitColor(items);
    const style = meanStyle(items);
    const ids = items.map((g) => g.id);
    let maxOverlap = 0;
    let overlapDays: number | null = null;
    for (const wr of recentWears) {
      const j = jaccard(ids, wr.itemIds);
      if (j > maxOverlap) { maxOverlap = j; overlapDays = daysBetween(wr.date, input.date); }
    }
    const exactRating = ratingByCombo.get(comboKey(ids));
    const components: Record<ComponentKey, number> = {
      color: color.score,
      style,
      event: mean('event'),
      weather: mean('weather'),
      preference: mean('preference'),
      rotation: mean('rotation'),
      recency: mean('recency'),
      diversity: 1 - maxOverlap,
      rating: exactRating !== undefined ? (exactRating - 1) / 4 : mean('rating'),
    };
    const coherence = (color.score + style) / 2;
    const score = weightedTotal(components, input.prefs.weights);
    const explanation = explain({ items, feats, components, color, input, outerRequired, maxOverlap, overlapDays, exactRating, templateId });
    return { itemIds: ids, templateId, score, coherence, components, explanation };
  }
}

export const defaultRecommender: Recommender = new RuleBasedRecommender();
