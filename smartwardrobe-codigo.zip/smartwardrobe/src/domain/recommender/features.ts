// Etapa 1 (filtrado estricto) y características por prenda (puntuaciones unarias).
import { CATEGORIES } from '../catalog';
import { daysBetween } from '../dates';
import { isRecommendable } from '../status';
import type { Garment, OutfitRating, Slot, UserPreferences, WeatherSnapshot } from '../types';
import { ENGINE } from './config';
import type { EventContext } from './types';

export type ExclusionReason = 'estado' | 'temperatura' | 'formalidad' | 'color_evitado' | 'reservada';

export interface FilterResult {
  eligible: Garment[];
  excluded: Record<ExclusionReason, number>;
  excludedIds: Map<string, ExclusionReason>;
}

export function slotOf(g: Pick<Garment, 'category'>): Slot {
  return CATEGORIES[g.category].slot;
}

export function isRainy(w: WeatherSnapshot | null): boolean {
  return !!w && (w.condition === 'lluvioso' || w.precipProbability >= ENGINE.rainThreshold);
}

/**
 * Filtro duro. El orden de las comprobaciones define qué motivo se registra primero.
 * Ninguna prenda excluida aquí puede volver a entrar en etapas posteriores.
 */
export function hardFilter(
  garments: Garment[],
  ctx: { event: EventContext; weather: WeatherSnapshot | null; prefs: Pick<UserPreferences, 'avoidColors' | 'allowUsedPending'>; reservedIds: Set<string> },
): FilterResult {
  const excluded: Record<ExclusionReason, number> = { estado: 0, temperatura: 0, formalidad: 0, color_evitado: 0, reservada: 0 };
  const excludedIds = new Map<string, ExclusionReason>();
  const eligible: Garment[] = [];
  const t = ctx.weather?.tempC;
  for (const g of garments) {
    let reason: ExclusionReason | null = null;
    if (!isRecommendable(g.status, ctx.prefs.allowUsedPending)) reason = 'estado';
    else if (ctx.reservedIds.has(g.id)) reason = 'reservada';
    else if (t !== undefined && (t < g.tempMin - ENGINE.tempTolerance || t > g.tempMax + ENGINE.tempTolerance)) reason = 'temperatura';
    else if (ctx.event.strict && Math.abs(g.formality - ctx.event.formality) > ENGINE.strictFormalityDelta) reason = 'formalidad';
    else if (ctx.prefs.avoidColors.includes(g.colorPrimary)) reason = 'color_evitado';
    if (reason) {
      excluded[reason]++;
      excludedIds.set(g.id, reason);
    } else eligible.push(g);
  }
  return { eligible, excluded, excludedIds };
}

export interface GarmentFeatures {
  weather: number;
  event: number;
  preference: number;
  rotation: number;
  recency: number;
  rating: number;
  daysSinceUse: number | null; // null = nunca usada
  ratingSamples: number;
}

/** Adecuación climática (0..1). Sin datos de clima devuelve 0.5 (neutro, se explica como ausencia). */
export function weatherFit(g: Garment, w: WeatherSnapshot | null): number {
  if (!w) return 0.5;
  const center = (g.tempMin + g.tempMax) / 2;
  const half = Math.max(1, (g.tempMax - g.tempMin) / 2);
  let s = 1 - 0.5 * Math.min(1.5, Math.abs(w.tempC - center) / half);
  if (isRainy(w)) {
    const slot = slotOf(g);
    if (slot === 'shoes' || slot === 'outer') s += g.waterproof ? 0.15 : -0.25;
    if (g.category === 'sandalias' || g.material?.toLowerCase().includes('gamuza')) s -= 0.3;
  }
  return clamp01(s);
}

export function eventFit(g: Garment, e: EventContext): number {
  // Penalización lineal: 3 niveles de diferencia o más = 0.
  let s = 1 - Math.min(1, Math.abs(g.formality - e.formality) / 3);
  if (e.preferredStyles.includes(g.style)) s += 0.15;
  return clamp01(s);
}

export function computeFeatures(
  g: Garment,
  ctx: {
    event: EventContext;
    weather: WeatherSnapshot | null;
    prefs: Pick<UserPreferences, 'preferredStyles'>;
    today: string;
    maxWearsInSlot: number;
    itemRatings: Map<string, number[]>;
  },
): GarmentFeatures {
  const pref = clamp01(0.5 + (ctx.prefs.preferredStyles.includes(g.style) ? 0.3 : 0) + (g.favorite ? 0.2 : 0));
  const rotation = ctx.maxWearsInSlot === 0 ? 0.5 : 1 - g.wearCount / (ctx.maxWearsInSlot + 1);
  const daysSinceUse = g.lastWornAt ? Math.max(0, daysBetween(g.lastWornAt, ctx.today)) : null;
  const recency = daysSinceUse === null ? 1 : Math.min(1, daysSinceUse / ENGINE.recencySaturationDays);
  const rs = ctx.itemRatings.get(g.id) ?? [];
  const rating = rs.length ? rs.reduce((a, r) => a + (r - 1) / 4, 0) / rs.length : 0.5;
  return { weather: weatherFit(g, ctx.weather), event: eventFit(g, ctx.event), preference: pref, rotation, recency, rating, daysSinceUse, ratingSamples: rs.length };
}

/** Índice prenda → calificaciones de los outfits en que aparece. */
export function indexItemRatings(ratings: OutfitRating[]): Map<string, number[]> {
  const m = new Map<string, number[]>();
  for (const r of ratings) for (const id of r.itemIds) (m.get(id) ?? m.set(id, []).get(id)!).push(r.rating);
  return m;
}

export function clamp01(x: number): number {
  return Math.max(0, Math.min(1, x));
}
