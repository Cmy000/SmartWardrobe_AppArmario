// Explicabilidad: cada frase se construye a partir de un valor calculado por el motor y
// queda etiquetada con el componente del que procede (verificado en las pruebas).
import { FORMALITY_LABEL, STYLES } from '../catalog';
import type { OutfitColorResult } from '../colors';
import type { Garment } from '../types';
import { ENGINE, TEMPLATES } from './config';
import { isRainy, slotOf, type GarmentFeatures } from './features';
import type { ComponentKey, ExplanationLine, RecommendationInput } from './types';

export function explain(a: {
  items: Garment[];
  feats: Map<string, GarmentFeatures>;
  components: Record<ComponentKey, number>;
  color: OutfitColorResult;
  input: RecommendationInput;
  outerRequired: boolean;
  maxOverlap: number;
  overlapDays: number | null;
  exactRating: number | undefined;
  templateId: string;
}): ExplanationLine[] {
  const { items, feats, components: c, input } = a;
  const lines: ExplanationLine[] = [];
  const lower = (s: string) => s.charAt(0).toLowerCase() + s.slice(1);

  // Disponibilidad: garantizada por el filtro estricto previo.
  lines.push({ factor: 'disponibilidad', text: `Todas las prendas están disponibles (${items.length} prendas).` });

  // Evento
  const avgF = items.reduce((s, g) => s + g.formality, 0) / items.length;
  const fitWord = c.event >= 0.8 ? 'adecuado' : c.event >= 0.6 ? 'aceptable' : 'poco ajustado';
  lines.push({
    factor: 'event',
    text: `Nivel ${fitWord} para "${input.event.label}": formalidad media ${avgF.toFixed(1)} (${lower(FORMALITY_LABEL[Math.round(avgF)] ?? '')}) frente a ${input.event.formality} buscada.`,
  });

  // Clima
  const w = input.weather;
  if (w) {
    const origin = w.source === 'api' ? 'pronóstico de Open-Meteo' : 'dato ingresado manualmente';
    let t = `Clima ${Math.round(w.tempC)} °C, ${w.description.toLowerCase()} (${origin}); todas las prendas están dentro de su rango de temperatura.`;
    if (a.outerRequired) t += ' Incluye capa exterior por el frío o la lluvia.';
    if (isRainy(w)) {
      const wp = items.filter((g) => g.waterproof && (slotOf(g) === 'outer' || slotOf(g) === 'shoes'));
      if (wp.length) t += ` Impermeable: ${wp.map((g) => g.name).join(', ')}.`;
    }
    lines.push({ factor: 'weather', text: t });
  } else lines.push({ factor: 'weather', text: 'Sin datos de clima: la temperatura no se tuvo en cuenta.' });

  // Color y estilo
  lines.push({ factor: 'color', text: `Colores: ${a.color.summary} (compatibilidad ${(c.color * 100).toFixed(0)} %).` });
  const styles = [...new Set(items.map((g) => STYLES[g.style].toLowerCase()))];
  lines.push({ factor: 'style', text: styles.length === 1 ? `Estilo uniforme: ${styles[0]}.` : `Combina estilos ${styles.join(', ')} (coherencia ${(c.style * 100).toFixed(0)} %).` });

  // Preferencias
  const prefStyles = items.filter((g) => input.prefs.preferredStyles.includes(g.style));
  const favs = items.filter((g) => g.favorite);
  if (prefStyles.length || favs.length) {
    const parts: string[] = [];
    if (prefStyles.length) parts.push(`${prefStyles.length} prenda(s) de tus estilos preferidos`);
    if (favs.length) parts.push(`tu favorita ${favs.map((g) => g.name).join(', ')}`);
    lines.push({ factor: 'preference', text: `Incluye ${parts.join(' y ')}.` });
  }

  // Tiempo sin uso: menciona la prenda con más días sin usar (si supera el umbral) o nunca usada.
  let longest: { g: Garment; d: number | null } | null = null;
  for (const g of items) {
    const d = feats.get(g.id)!.daysSinceUse;
    if (d === null) { longest = { g, d: null }; break; }
    if (d >= ENGINE.recencyMentionDays && (!longest || (longest.d !== null && d > longest.d))) longest = { g, d };
  }
  if (longest) lines.push({ factor: 'recency', text: longest.d === null ? `Aún no has registrado ningún uso de "${longest.g.name}".` : `Hace ${longest.d} días que no usas "${longest.g.name}".` });

  // Rotación
  if (c.rotation >= 0.7) lines.push({ factor: 'rotation', text: 'Da salida a prendas que usas poco en comparación con el resto de tu armario.' });

  // Diversidad
  if (a.maxOverlap > 0 && a.overlapDays !== null)
    lines.push({ factor: 'diversity', text: `Comparte ${(a.maxOverlap * 100).toFixed(0)} % de las prendas con un outfit usado hace ${a.overlapDays} día(s).` });
  else lines.push({ factor: 'diversity', text: `No se parece a lo que usaste en los últimos ${input.prefs.repeatWindowDays} días.` });

  // Valoraciones
  if (a.exactRating !== undefined) lines.push({ factor: 'rating', text: `Calificaste esta combinación con ${a.exactRating}/5.` });
  else {
    const rated = items.filter((g) => feats.get(g.id)!.ratingSamples > 0);
    if (rated.length) lines.push({ factor: 'rating', text: `Basado en tus valoraciones de outfits con ${rated.length} de estas prendas (${(c.rating * 100).toFixed(0)} %).` });
  }

  const tpl = TEMPLATES.find((t) => t.id === a.templateId);
  if (tpl) lines.push({ factor: 'plantilla', text: `Estructura: ${tpl.label.toLowerCase()}${items.some((g) => slotOf(g) === 'accessory') ? ' + accesorio' : ''}.` });
  return lines;
}
