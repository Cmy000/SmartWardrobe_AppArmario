// Parámetros del motor de recomendación.
// IMPORTANTE: todos los valores son iniciales, elegidos por criterio de diseño y NO calibrados con
// datos. Están pensados para ajustarse (desde Ajustes → Motor, o aquí) a medida que existan
// valoraciones reales con las que evaluarlos.
import type { ScoreWeights, Slot } from '../types';

export const DEFAULT_WEIGHTS: ScoreWeights = {
  color: 1.2, // compatibilidad cromática del conjunto
  style: 1.0, // coherencia de estilos entre prendas
  event: 1.5, // adecuación a la formalidad / estilo del evento
  weather: 1.2, // adecuación al rango de temperatura y lluvia
  preference: 0.8, // estilos preferidos y prendas favoritas
  rotation: 0.5, // favorece prendas con menos usos
  recency: 0.6, // favorece prendas que llevan tiempo sin usarse
  diversity: 0.7, // evita parecerse a outfits recientes
  rating: 0.8, // valoraciones históricas
};

export const WEIGHT_LABELS: Record<keyof ScoreWeights, string> = {
  color: 'Colores', style: 'Estilo', event: 'Evento', weather: 'Clima', preference: 'Preferencias',
  rotation: 'Rotación', recency: 'Tiempo sin uso', diversity: 'Diversidad', rating: 'Valoraciones',
};

export const ENGINE = {
  /** Umbral mínimo de coherencia estética ((color + estilo) / 2). Ningún bono de rotación lo compensa. */
  minCoherence: 0.6,
  /** Tolerancia (°C) alrededor del rango de temperatura de cada prenda en el filtro duro. */
  tempTolerance: 2,
  /** Por debajo de esta temperatura efectiva (o con lluvia) se exige una capa exterior si existe. */
  coldThreshold: 17,
  /** Por encima de esta temperatura no se generan plantillas con capa exterior. */
  warmThreshold: 24,
  /** Probabilidad de precipitación (%) a partir de la cual se considera día lluvioso. */
  rainThreshold: 50,
  /** En el filtro de formalidad obligatoria, diferencia máxima permitida respecto al objetivo. */
  strictFormalityDelta: 1,
  /** Candidatas por posición que pasan a la búsqueda de combinaciones (poda). */
  topKPerSlot: 8,
  /** Ancho del haz en la búsqueda por haz (beam search). */
  beamWidth: 40,
  /** Número de recomendaciones devueltas. */
  results: 6,
  /** Similitud de Jaccard máxima entre dos recomendaciones devueltas (variedad del resultado). */
  maxResultOverlap: 0.5,
  /** Días tras los cuales el componente "tiempo sin uso" se satura en 1. */
  recencySaturationDays: 30,
  /** A partir de cuántos días sin uso se menciona en la explicación. */
  recencyMentionDays: 14,
};

export interface OutfitTemplate {
  id: string;
  label: string;
  slots: Slot[];
}

export const TEMPLATES: OutfitTemplate[] = [
  { id: 'sup-inf-cal', label: 'Superior + inferior + calzado', slots: ['top', 'bottom', 'shoes'] },
  { id: 'com-cal', label: 'Vestido o enterizo + calzado', slots: ['onepiece', 'shoes'] },
  { id: 'sup-inf-abr-cal', label: 'Superior + inferior + abrigo + calzado', slots: ['top', 'bottom', 'outer', 'shoes'] },
  { id: 'com-abr-cal', label: 'Vestido o enterizo + abrigo + calzado', slots: ['onepiece', 'outer', 'shoes'] },
];
