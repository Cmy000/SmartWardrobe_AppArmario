// Modelo de datos de SmartWardrobe.
// Cada registro persistido lleva `profileId`: es la clave de aislamiento entre usuarios
// que comparten un mismo navegador. Las fechas de calendario son 'YYYY-MM-DD' (hora local);
// los instantes son ISO 8601.

export type ID = string;
export type ISODate = string; // 'YYYY-MM-DD'
export type ISODateTime = string;

export type GarmentStatus =
  | 'disponible' // Limpia y disponible
  | 'usada' // Usada, pendiente de decidir si requiere lavado
  | 'lavanderia'
  | 'reparacion'
  | 'guardada' // Guardada temporalmente
  | 'retirada'; // Retirada del armario

export type Slot = 'top' | 'bottom' | 'onepiece' | 'outer' | 'shoes' | 'accessory';

export type Category =
  | 'camisa' | 'camiseta' | 'blusa' | 'sueter' | 'top_deportivo'
  | 'pantalon' | 'jean' | 'falda' | 'short'
  | 'vestido' | 'enterizo'
  | 'chaqueta' | 'abrigo' | 'blazer' | 'cardigan'
  | 'zapatos' | 'tenis' | 'botas' | 'sandalias'
  | 'accesorio' | 'bolso' | 'bufanda';

export type Style = 'casual' | 'elegante' | 'formal' | 'deportivo' | 'bohemio' | 'minimalista' | 'urbano';
export type Pattern = 'liso' | 'rayas' | 'cuadros' | 'flores' | 'lunares' | 'estampado' | 'animal_print';
export type Season = 'primavera' | 'verano' | 'otono' | 'invierno' | 'todo_el_ano';

export interface Profile {
  id: ID;
  name: string;
  isDemo: boolean;
  pinHash?: string; // PBKDF2-SHA256 (base64) — protección de conveniencia, no criptográfica fuerte
  pinSalt?: string;
  createdAt: ISODateTime;
}

export interface Garment {
  id: ID;
  profileId: ID;
  name: string;
  imageId?: ID;
  category: Category;
  subcategory?: string;
  colorPrimary: string; // clave de la paleta (catalog.COLORS)
  colorsSecondary: string[];
  material?: string;
  pattern: Pattern;
  style: Style;
  formality: number; // 1 (muy informal) … 5 (etiqueta)
  seasons: Season[];
  tempMin: number; // °C, rango recomendado
  tempMax: number;
  waterproof: boolean;
  brand?: string;
  acquiredAt?: ISODate;
  cost?: number;
  wearCount: number;
  lastWornAt?: ISODate;
  status: GarmentStatus;
  notes?: string;
  favorite: boolean;
  tags: string[];
  createdAt: ISODateTime;
  updatedAt: ISODateTime;
}

export interface GarmentImage {
  id: ID;
  profileId: ID;
  full: Blob; // JPEG re-codificado (sin EXIF), máx. 1280 px
  thumb: Blob; // JPEG 400 px
  width: number;
  height: number;
  createdAt: ISODateTime;
}

export interface StatusChange {
  id: ID;
  profileId: ID;
  garmentId: ID;
  from: GarmentStatus | null;
  to: GarmentStatus;
  at: ISODateTime;
  note?: string;
}

export interface MaintenanceRecord {
  id: ID;
  profileId: ID;
  garmentId: ID;
  kind: 'lavanderia' | 'reparacion';
  reason?: string;
  reportedAt: ISODateTime;
  notes?: string;
  resolvedAt?: ISODateTime;
}

export interface UserPreferences {
  profileId: ID;
  location?: { name: string; latitude: number; longitude: number };
  preferredStyles: Style[];
  avoidColors: string[];
  repeatWindowDays: number; // prevención de repeticiones recientes
  afterWear: 'preguntar' | 'disponible'; // estado de las prendas tras registrar uso
  allowUsedPending: boolean; // permitir prendas en estado "usada" en recomendaciones
  weights: ScoreWeights;
  minCoherence: number;
  updatedAt: ISODateTime;
}

export interface ScoreWeights {
  color: number;
  style: number;
  event: number;
  weather: number;
  preference: number;
  rotation: number;
  recency: number;
  diversity: number;
  rating: number;
}

export type OutfitSource = 'recomendado' | 'manual';

export interface Outfit {
  id: ID;
  profileId: ID;
  name: string;
  itemIds: ID[];
  source: OutfitSource;
  favorite: boolean;
  eventType?: string;
  createdAt: ISODateTime;
}

/** Recomendación mostrada. Estado: mostrada → aceptada | rechazada. "Usada" se registra en WearRecord. */
export interface RecommendationRecord {
  id: ID;
  profileId: ID;
  createdAt: ISODateTime;
  forDate: ISODate;
  eventType: string;
  itemIds: ID[];
  score: number;
  components: Record<string, number>;
  explanation: string[];
  weatherSource: 'api' | 'manual' | 'none';
  status: 'mostrada' | 'aceptada' | 'rechazada';
}

export interface OutfitRating {
  id: ID;
  profileId: ID;
  comboKey: string; // ids ordenados unidos por '|'
  itemIds: ID[];
  rating: number; // 1..5
  at: ISODateTime;
}

export interface BlockedCombo {
  id: ID;
  profileId: ID;
  itemIds: ID[]; // 2+ prendas que nunca deben aparecer juntas
  createdAt: ISODateTime;
}

export interface WearRecord {
  id: ID;
  profileId: ID;
  date: ISODate;
  itemIds: ID[];
  outfitId?: ID;
  recommendationId?: ID;
  eventType?: string;
  createdAt: ISODateTime;
}

export interface PlannedOutfit {
  id: ID;
  profileId: ID;
  date: ISODate;
  itemIds: ID[];
  outfitId?: ID;
  eventType?: string;
  note?: string;
  createdAt: ISODateTime;
}

export interface WeatherSnapshot {
  source: 'api' | 'manual';
  date: ISODate;
  tempC: number; // temperatura efectiva usada por el motor
  tempMin?: number;
  tempMax?: number;
  feelsLikeC?: number;
  precipProbability: number; // 0..100
  condition: 'soleado' | 'nublado' | 'lluvioso';
  description: string;
  locationName?: string;
  fetchedAt?: ISODateTime;
}
