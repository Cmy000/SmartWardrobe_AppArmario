// Historial de uso y planificación de outfits futuros.
import { STATUS_LABEL } from './catalog';
import { BLOCKING_STATUSES } from './status';
import type { Garment, ISODate, PlannedOutfit, WearRecord } from './types';

/**
 * Métricas de uso derivadas del historial real (WearRecord), nunca de recomendaciones
 * mostradas o aceptadas ni de planes. Recalcular desde el historial hace que borrar un
 * registro deshaga correctamente el conteo.
 */
export function usageFromHistory(garmentId: string, wears: WearRecord[], today: ISODate): { wearCount: number; lastWornAt?: ISODate } {
  let count = 0;
  let last: ISODate | undefined;
  for (const w of wears) {
    if (w.date > today) continue; // un registro con fecha futura no cuenta como uso
    if (!w.itemIds.includes(garmentId)) continue;
    count++;
    if (!last || w.date > last) last = w.date;
  }
  return { wearCount: count, lastWornAt: last };
}

export interface PlanConflict {
  planId: string;
  date: ISODate;
  garmentId: string;
  garmentName: string;
  kind: 'no_disponible' | 'doble_reserva' | 'eliminada';
  message: string;
}

/** Conflictos de los planes desde `from`: prendas no disponibles o reservadas dos veces el mismo día. */
export function planConflicts(plans: PlannedOutfit[], garments: Garment[], from: ISODate): PlanConflict[] {
  const byId = new Map(garments.map((g) => [g.id, g]));
  const out: PlanConflict[] = [];
  const upcoming = plans.filter((p) => p.date >= from).sort((a, b) => a.date.localeCompare(b.date) || a.createdAt.localeCompare(b.createdAt));
  const seen = new Map<string, string>(); // `${date}|${garmentId}` → planId
  for (const p of upcoming)
    for (const id of p.itemIds) {
      const g = byId.get(id);
      if (!g) { out.push({ planId: p.id, date: p.date, garmentId: id, garmentName: '(eliminada)', kind: 'eliminada', message: 'Una prenda de este plan fue eliminada.' }); continue; }
      if (BLOCKING_STATUSES.has(g.status))
        out.push({ planId: p.id, date: p.date, garmentId: id, garmentName: g.name, kind: 'no_disponible', message: `"${g.name}" está ${STATUS_LABEL[g.status].toLowerCase()}.` });
      const k = `${p.date}|${id}`;
      if (seen.has(k) && seen.get(k) !== p.id)
        out.push({ planId: p.id, date: p.date, garmentId: id, garmentName: g.name, kind: 'doble_reserva', message: `"${g.name}" ya está reservada en otro plan de ese día.` });
      else seen.set(k, p.id);
    }
  return out;
}

/** Validación al crear un plan nuevo (antes de guardarlo). */
export function checkNewPlan(itemIds: string[], date: ISODate, plans: PlannedOutfit[], garments: Garment[]): PlanConflict[] {
  const draft: PlannedOutfit = { id: '__nuevo__', profileId: '', date, itemIds, createdAt: '9999' };
  return planConflicts([...plans, draft], garments, date).filter((c) => c.planId === '__nuevo__');
}
