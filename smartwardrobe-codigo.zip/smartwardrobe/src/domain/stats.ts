// Indicadores del armario. Regla: no inventar métricas. Cuando faltan datos se devuelve
// `null` con un motivo, y la interfaz lo muestra como "datos insuficientes".
import { CATEGORIES, COLORS } from './catalog';
import { addDays, daysBetween, monthKey } from './dates';
import type { Garment, ISODate, MaintenanceRecord, WearRecord } from './types';

export interface Insufficient { value: null; reason: string }
export type Metric<T> = { value: T } | Insufficient;

export interface WardrobeStats {
  period: { from: ISODate | null; to: ISODate; days: number | null };
  totalGarments: number; // activas (no retiradas)
  retired: number;
  available: number;
  byStatus: Record<string, number>;
  pendingMaintenance: number;
  wearsInPeriod: number; // registros de uso (outfits) en el periodo
  outfitsRegistered: number; // total histórico
  neverWorn: Metric<{ count: number; ids: string[] }>;
  unusedInPeriod: Metric<{ count: number; ids: string[] }>;
  usedShare: Metric<number>; // % del armario activo usado en el periodo
  frequency: Array<{ id: string; name: string; uses: number }>; // usos en el periodo
  byCategory: Array<{ key: string; label: string; count: number }>;
  byColor: Array<{ key: string; label: string; hex: string; count: number }>;
  monthlyRotation: Array<{ month: string; distinctItems: number; wears: number }>;
  costPerWear: Array<{ id: string; name: string; cost: number; uses: number; cpw: number | null }>;
  trackingDays: number | null; // días desde el primer registro de uso
}

export const MIN_TRACKING_DAYS = 14; // por debajo, "sin uso" no es concluyente

export function computeStats(garments: Garment[], wears: WearRecord[], maintenance: MaintenanceRecord[], to: ISODate, periodDays: number | null): WardrobeStats {
  const from = periodDays === null ? null : addDays(to, -periodDays + 1);
  const inPeriod = (d: ISODate) => (from === null || d >= from) && d <= to;
  const active = garments.filter((g) => g.status !== 'retirada');
  const activeIds = new Set(active.map((g) => g.id));
  const periodWears = wears.filter((w) => inPeriod(w.date));

  const uses = new Map<string, number>();
  for (const w of periodWears) for (const id of w.itemIds) uses.set(id, (uses.get(id) ?? 0) + 1);

  const byStatus: Record<string, number> = {};
  for (const g of garments) byStatus[g.status] = (byStatus[g.status] ?? 0) + 1;

  const firstWear = wears.length ? wears.reduce((m, w) => (w.date < m ? w.date : m), wears[0].date) : null;
  const trackingDays = firstWear ? daysBetween(firstWear, to) + 1 : null;
  const enoughTracking = trackingDays !== null && trackingDays >= MIN_TRACKING_DAYS;

  const neverIds = active.filter((g) => g.wearCount === 0).map((g) => g.id);
  const neverWorn: Metric<{ count: number; ids: string[] }> = active.length === 0
    ? { value: null, reason: 'No hay prendas registradas.' }
    : !enoughTracking
      ? { value: null, reason: `Se necesitan al menos ${MIN_TRACKING_DAYS} días de registros de uso para concluir que una prenda no se usa.` }
      : { value: { count: neverIds.length, ids: neverIds } };

  const unusedIds = active.filter((g) => !uses.has(g.id)).map((g) => g.id);
  const unusedInPeriod: Metric<{ count: number; ids: string[] }> = !enoughTracking || periodWears.length === 0
    ? { value: null, reason: 'Aún no hay suficientes registros de uso en este periodo.' }
    : { value: { count: unusedIds.length, ids: unusedIds } };

  const usedActive = [...uses.keys()].filter((id) => activeIds.has(id)).length;
  const usedShare: Metric<number> = active.length === 0 || periodWears.length === 0
    ? { value: null, reason: 'Sin registros de uso en el periodo.' }
    : { value: usedActive / active.length };

  const cat = new Map<string, number>();
  const col = new Map<string, number>();
  for (const g of active) {
    cat.set(g.category, (cat.get(g.category) ?? 0) + 1);
    col.set(g.colorPrimary, (col.get(g.colorPrimary) ?? 0) + 1);
  }

  const months = new Map<string, { items: Set<string>; wears: number }>();
  for (const w of periodWears) {
    const k = monthKey(w.date);
    const e = months.get(k) ?? months.set(k, { items: new Set(), wears: 0 }).get(k)!;
    e.wears++;
    w.itemIds.forEach((id) => e.items.add(id));
  }

  return {
    period: { from, to, days: periodDays },
    totalGarments: active.length,
    retired: garments.length - active.length,
    available: garments.filter((g) => g.status === 'disponible').length,
    byStatus,
    pendingMaintenance: maintenance.filter((m) => !m.resolvedAt).length,
    wearsInPeriod: periodWears.length,
    outfitsRegistered: wears.length,
    neverWorn,
    unusedInPeriod,
    usedShare,
    frequency: active.map((g) => ({ id: g.id, name: g.name, uses: uses.get(g.id) ?? 0 })).sort((a, b) => b.uses - a.uses),
    byCategory: [...cat].map(([key, count]) => ({ key, label: CATEGORIES[key as keyof typeof CATEGORIES]?.label ?? key, count })).sort((a, b) => b.count - a.count),
    byColor: [...col].map(([key, count]) => ({ key, label: COLORS[key]?.label ?? key, hex: COLORS[key]?.hex ?? '#999', count })).sort((a, b) => b.count - a.count),
    monthlyRotation: [...months].map(([month, e]) => ({ month, distinctItems: e.items.size, wears: e.wears })).sort((a, b) => a.month.localeCompare(b.month)),
    // Costo por uso: costo de adquisición / usos registrados (históricos). Solo si hay costo.
    costPerWear: garments
      .filter((g) => g.cost !== undefined && g.cost !== null && g.cost > 0)
      .map((g) => ({ id: g.id, name: g.name, cost: g.cost!, uses: g.wearCount, cpw: g.wearCount > 0 ? g.cost! / g.wearCount : null }))
      .sort((a, b) => (b.cpw ?? Infinity) - (a.cpw ?? Infinity)),
    trackingDays,
  };
}

/** Prendas menos utilizadas (activas, disponibles o no), para el dashboard. */
export function leastUsed(garments: Garment[], today: ISODate, n = 5): Garment[] {
  return garments
    .filter((g) => g.status !== 'retirada')
    .sort((a, b) => {
      const da = a.lastWornAt ? daysBetween(a.lastWornAt, today) : Infinity;
      const db = b.lastWornAt ? daysBetween(b.lastWornAt, today) : Infinity;
      return a.wearCount - b.wearCount || db - da;
    })
    .slice(0, n);
}
