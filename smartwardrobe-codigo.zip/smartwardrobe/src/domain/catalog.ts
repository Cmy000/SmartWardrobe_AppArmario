// Catálogos de referencia: categorías, colores, estilos, eventos.
// Son datos de configuración: modificarlos aquí cambia el comportamiento del motor sin tocar algoritmos.
import type { Category, Pattern, Season, Slot, Style, GarmentStatus } from './types';

export interface CategoryInfo {
  label: string;
  slot: Slot;
  /** Valores sugeridos al crear la prenda; el usuario puede ajustarlos. */
  defaultTemp: [number, number];
  defaultFormality: number;
}

export const CATEGORIES: Record<Category, CategoryInfo> = {
  camisa: { label: 'Camisa', slot: 'top', defaultTemp: [12, 30], defaultFormality: 3 },
  camiseta: { label: 'Camiseta', slot: 'top', defaultTemp: [16, 35], defaultFormality: 1 },
  blusa: { label: 'Blusa', slot: 'top', defaultTemp: [14, 32], defaultFormality: 3 },
  sueter: { label: 'Suéter', slot: 'top', defaultTemp: [0, 18], defaultFormality: 2 },
  top_deportivo: { label: 'Top deportivo', slot: 'top', defaultTemp: [14, 35], defaultFormality: 1 },
  pantalon: { label: 'Pantalón', slot: 'bottom', defaultTemp: [0, 28], defaultFormality: 3 },
  jean: { label: 'Jean', slot: 'bottom', defaultTemp: [0, 26], defaultFormality: 2 },
  falda: { label: 'Falda', slot: 'bottom', defaultTemp: [14, 32], defaultFormality: 3 },
  short: { label: 'Short', slot: 'bottom', defaultTemp: [22, 38], defaultFormality: 1 },
  vestido: { label: 'Vestido', slot: 'onepiece', defaultTemp: [16, 34], defaultFormality: 3 },
  enterizo: { label: 'Enterizo', slot: 'onepiece', defaultTemp: [14, 32], defaultFormality: 2 },
  chaqueta: { label: 'Chaqueta', slot: 'outer', defaultTemp: [6, 20], defaultFormality: 2 },
  abrigo: { label: 'Abrigo', slot: 'outer', defaultTemp: [-10, 14], defaultFormality: 3 },
  blazer: { label: 'Blazer', slot: 'outer', defaultTemp: [10, 24], defaultFormality: 4 },
  cardigan: { label: 'Cárdigan', slot: 'outer', defaultTemp: [10, 22], defaultFormality: 2 },
  zapatos: { label: 'Zapatos', slot: 'shoes', defaultTemp: [-5, 35], defaultFormality: 4 },
  tenis: { label: 'Tenis', slot: 'shoes', defaultTemp: [0, 35], defaultFormality: 1 },
  botas: { label: 'Botas', slot: 'shoes', defaultTemp: [-10, 20], defaultFormality: 3 },
  sandalias: { label: 'Sandalias', slot: 'shoes', defaultTemp: [20, 40], defaultFormality: 2 },
  accesorio: { label: 'Accesorio', slot: 'accessory', defaultTemp: [-20, 45], defaultFormality: 3 },
  bolso: { label: 'Bolso', slot: 'accessory', defaultTemp: [-20, 45], defaultFormality: 3 },
  bufanda: { label: 'Bufanda', slot: 'accessory', defaultTemp: [-15, 16], defaultFormality: 2 },
};

export const SLOT_LABEL: Record<Slot, string> = {
  top: 'Parte superior', bottom: 'Parte inferior', onepiece: 'Prenda completa', outer: 'Abrigo / capa', shoes: 'Calzado', accessory: 'Accesorio',
};

export interface ColorInfo {
  label: string;
  hex: string;
  /** Tono HSL en grados (null para neutros acromáticos). */
  hue: number | null;
  /** Los neutros combinan con casi todo. */
  neutral: boolean;
}

export const COLORS: Record<string, ColorInfo> = {
  negro: { label: 'Negro', hex: '#1c1917', hue: null, neutral: true },
  blanco: { label: 'Blanco', hex: '#fafaf9', hue: null, neutral: true },
  gris: { label: 'Gris', hex: '#9ca3af', hue: null, neutral: true },
  beige: { label: 'Beige', hex: '#e7d8bf', hue: 38, neutral: true },
  camel: { label: 'Camel', hex: '#b68654', hue: 30, neutral: true },
  marron: { label: 'Marrón', hex: '#6b4a32', hue: 25, neutral: true },
  azul_marino: { label: 'Azul marino', hex: '#1e2a4a', hue: 222, neutral: true },
  denim: { label: 'Denim', hex: '#4a6a93', hue: 214, neutral: true },
  azul: { label: 'Azul', hex: '#2f6fd1', hue: 216, neutral: false },
  celeste: { label: 'Celeste', hex: '#9cc7ec', hue: 207, neutral: false },
  verde: { label: 'Verde', hex: '#3f8f5a', hue: 140, neutral: false },
  oliva: { label: 'Verde oliva', hex: '#6b6b3a', hue: 60, neutral: true },
  rojo: { label: 'Rojo', hex: '#c0392b', hue: 6, neutral: false },
  vinotinto: { label: 'Vinotinto', hex: '#6d1f2f', hue: 348, neutral: false },
  rosado: { label: 'Rosado', hex: '#f2a7bb', hue: 344, neutral: false },
  fucsia: { label: 'Fucsia', hex: '#d63384', hue: 330, neutral: false },
  morado: { label: 'Morado', hex: '#7b4fa0', hue: 275, neutral: false },
  lila: { label: 'Lila', hex: '#c3a6db', hue: 275, neutral: false },
  amarillo: { label: 'Amarillo', hex: '#f2c94c', hue: 45, neutral: false },
  mostaza: { label: 'Mostaza', hex: '#c9a227', hue: 46, neutral: false },
  naranja: { label: 'Naranja', hex: '#e67e22', hue: 28, neutral: false },
  terracota: { label: 'Terracota', hex: '#b85c38', hue: 18, neutral: false },
  dorado: { label: 'Dorado', hex: '#c8a951', hue: 45, neutral: true },
  plateado: { label: 'Plateado', hex: '#c0c4c8', hue: null, neutral: true },
};

export const STYLES: Record<Style, string> = {
  casual: 'Casual', elegante: 'Elegante', formal: 'Formal', deportivo: 'Deportivo', bohemio: 'Bohemio', minimalista: 'Minimalista', urbano: 'Urbano',
};

/**
 * Compatibilidad entre estilos (simétrica, 0..1). Valores iniciales razonados, no calibrados
 * con datos: ajustables. Pares no listados = 0.5.
 */
const STYLE_PAIRS: Array<[Style, Style, number]> = [
  ['casual', 'urbano', 0.9], ['casual', 'minimalista', 0.9], ['casual', 'bohemio', 0.8], ['casual', 'deportivo', 0.7],
  ['casual', 'elegante', 0.6], ['casual', 'formal', 0.35],
  ['elegante', 'formal', 0.9], ['elegante', 'minimalista', 0.9], ['elegante', 'bohemio', 0.55], ['elegante', 'urbano', 0.55],
  ['elegante', 'deportivo', 0.15], ['formal', 'minimalista', 0.85], ['formal', 'deportivo', 0.05], ['formal', 'urbano', 0.3],
  ['formal', 'bohemio', 0.3], ['deportivo', 'urbano', 0.8], ['deportivo', 'minimalista', 0.5], ['deportivo', 'bohemio', 0.3],
  ['minimalista', 'urbano', 0.85], ['minimalista', 'bohemio', 0.5], ['bohemio', 'urbano', 0.6],
];
export function styleCompatibility(a: Style, b: Style): number {
  if (a === b) return 1;
  for (const [x, y, v] of STYLE_PAIRS) if ((x === a && y === b) || (x === b && y === a)) return v;
  return 0.5;
}

export const PATTERNS: Record<Pattern, string> = {
  liso: 'Liso', rayas: 'Rayas', cuadros: 'Cuadros', flores: 'Flores', lunares: 'Lunares', estampado: 'Estampado', animal_print: 'Animal print',
};

export const SEASONS: Record<Season, string> = {
  primavera: 'Primavera', verano: 'Verano', otono: 'Otoño', invierno: 'Invierno', todo_el_ano: 'Todo el año',
};

export interface EventType {
  label: string;
  formality: number; // objetivo 1..5
  strict: boolean; // si la formalidad es obligatoria (filtro duro) o preferencia (puntuación)
  preferredStyles: Style[];
}

export const EVENTS: Record<string, EventType> = {
  casa: { label: 'En casa / descanso', formality: 1, strict: false, preferredStyles: ['casual', 'deportivo', 'minimalista'] },
  diario: { label: 'Día a día', formality: 2, strict: false, preferredStyles: ['casual', 'urbano', 'minimalista'] },
  deporte: { label: 'Deporte', formality: 1, strict: true, preferredStyles: ['deportivo'] },
  trabajo: { label: 'Trabajo / oficina', formality: 3, strict: false, preferredStyles: ['minimalista', 'elegante', 'casual'] },
  reunion_formal: { label: 'Reunión formal', formality: 4, strict: true, preferredStyles: ['formal', 'elegante', 'minimalista'] },
  cita: { label: 'Cita / salida', formality: 3, strict: false, preferredStyles: ['elegante', 'urbano', 'bohemio'] },
  fiesta: { label: 'Fiesta', formality: 3, strict: false, preferredStyles: ['elegante', 'urbano', 'bohemio'] },
  ceremonia: { label: 'Ceremonia / boda', formality: 5, strict: true, preferredStyles: ['formal', 'elegante'] },
  viaje: { label: 'Viaje', formality: 2, strict: false, preferredStyles: ['casual', 'urbano', 'deportivo'] },
};

export const STATUS_LABEL: Record<GarmentStatus, string> = {
  disponible: 'Limpia y disponible',
  usada: 'Usada · decidir si lavar',
  lavanderia: 'En lavandería',
  reparacion: 'Requiere reparación',
  guardada: 'Guardada temporalmente',
  retirada: 'Retirada del armario',
};

export const FORMALITY_LABEL = ['', 'Muy informal', 'Informal', 'Smart casual', 'Formal', 'Etiqueta'];
