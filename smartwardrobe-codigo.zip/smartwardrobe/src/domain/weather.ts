// Integración climática con Open-Meteo (API gratuita sin clave para uso no comercial,
// < 10.000 llamadas/día; datos CC-BY 4.0 — ver docs/README.md).
// - Caché con caducidad.
// - Errores tipados; la interfaz cae al modo manual y nunca bloquea la generación de outfits.
// - Nunca se inventan datos: si la API falla, el resultado es un error, no un valor por defecto.
import type { ISODate, WeatherSnapshot } from './types';

export const FORECAST_URL = 'https://api.open-meteo.com/v1/forecast';
export const GEOCODING_URL = 'https://geocoding-api.open-meteo.com/v1/search';
export const FORECAST_DAYS = 16; // horizonte máximo de la API gratuita
export const CACHE_TTL_MS = 60 * 60 * 1000; // 1 hora

/** Peso de la máxima diaria en la temperatura efectiva (horas de día pesan más que la madrugada). */
export const DAYTIME_WEIGHT = 0.6;

export type WeatherErrorKind = 'sin_ubicacion' | 'fuera_de_rango' | 'red' | 'respuesta_invalida' | 'http';
export class WeatherError extends Error {
  constructor(public kind: WeatherErrorKind, message: string) { super(message); }
}

// Códigos WMO usados por Open-Meteo → descripción y condición simplificada.
export function describeWmo(code: number): { description: string; condition: WeatherSnapshot['condition'] } {
  if (code === 0) return { description: 'Despejado', condition: 'soleado' };
  if (code <= 2) return { description: 'Parcialmente nublado', condition: 'soleado' };
  if (code === 3) return { description: 'Nublado', condition: 'nublado' };
  if (code === 45 || code === 48) return { description: 'Niebla', condition: 'nublado' };
  if (code >= 51 && code <= 57) return { description: 'Llovizna', condition: 'lluvioso' };
  if (code >= 61 && code <= 67) return { description: 'Lluvia', condition: 'lluvioso' };
  if (code >= 71 && code <= 77) return { description: 'Nieve', condition: 'lluvioso' };
  if (code >= 80 && code <= 82) return { description: 'Chubascos', condition: 'lluvioso' };
  if (code >= 85 && code <= 86) return { description: 'Chubascos de nieve', condition: 'lluvioso' };
  if (code >= 95) return { description: 'Tormenta', condition: 'lluvioso' };
  return { description: 'Condición desconocida', condition: 'nublado' };
}

export interface CacheStore {
  get(key: string): { at: number; value: unknown } | undefined;
  set(key: string, entry: { at: number; value: unknown }): void;
}

export class MemoryCache implements CacheStore {
  private m = new Map<string, { at: number; value: unknown }>();
  get(k: string) { return this.m.get(k); }
  set(k: string, v: { at: number; value: unknown }) { this.m.set(k, v); }
}

/** Caché respaldada en localStorage (navegador). */
export class LocalStorageCache implements CacheStore {
  constructor(private prefix = 'sw-weather:') {}
  get(k: string) {
    try { const s = localStorage.getItem(this.prefix + k); return s ? JSON.parse(s) : undefined; } catch { return undefined; }
  }
  set(k: string, v: { at: number; value: unknown }) {
    try { localStorage.setItem(this.prefix + k, JSON.stringify(v)); } catch { /* cuota llena: se ignora la caché */ }
  }
}

type FetchFn = (url: string, init?: { signal?: AbortSignal }) => Promise<{ ok: boolean; status: number; json(): Promise<unknown> }>;

interface DailyResponse {
  daily: {
    time: string[];
    temperature_2m_max: number[];
    temperature_2m_min: number[];
    apparent_temperature_max?: number[];
    precipitation_probability_max?: (number | null)[];
    weather_code: number[];
  };
}

export interface Location { name: string; latitude: number; longitude: number }

export class WeatherService {
  constructor(
    private fetchFn: FetchFn,
    private cache: CacheStore = new MemoryCache(),
    private now: () => number = () => Date.now(),
    private timeoutMs = 8000,
  ) {}

  async forecast(loc: Location | undefined, date: ISODate): Promise<WeatherSnapshot> {
    if (!loc) throw new WeatherError('sin_ubicacion', 'Configura tu ubicación en Ajustes para consultar el clima.');
    const key = `${loc.latitude.toFixed(3)},${loc.longitude.toFixed(3)}`;
    let data = this.cache.get(key);
    if (!data || this.now() - data.at > CACHE_TTL_MS) {
      const url = `${FORECAST_URL}?latitude=${loc.latitude}&longitude=${loc.longitude}` +
        `&daily=temperature_2m_max,temperature_2m_min,apparent_temperature_max,precipitation_probability_max,weather_code` +
        `&timezone=auto&forecast_days=${FORECAST_DAYS}`;
      const json = await this.get(url);
      if (!isDaily(json)) throw new WeatherError('respuesta_invalida', 'La respuesta del servicio climático no tiene el formato esperado.');
      data = { at: this.now(), value: json };
      this.cache.set(key, data);
    }
    const d = (data.value as DailyResponse).daily;
    const i = d.time.indexOf(date);
    if (i < 0) throw new WeatherError('fuera_de_rango', `No hay pronóstico para ${date} (la API cubre ${FORECAST_DAYS} días). Ingresa el clima manualmente.`);
    const max = d.temperature_2m_max[i];
    const min = d.temperature_2m_min[i];
    const { description, condition } = describeWmo(d.weather_code[i]);
    return {
      source: 'api',
      date,
      tempC: round1(DAYTIME_WEIGHT * max + (1 - DAYTIME_WEIGHT) * min),
      tempMax: max,
      tempMin: min,
      feelsLikeC: d.apparent_temperature_max?.[i] ?? undefined,
      precipProbability: d.precipitation_probability_max?.[i] ?? 0,
      condition,
      description,
      locationName: loc.name,
      fetchedAt: new Date(data.at).toISOString(),
    };
  }

  async geocode(name: string): Promise<Location[]> {
    const json = (await this.get(`${GEOCODING_URL}?name=${encodeURIComponent(name)}&count=6&language=es&format=json`)) as {
      results?: Array<{ name: string; latitude: number; longitude: number; admin1?: string; country?: string }>;
    };
    return (json.results ?? []).map((r) => ({ name: [r.name, r.admin1, r.country].filter(Boolean).join(', '), latitude: r.latitude, longitude: r.longitude }));
  }

  private async get(url: string): Promise<unknown> {
    const ctrl = typeof AbortController !== 'undefined' ? new AbortController() : undefined;
    const timer = ctrl ? setTimeout(() => ctrl.abort(), this.timeoutMs) : undefined;
    try {
      const res = await this.fetchFn(url, { signal: ctrl?.signal });
      if (!res.ok) throw new WeatherError('http', `El servicio climático respondió con error ${res.status}.`);
      return await res.json();
    } catch (e) {
      if (e instanceof WeatherError) throw e;
      throw new WeatherError('red', 'No fue posible conectar con el servicio climático.');
    } finally {
      if (timer) clearTimeout(timer);
    }
  }
}

function isDaily(x: unknown): x is DailyResponse {
  const d = (x as DailyResponse)?.daily;
  return !!d && Array.isArray(d.time) && Array.isArray(d.temperature_2m_max) && Array.isArray(d.temperature_2m_min) && Array.isArray(d.weather_code);
}

const round1 = (x: number) => Math.round(x * 10) / 10;

/** Clima manual: el usuario elige temperatura aproximada y condición. Se marca como 'manual'. */
export function manualWeather(date: ISODate, tempC: number, condition: WeatherSnapshot['condition'], feelsLikeC?: number): WeatherSnapshot {
  const labels = { soleado: 'Soleado', nublado: 'Nublado', lluvioso: 'Lluvioso' } as const;
  return {
    source: 'manual',
    date,
    // Si el usuario indica sensación térmica, el motor usa esa temperatura.
    tempC: feelsLikeC ?? tempC,
    feelsLikeC,
    precipProbability: condition === 'lluvioso' ? 80 : condition === 'nublado' ? 20 : 0,
    condition,
    description: labels[condition],
  };
}
