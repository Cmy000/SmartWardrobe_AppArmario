// Repositorio con aislamiento por perfil.
// Toda lectura y escritura pasa por `ProfileRepo`, que:
//   - consulta siempre por el índice `profileId` del perfil activo;
//   - al leer por id, devuelve `undefined` si el registro pertenece a otro perfil
//     (modificar un id en la URL no da acceso a datos ajenos);
//   - al escribir, fuerza `profileId` y rechaza sobrescribir registros de otro perfil.
import { DEFAULT_WEIGHTS, ENGINE } from '../domain/recommender/config';
import { comboKey } from '../domain/recommender/engine';
import { usageFromHistory } from '../domain/planning';
import { planTransition } from '../domain/status';
import { today as todayISO } from '../domain/dates';
import type {
  BlockedCombo, Garment, GarmentImage, GarmentStatus, ID, ISODate, MaintenanceRecord, Outfit, OutfitRating, PlannedOutfit,
  Profile, RecommendationRecord, StatusChange, UserPreferences, WearRecord,
} from '../domain/types';
import { openDB, reqP, tx, type StoreName } from './db';

export const newId = () => (crypto.randomUUID ? crypto.randomUUID() : `${Date.now().toString(36)}-${Math.random().toString(36).slice(2)}`);
const nowISO = () => new Date().toISOString();

export class NotFoundError extends Error { constructor() { super('No encontrado'); } }

// ---------------- Perfiles (nivel dispositivo) ----------------
export async function listProfiles(): Promise<Profile[]> {
  const db = await openDB();
  const all = await reqP(db.transaction('profiles').objectStore('profiles').getAll() as IDBRequest<Profile[]>);
  return all.sort((a, b) => a.createdAt.localeCompare(b.createdAt));
}

export async function createProfile(name: string, opts: { isDemo?: boolean; pin?: string } = {}): Promise<Profile> {
  const clean = name.trim();
  if (!clean) throw new Error('Escribe un nombre para el perfil.');
  if (clean.length > 40) throw new Error('El nombre es demasiado largo (máx. 40 caracteres).');
  const p: Profile = { id: newId(), name: clean, isDemo: !!opts.isDemo, createdAt: nowISO() };
  if (opts.pin) Object.assign(p, await hashPin(opts.pin));
  await tx(['profiles', 'preferences'], 'readwrite', async (t) => {
    await reqP(t.objectStore('profiles').add(p));
    await reqP(t.objectStore('preferences').add(defaultPreferences(p.id)));
  });
  return p;
}

export async function updateProfile(p: Profile, changes: { name?: string; pin?: string | null }): Promise<Profile> {
  const next: Profile = { ...p };
  if (changes.name !== undefined) next.name = changes.name.trim() || p.name;
  if (changes.pin === null) { delete next.pinHash; delete next.pinSalt; }
  else if (changes.pin) Object.assign(next, await hashPin(changes.pin));
  await tx(['profiles'], 'readwrite', (t) => reqP(t.objectStore('profiles').put(next)));
  return next;
}

/** Elimina un perfil y TODOS sus datos en una sola transacción. */
export async function deleteProfile(profileId: ID): Promise<void> {
  const stores: StoreName[] = ['profiles', 'preferences', 'garments', 'images', 'statusHistory', 'maintenance', 'outfits', 'recommendations', 'ratings', 'blocked', 'wears', 'planned'];
  await tx(stores, 'readwrite', async (t) => {
    await reqP(t.objectStore('profiles').delete(profileId));
    await reqP(t.objectStore('preferences').delete(profileId));
    for (const s of stores.slice(2)) {
      const keys = await reqP(t.objectStore(s).index('profileId').getAllKeys(profileId));
      for (const k of keys) await reqP(t.objectStore(s).delete(k));
    }
  });
}

export function defaultPreferences(profileId: ID): UserPreferences {
  return {
    profileId, preferredStyles: [], avoidColors: [], repeatWindowDays: 7, afterWear: 'preguntar', allowUsedPending: false,
    weights: { ...DEFAULT_WEIGHTS }, minCoherence: ENGINE.minCoherence, updatedAt: nowISO(),
  };
}

// PIN: PBKDF2-SHA256 con sal aleatoria. Es una barrera de conveniencia entre personas que comparten
// un dispositivo; NO protege frente a alguien con acceso a las herramientas del navegador.
const b64 = (u: ArrayBuffer | Uint8Array) => btoa(String.fromCharCode(...new Uint8Array(u instanceof Uint8Array ? u : new Uint8Array(u))));
async function derive(pin: string, salt: Uint8Array): Promise<string> {
  const key = await crypto.subtle.importKey('raw', new TextEncoder().encode(pin), 'PBKDF2', false, ['deriveBits']);
  const bits = await crypto.subtle.deriveBits({ name: 'PBKDF2', hash: 'SHA-256', salt: salt as BufferSource, iterations: 150_000 }, key, 256);
  return b64(bits);
}
export async function hashPin(pin: string): Promise<{ pinHash: string; pinSalt: string }> {
  if (!/^\d{4,8}$/.test(pin)) throw new Error('El PIN debe tener entre 4 y 8 dígitos.');
  const salt = crypto.getRandomValues(new Uint8Array(16));
  return { pinHash: await derive(pin, salt), pinSalt: b64(salt) };
}
export async function verifyPin(p: Profile, pin: string): Promise<boolean> {
  if (!p.pinHash || !p.pinSalt) return true;
  const salt = Uint8Array.from(atob(p.pinSalt), (c) => c.charCodeAt(0));
  return (await derive(pin, salt)) === p.pinHash;
}

// ---------------- Repositorio por perfil ----------------
type Owned = { id: ID; profileId: ID };

export class ProfileRepo {
  constructor(readonly profileId: ID) {}

  // --- utilidades genéricas con control de propietario ---
  private async all<T>(store: StoreName): Promise<T[]> {
    const db = await openDB();
    return reqP(db.transaction(store).objectStore(store).index('profileId').getAll(this.profileId) as IDBRequest<T[]>);
  }
  private async one<T extends Owned>(store: StoreName, id: ID): Promise<T | undefined> {
    const db = await openDB();
    const r = (await reqP(db.transaction(store).objectStore(store).get(id))) as T | undefined;
    return r && r.profileId === this.profileId ? r : undefined; // aislamiento
  }
  private async putOwned<T extends Owned>(t: IDBTransaction, store: StoreName, rec: T): Promise<void> {
    const os = t.objectStore(store);
    const existing = (await reqP(os.get(rec.id))) as Owned | undefined;
    if (existing && existing.profileId !== this.profileId) throw new NotFoundError();
    await reqP(os.put({ ...rec, profileId: this.profileId }));
  }
  private async deleteOwned(t: IDBTransaction, store: StoreName, id: ID): Promise<void> {
    const os = t.objectStore(store);
    const existing = (await reqP(os.get(id))) as Owned | undefined;
    if (!existing || existing.profileId !== this.profileId) throw new NotFoundError();
    await reqP(os.delete(id));
  }

  // --- preferencias ---
  async preferences(): Promise<UserPreferences> {
    const db = await openDB();
    const p = (await reqP(db.transaction('preferences').objectStore('preferences').get(this.profileId))) as UserPreferences | undefined;
    const d = defaultPreferences(this.profileId);
    return p ? { ...d, ...p, weights: { ...d.weights, ...p.weights } } : d;
  }
  async savePreferences(p: UserPreferences): Promise<void> {
    await tx(['preferences'], 'readwrite', (t) => reqP(t.objectStore('preferences').put({ ...p, profileId: this.profileId, updatedAt: nowISO() })));
  }

  // --- prendas ---
  garments() { return this.all<Garment>('garments'); }
  garment(id: ID) { return this.one<Garment>('garments', id); }

  async saveGarment(input: Omit<Garment, 'id' | 'profileId' | 'createdAt' | 'updatedAt' | 'wearCount' | 'lastWornAt' | 'status'> & { id?: ID; status?: GarmentStatus }, image?: Omit<GarmentImage, 'profileId'>): Promise<Garment> {
    validateGarment(input);
    const existing = input.id ? await this.garment(input.id) : undefined;
    if (input.id && !existing) throw new NotFoundError();
    const g: Garment = {
      ...(existing ?? { wearCount: 0, status: input.status ?? 'disponible', createdAt: nowISO() }),
      ...input,
      status: existing?.status ?? input.status ?? 'disponible', // el estado solo cambia vía changeStatus
      wearCount: existing?.wearCount ?? 0,
      lastWornAt: existing?.lastWornAt,
      id: existing?.id ?? newId(),
      profileId: this.profileId,
      updatedAt: nowISO(),
    } as Garment;
    const oldImage = existing?.imageId;
    if (image) g.imageId = image.id;
    await tx(['garments', 'images', 'statusHistory'], 'readwrite', async (t) => {
      if (image) await this.putOwned(t, 'images', { ...image, profileId: this.profileId });
      if (image && oldImage && oldImage !== image.id) await this.deleteOwned(t, 'images', oldImage).catch(() => undefined);
      await this.putOwned(t, 'garments', g);
      if (!existing) await this.putOwned<StatusChange>(t, 'statusHistory', { id: newId(), profileId: this.profileId, garmentId: g.id, from: null, to: g.status, at: nowISO(), note: 'Registro inicial' });
    });
    return g;
  }

  async deleteGarment(id: ID): Promise<void> {
    const g = await this.garment(id);
    if (!g) throw new NotFoundError();
    await tx(['garments', 'images', 'statusHistory', 'maintenance'], 'readwrite', async (t) => {
      await this.deleteOwned(t, 'garments', id);
      if (g.imageId) await this.deleteOwned(t, 'images', g.imageId).catch(() => undefined);
      for (const s of ['statusHistory', 'maintenance'] as const) {
        const keys = await reqP(t.objectStore(s).index('garmentId').getAllKeys(id));
        for (const k of keys) await reqP(t.objectStore(s).delete(k));
      }
    });
  }

  image(id: ID) { return this.one<GarmentImage>('images', id); }

  // --- estados y mantenimiento (transaccional) ---
  async changeStatus(garmentId: ID, to: GarmentStatus, opts: { reason?: string; note?: string } = {}): Promise<Garment> {
    return tx(['garments', 'statusHistory', 'maintenance'], 'readwrite', async (t) => {
      const g = (await reqP(t.objectStore('garments').get(garmentId))) as Garment | undefined;
      if (!g || g.profileId !== this.profileId) throw new NotFoundError();
      const effects = planTransition(g.status, { to, reason: opts.reason, note: opts.note });
      const at = nowISO();
      if (effects.closeMaintenance) {
        const recs = (await reqP(t.objectStore('maintenance').index('garmentId').getAll(garmentId))) as MaintenanceRecord[];
        for (const m of recs) if (!m.resolvedAt && m.profileId === this.profileId) await reqP(t.objectStore('maintenance').put({ ...m, resolvedAt: at, notes: [m.notes, opts.note].filter(Boolean).join(' · ') || undefined }));
      }
      if (effects.openMaintenance)
        await this.putOwned<MaintenanceRecord>(t, 'maintenance', { id: newId(), profileId: this.profileId, garmentId, kind: effects.openMaintenance, reason: opts.reason?.trim() || undefined, reportedAt: at, notes: opts.note?.trim() || undefined });
      const next = { ...g, status: to, updatedAt: at };
      await reqP(t.objectStore('garments').put(next));
      await this.putOwned<StatusChange>(t, 'statusHistory', { id: newId(), profileId: this.profileId, garmentId, from: g.status, to, at, note: [opts.reason, opts.note].filter(Boolean).join(' · ') || undefined });
      return next;
    });
  }
  async updateMaintenanceNotes(id: ID, notes: string): Promise<void> {
    const m = await this.one<MaintenanceRecord>('maintenance', id);
    if (!m) throw new NotFoundError();
    await tx(['maintenance'], 'readwrite', (t) => this.putOwned(t, 'maintenance', { ...m, notes }));
  }
  statusHistory() { return this.all<StatusChange>('statusHistory'); }
  maintenance() { return this.all<MaintenanceRecord>('maintenance'); }

  // --- outfits guardados ---
  outfits() { return this.all<Outfit>('outfits'); }
  outfit(id: ID) { return this.one<Outfit>('outfits', id); }
  async saveOutfit(o: Omit<Outfit, 'id' | 'profileId' | 'createdAt'> & { id?: ID }): Promise<Outfit> {
    await this.assertOwnItems(o.itemIds);
    if (!o.name.trim()) throw new Error('Ponle un nombre al outfit.');
    const existing = o.id ? await this.outfit(o.id) : undefined;
    if (o.id && !existing) throw new NotFoundError();
    const rec: Outfit = { ...o, id: existing?.id ?? newId(), profileId: this.profileId, createdAt: existing?.createdAt ?? nowISO() };
    await tx(['outfits'], 'readwrite', (t) => this.putOwned(t, 'outfits', rec));
    return rec;
  }
  async deleteOutfit(id: ID) { await tx(['outfits'], 'readwrite', (t) => this.deleteOwned(t, 'outfits', id)); }

  // --- recomendaciones (mostrada → aceptada | rechazada) ---
  recommendations() { return this.all<RecommendationRecord>('recommendations'); }
  async logRecommendations(recs: Omit<RecommendationRecord, 'id' | 'profileId' | 'createdAt' | 'status'>[]): Promise<RecommendationRecord[]> {
    const out = recs.map((r) => ({ ...r, id: newId(), profileId: this.profileId, createdAt: nowISO(), status: 'mostrada' as const }));
    await tx(['recommendations'], 'readwrite', async (t) => { for (const r of out) await this.putOwned(t, 'recommendations', r); });
    return out;
  }
  async setRecommendationStatus(id: ID, status: 'aceptada' | 'rechazada'): Promise<void> {
    const r = await this.one<RecommendationRecord>('recommendations', id);
    if (!r) throw new NotFoundError();
    await tx(['recommendations'], 'readwrite', (t) => this.putOwned(t, 'recommendations', { ...r, status }));
  }

  // --- valoraciones y vetos ---
  ratings() { return this.all<OutfitRating>('ratings'); }
  async rate(itemIds: ID[], rating: number): Promise<void> {
    if (!Number.isInteger(rating) || rating < 1 || rating > 5) throw new Error('La calificación va de 1 a 5.');
    await this.assertOwnItems(itemIds);
    const key = comboKey(itemIds);
    const prev = (await this.ratings()).find((r) => r.comboKey === key);
    await tx(['ratings'], 'readwrite', (t) => this.putOwned<OutfitRating>(t, 'ratings', { id: prev?.id ?? newId(), profileId: this.profileId, comboKey: key, itemIds: [...itemIds].sort(), rating, at: nowISO() }));
  }
  blocked() { return this.all<BlockedCombo>('blocked'); }
  async block(itemIds: ID[]): Promise<void> {
    if (itemIds.length < 2) throw new Error('Una combinación bloqueada necesita al menos dos prendas.');
    await this.assertOwnItems(itemIds);
    await tx(['blocked'], 'readwrite', (t) => this.putOwned<BlockedCombo>(t, 'blocked', { id: newId(), profileId: this.profileId, itemIds: [...itemIds].sort(), createdAt: nowISO() }));
  }
  async unblock(id: ID) { await tx(['blocked'], 'readwrite', (t) => this.deleteOwned(t, 'blocked', id)); }

  // --- historial de uso ---
  wears() { return this.all<WearRecord>('wears'); }
  /**
   * Registra lo que realmente se usó. Actualiza en la MISMA transacción el conteo de usos y la
   * última fecha (recalculados desde el historial) y, si corresponde, el estado post-uso.
   */
  async registerWear(w: { date: ISODate; itemIds: ID[]; outfitId?: ID; recommendationId?: ID; eventType?: string }, afterWear: UserPreferences['afterWear']): Promise<WearRecord> {
    if (!w.itemIds.length) throw new Error('Selecciona al menos una prenda.');
    if (w.date > todayISO()) throw new Error('No puedes registrar como usado un outfit con fecha futura: usa "Planificar".');
    const rec: WearRecord = { ...w, id: newId(), profileId: this.profileId, createdAt: nowISO() };
    await tx(['wears', 'garments', 'statusHistory', 'recommendations'], 'readwrite', async (t) => {
      const garments: Garment[] = [];
      for (const id of w.itemIds) {
        const g = (await reqP(t.objectStore('garments').get(id))) as Garment | undefined;
        if (!g || g.profileId !== this.profileId) throw new NotFoundError();
        garments.push(g);
      }
      await this.putOwned(t, 'wears', rec);
      const all = (await reqP(t.objectStore('wears').index('profileId').getAll(this.profileId))) as WearRecord[];
      for (const g of garments) {
        const usage = usageFromHistory(g.id, all, todayISO());
        const next: Garment = { ...g, ...usage, updatedAt: nowISO() };
        // Solo prendas que estaban disponibles pasan a "usada" (no se asume lavado automático).
        if (afterWear === 'preguntar' && g.status === 'disponible' && w.date === todayISO()) {
          next.status = 'usada';
          await this.putOwned<StatusChange>(t, 'statusHistory', { id: newId(), profileId: this.profileId, garmentId: g.id, from: g.status, to: 'usada', at: nowISO(), note: 'Uso registrado' });
        }
        await reqP(t.objectStore('garments').put(next));
      }
      if (w.recommendationId) {
        const r = (await reqP(t.objectStore('recommendations').get(w.recommendationId))) as RecommendationRecord | undefined;
        if (r && r.profileId === this.profileId) await reqP(t.objectStore('recommendations').put({ ...r, status: 'aceptada' }));
      }
    });
    return rec;
  }
  async deleteWear(id: ID): Promise<void> {
    await tx(['wears', 'garments'], 'readwrite', async (t) => {
      const w = (await reqP(t.objectStore('wears').get(id))) as WearRecord | undefined;
      if (!w || w.profileId !== this.profileId) throw new NotFoundError();
      await reqP(t.objectStore('wears').delete(id));
      const all = (await reqP(t.objectStore('wears').index('profileId').getAll(this.profileId))) as WearRecord[];
      for (const gid of w.itemIds) {
        const g = (await reqP(t.objectStore('garments').get(gid))) as Garment | undefined;
        if (!g || g.profileId !== this.profileId) continue;
        const usage = usageFromHistory(gid, all, todayISO());
        await reqP(t.objectStore('garments').put({ ...g, wearCount: usage.wearCount, lastWornAt: usage.lastWornAt, updatedAt: nowISO() }));
      }
    });
  }

  // --- planificación ---
  planned() { return this.all<PlannedOutfit>('planned'); }
  async plan(p: { date: ISODate; itemIds: ID[]; outfitId?: ID; eventType?: string; note?: string }): Promise<PlannedOutfit> {
    if (!p.itemIds.length) throw new Error('Selecciona al menos una prenda.');
    await this.assertOwnItems(p.itemIds);
    const rec: PlannedOutfit = { ...p, id: newId(), profileId: this.profileId, createdAt: nowISO() };
    await tx(['planned'], 'readwrite', (t) => this.putOwned(t, 'planned', rec));
    return rec;
  }
  async deletePlan(id: ID) { await tx(['planned'], 'readwrite', (t) => this.deleteOwned(t, 'planned', id)); }

  private async assertOwnItems(ids: ID[]) {
    for (const id of ids) if (!(await this.garment(id))) throw new NotFoundError();
  }
}

export function validateGarment(g: Partial<Garment>): void {
  if (!g.name?.trim()) throw new Error('El nombre es obligatorio.');
  if (g.name.length > 80) throw new Error('El nombre es demasiado largo (máx. 80).');
  if (!g.category) throw new Error('Elige una categoría.');
  if (!g.colorPrimary) throw new Error('Elige el color principal.');
  if (g.formality === undefined || g.formality < 1 || g.formality > 5) throw new Error('La formalidad va de 1 a 5.');
  if (g.tempMin === undefined || g.tempMax === undefined || Number.isNaN(g.tempMin) || Number.isNaN(g.tempMax)) throw new Error('Indica el rango de temperatura.');
  if (g.tempMin > g.tempMax) throw new Error('La temperatura mínima no puede ser mayor que la máxima.');
  if (g.tempMin < -40 || g.tempMax > 50) throw new Error('Rango de temperatura fuera de lo razonable (-40 a 50 °C).');
  if (g.cost !== undefined && g.cost !== null && (Number.isNaN(g.cost) || g.cost < 0)) throw new Error('El costo no puede ser negativo.');
  if (g.notes && g.notes.length > 1000) throw new Error('Las observaciones son demasiado largas.');
}
