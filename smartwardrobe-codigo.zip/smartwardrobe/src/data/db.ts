// Capa mínima sobre IndexedDB (sin dependencias).
// Esquema relacional en almacenes de objetos: cada almacén tiene clave primaria `id`
// e índice `profileId`; las relaciones se resuelven por id en el repositorio.
// Las versiones del esquema son migraciones: añadir un `case` en `upgrade` por versión.

export const DB_NAME = 'smartwardrobe';
export const DB_VERSION = 1;

export const STORES = [
  'garments', 'images', 'statusHistory', 'maintenance', 'outfits', 'recommendations',
  'ratings', 'blocked', 'wears', 'planned',
] as const;
export type StoreName = (typeof STORES)[number] | 'profiles' | 'preferences';

function upgrade(db: IDBDatabase, oldVersion: number) {
  // Migración 0 → 1: esquema inicial.
  if (oldVersion < 1) {
    db.createObjectStore('profiles', { keyPath: 'id' });
    db.createObjectStore('preferences', { keyPath: 'profileId' });
    for (const s of STORES) {
      const os = db.createObjectStore(s, { keyPath: 'id' });
      os.createIndex('profileId', 'profileId', { unique: false });
      if (s === 'statusHistory' || s === 'maintenance') os.createIndex('garmentId', 'garmentId', { unique: false });
      if (s === 'wears' || s === 'planned') os.createIndex('profile_date', ['profileId', 'date'], { unique: false });
    }
  }
  // if (oldVersion < 2) { … futuras migraciones … }
}

let dbPromise: Promise<IDBDatabase> | null = null;

export function openDB(name = DB_NAME): Promise<IDBDatabase> {
  if (dbPromise) return dbPromise;
  dbPromise = new Promise((resolve, reject) => {
    const req = indexedDB.open(name, DB_VERSION);
    req.onupgradeneeded = (ev) => upgrade(req.result, ev.oldVersion);
    req.onsuccess = () => {
      const db = req.result;
      db.onversionchange = () => { db.close(); location.reload(); };
      resolve(db);
    };
    req.onerror = () => reject(req.error);
    req.onblocked = () => reject(new Error('La base de datos está abierta en otra pestaña con una versión anterior. Ciérrala y recarga.'));
  });
  return dbPromise;
}

export function reqP<T>(r: IDBRequest<T>): Promise<T> {
  return new Promise((res, rej) => { r.onsuccess = () => res(r.result); r.onerror = () => rej(r.error); });
}

/** Ejecuta `fn` dentro de una transacción; se confirma solo si todas las operaciones tienen éxito. */
export async function tx<T>(stores: StoreName[], mode: IDBTransactionMode, fn: (t: IDBTransaction) => Promise<T> | T): Promise<T> {
  const db = await openDB();
  const t = db.transaction(stores, mode);
  const done = new Promise<void>((res, rej) => { t.oncomplete = () => res(); t.onerror = () => rej(t.error); t.onabort = () => rej(t.error ?? new Error('Transacción abortada')); });
  let result: T;
  try {
    result = await fn(t);
  } catch (e) {
    try { t.abort(); } catch { /* ya finalizada */ }
    throw e;
  }
  await done;
  return result;
}

/** Pide al navegador almacenamiento persistente (reduce el riesgo de que borre los datos). */
export async function requestPersistence(): Promise<boolean> {
  try { return (await navigator.storage?.persist?.()) ?? false; } catch { return false; }
}

export async function storageEstimate(): Promise<{ usage: number; quota: number; persisted: boolean } | null> {
  try {
    const e = await navigator.storage.estimate();
    const persisted = (await navigator.storage.persisted?.()) ?? false;
    return { usage: e.usage ?? 0, quota: e.quota ?? 0, persisted };
  } catch { return null; }
}
