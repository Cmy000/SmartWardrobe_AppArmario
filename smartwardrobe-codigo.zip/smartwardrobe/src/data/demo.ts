// Datos de demostración. Viven SIEMPRE en un perfil separado marcado `isDemo`, con
// ilustraciones generadas (no fotos) y la etiqueta "DEMO", para no confundirlos con datos reales.
import { CATEGORIES, COLORS } from '../domain/catalog';
import { addDays, today } from '../domain/dates';
import type { Category, Garment, Pattern, Style } from '../domain/types';
import { processImage } from './images';
import { createProfile, ProfileRepo } from './repo';

type Seed = [string, Category, string, Style, number?, Pattern?, Partial<Garment>?];
const SEEDS: Seed[] = [
  ['Camiseta blanca básica', 'camiseta', 'blanco', 'casual'],
  ['Camiseta negra', 'camiseta', 'negro', 'minimalista'],
  ['Camisa celeste Oxford', 'camisa', 'celeste', 'elegante', 3],
  ['Blusa de seda marfil', 'blusa', 'beige', 'elegante', 4],
  ['Suéter de lana gris', 'sueter', 'gris', 'minimalista', 2],
  ['Suéter mostaza', 'sueter', 'mostaza', 'bohemio', 2],
  ['Jean azul recto', 'jean', 'denim', 'casual'],
  ['Pantalón negro de vestir', 'pantalon', 'negro', 'formal', 4],
  ['Pantalón beige chino', 'pantalon', 'beige', 'casual', 3],
  ['Falda midi plisada', 'falda', 'vinotinto', 'elegante', 3],
  ['Vestido negro', 'vestido', 'negro', 'elegante', 4, 'liso', { tempMin: 14 }],
  ['Vestido de flores', 'vestido', 'rosado', 'bohemio', 2, 'flores'],
  ['Blazer azul marino', 'blazer', 'azul_marino', 'formal', 4],
  ['Chaqueta de jean', 'chaqueta', 'denim', 'urbano', 2],
  ['Gabardina camel', 'abrigo', 'camel', 'elegante', 4, 'liso', { waterproof: true, tempMax: 18 }],
  ['Tenis blancos', 'tenis', 'blanco', 'urbano'],
  ['Mocasines marrón', 'zapatos', 'marron', 'elegante', 4],
  ['Botines negros impermeables', 'botas', 'negro', 'urbano', 3, 'liso', { waterproof: true }],
  ['Bufanda de cuadros', 'bufanda', 'vinotinto', 'casual', 2, 'cuadros'],
  ['Bolso de cuero camel', 'bolso', 'camel', 'elegante', 4],
];

async function placeholder(label: string, hex: string): Promise<Blob> {
  const c = document.createElement('canvas');
  c.width = 600; c.height = 750;
  const x = c.getContext('2d')!;
  x.fillStyle = '#f5f1ea'; x.fillRect(0, 0, 600, 750);
  x.fillStyle = hex; x.strokeStyle = 'rgba(0,0,0,.25)'; x.lineWidth = 6;
  x.beginPath(); x.roundRect(150, 170, 300, 380, 40); x.fill(); x.stroke();
  x.fillStyle = '#57534e'; x.font = '600 34px system-ui, sans-serif'; x.textAlign = 'center';
  x.fillText(label, 300, 640);
  x.fillStyle = '#a8a29e'; x.font = '700 26px system-ui, sans-serif'; x.fillText('DEMO · ilustración', 300, 100);
  return new Promise((r) => c.toBlob((b) => r(b!), 'image/jpeg', 0.85));
}

export async function createDemoProfile(): Promise<string> {
  const p = await createProfile('Demo', { isDemo: true });
  const repo = new ProfileRepo(p.id);
  const ids: string[] = [];
  for (const [name, cat, color, style, formality, pattern, extra] of SEEDS) {
    const info = CATEGORIES[cat];
    const img = await processImage(await placeholder(info.label, COLORS[color].hex));
    const g = await repo.saveGarment({
      name, category: cat, colorPrimary: color, colorsSecondary: [], pattern: pattern ?? 'liso', style,
      formality: formality ?? info.defaultFormality, seasons: ['todo_el_ano'], tempMin: info.defaultTemp[0], tempMax: info.defaultTemp[1],
      waterproof: false, favorite: false, tags: ['demo'], ...extra,
    }, img);
    ids.push(g.id);
  }
  // Algunos usos pasados y estados de mantenimiento para que todas las pantallas tengan contenido.
  const t = today();
  const prefs = await repo.preferences();
  await repo.registerWear({ date: addDays(t, -20), itemIds: [ids[0], ids[6], ids[15]], eventType: 'diario' }, 'disponible');
  await repo.registerWear({ date: addDays(t, -12), itemIds: [ids[2], ids[7], ids[16], ids[12]], eventType: 'trabajo' }, 'disponible');
  await repo.registerWear({ date: addDays(t, -5), itemIds: [ids[4], ids[8], ids[17]], eventType: 'diario' }, 'disponible');
  await repo.changeStatus(ids[1], 'lavanderia');
  await repo.changeStatus(ids[13], 'reparacion', { reason: 'Botón suelto' });
  await repo.savePreferences({ ...prefs, location: { name: 'Bogotá, Colombia', latitude: 4.60971, longitude: -74.08175 }, preferredStyles: ['minimalista', 'elegante'] });
  return p.id;
}
