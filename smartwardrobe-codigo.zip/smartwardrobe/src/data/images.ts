// Tratamiento de fotografías.
// - Valida tamaño y CONTENIDO real (se decodifica la imagen; un archivo que no es imagen falla).
// - Re-codifica a JPEG: elimina metadatos EXIF (incluida la ubicación GPS del celular)
//   y corrige la orientación.
// - Genera miniatura. Las imágenes se guardan en IndexedDB del perfil, nunca como archivos públicos.
import type { GarmentImage } from '../domain/types';
import { newId } from './repo';

export const MAX_UPLOAD_BYTES = 15 * 1024 * 1024;
export const FULL_SIZE = 1280;
export const THUMB_SIZE = 400;
const ACCEPTED = /^image\/(jpeg|png|webp|gif|avif|heic|heif)$/i;

export class ImageError extends Error {}

async function decode(file: Blob): Promise<ImageBitmap | HTMLImageElement> {
  if ('createImageBitmap' in window) {
    try { return await createImageBitmap(file, { imageOrientation: 'from-image' }); } catch { /* fallback */ }
  }
  const url = URL.createObjectURL(file);
  try {
    const img = new Image();
    img.src = url;
    await img.decode();
    return img;
  } finally {
    URL.revokeObjectURL(url);
  }
}

function render(src: ImageBitmap | HTMLImageElement, max: number, quality: number): Promise<{ blob: Blob; w: number; h: number }> {
  const sw = 'naturalWidth' in src ? src.naturalWidth : src.width;
  const sh = 'naturalHeight' in src ? src.naturalHeight : src.height;
  const scale = Math.min(1, max / Math.max(sw, sh));
  const w = Math.max(1, Math.round(sw * scale));
  const h = Math.max(1, Math.round(sh * scale));
  const canvas = document.createElement('canvas');
  canvas.width = w;
  canvas.height = h;
  const ctx = canvas.getContext('2d')!;
  ctx.fillStyle = '#ffffff'; // fondo para PNG con transparencia
  ctx.fillRect(0, 0, w, h);
  ctx.drawImage(src, 0, 0, w, h);
  return new Promise((res, rej) => canvas.toBlob((b) => (b ? res({ blob: b, w, h }) : rej(new ImageError('No se pudo procesar la imagen.'))), 'image/jpeg', quality));
}

export async function processImage(file: File | Blob): Promise<Omit<GarmentImage, 'profileId'>> {
  if (file.size === 0) throw new ImageError('El archivo está vacío.');
  if (file.size > MAX_UPLOAD_BYTES) throw new ImageError('La imagen supera 15 MB.');
  if (file.type && !ACCEPTED.test(file.type)) throw new ImageError('Formato no admitido. Usa JPG, PNG o WebP.');
  let bmp: ImageBitmap | HTMLImageElement;
  try {
    bmp = await decode(file);
  } catch {
    throw new ImageError(/heic|heif/i.test(file.type) ? 'Este navegador no puede leer fotos HEIC. En el iPhone: Ajustes → Cámara → Formatos → "Más compatible".' : 'El archivo no es una imagen válida.');
  }
  const full = await render(bmp, FULL_SIZE, 0.82);
  const thumb = await render(bmp, THUMB_SIZE, 0.78);
  if ('close' in bmp) bmp.close();
  return { id: newId(), full: full.blob, thumb: thumb.blob, width: full.w, height: full.h, createdAt: new Date().toISOString() };
}

/** Color dominante aproximado (promedio de la zona central), como sugerencia editable. */
export async function suggestColor(blob: Blob, palette: Record<string, { hex: string }>): Promise<string | null> {
  try {
    const bmp = await createImageBitmap(blob);
    const c = document.createElement('canvas');
    c.width = 24; c.height = 24;
    const ctx = c.getContext('2d')!;
    ctx.drawImage(bmp, bmp.width * 0.25, bmp.height * 0.25, bmp.width * 0.5, bmp.height * 0.5, 0, 0, 24, 24);
    const d = ctx.getImageData(0, 0, 24, 24).data;
    let r = 0, g = 0, b = 0;
    for (let i = 0; i < d.length; i += 4) { r += d[i]; g += d[i + 1]; b += d[i + 2]; }
    const n = d.length / 4;
    r /= n; g /= n; b /= n;
    let best: string | null = null, bestD = Infinity;
    for (const [k, v] of Object.entries(palette)) {
      const pr = parseInt(v.hex.slice(1, 3), 16), pg = parseInt(v.hex.slice(3, 5), 16), pb = parseInt(v.hex.slice(5, 7), 16);
      const dist = (pr - r) ** 2 * 0.3 + (pg - g) ** 2 * 0.59 + (pb - b) ** 2 * 0.11;
      if (dist < bestD) { bestD = dist; best = k; }
    }
    return best;
  } catch { return null; }
}
