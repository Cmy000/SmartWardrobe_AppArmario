// Copias de seguridad y restauración (ZIP: data.json + imágenes) y exportación CSV del inventario.
// La restauración crea un perfil NUEVO con identificadores nuevos: nunca sobrescribe ni mezcla
// datos de otros perfiles, y se puede importar el mismo respaldo en otro dispositivo.
import JSZip from 'jszip';
import { CATEGORIES, COLORS, STATUS_LABEL } from '../domain/catalog';
import type { Garment, Profile, UserPreferences } from '../domain/types';
import { openDB, reqP, tx, type StoreName } from './db';
import { defaultPreferences, newId, ProfileRepo } from './repo';

export const BACKUP_FORMAT = 'smartwardrobe-backup';
export const BACKUP_VERSION = 1;

const DATA_STORES = ['garments', 'statusHistory', 'maintenance', 'outfits', 'recommendations', 'ratings', 'blocked', 'wears', 'planned'] as const;

export async function exportProfile(profile: Profile): Promise<Blob> {
  const db = await openDB();
  const zip = new JSZip();
  const data: Record<string, unknown> = {
    format: BACKUP_FORMAT, version: BACKUP_VERSION, exportedAt: new Date().toISOString(),
    profile: { name: profile.name, isDemo: profile.isDemo, createdAt: profile.createdAt },
    preferences: await new ProfileRepo(profile.id).preferences(),
  };
  for (const s of DATA_STORES) data[s] = await reqP(db.transaction(s).objectStore(s).index('profileId').getAll(profile.id));
  const images = (await reqP(db.transaction('images').objectStore('images').index('profileId').getAll(profile.id))) as Array<{ id: string; full: Blob; thumb: Blob; width: number; height: number; createdAt: string }>;
  data.images = images.map((i) => ({ id: i.id, width: i.width, height: i.height, createdAt: i.createdAt }));
  for (const i of images) {
    zip.file(`images/${i.id}.jpg`, i.full);
    zip.file(`images/${i.id}.thumb.jpg`, i.thumb);
  }
  zip.file('data.json', JSON.stringify(data, null, 1));
  zip.file('LEEME.txt', 'Respaldo de SmartWardrobe. Restaurar: Ajustes → Copias de seguridad → Restaurar respaldo.\n');
  return zip.generateAsync({ type: 'blob', compression: 'DEFLATE' });
}

export class BackupError extends Error {}

/** Restaura un respaldo como un perfil nuevo. Devuelve el perfil creado. */
export async function importBackup(file: Blob, nameOverride?: string): Promise<Profile> {
  let zip: JSZip;
  try { zip = await JSZip.loadAsync(file); } catch { throw new BackupError('El archivo no es un respaldo ZIP válido.'); }
  const raw = await zip.file('data.json')?.async('string');
  if (!raw) throw new BackupError('El respaldo no contiene data.json.');
  let data: Record<string, unknown>;
  try { data = JSON.parse(raw); } catch { throw new BackupError('data.json está dañado.'); }
  if (data.format !== BACKUP_FORMAT) throw new BackupError('El archivo no es un respaldo de SmartWardrobe.');
  if (typeof data.version !== 'number' || data.version > BACKUP_VERSION) throw new BackupError('El respaldo fue creado con una versión más nueva de la aplicación.');

  // Mapa de ids antiguos → nuevos para todas las entidades.
  const idMap = new Map<string, string>();
  const remap = (id: unknown) => {
    if (typeof id !== 'string') return id;
    if (!idMap.has(id)) idMap.set(id, newId());
    return idMap.get(id)!;
  };
  const profileId = newId();
  const srcProfile = (data.profile ?? {}) as Partial<Profile>;
  const profile: Profile = { id: profileId, name: (nameOverride || srcProfile.name || 'Restaurado').slice(0, 40), isDemo: !!srcProfile.isDemo, createdAt: new Date().toISOString() };

  // Imágenes: se leen ANTES de abrir la transacción (IndexedDB no admite esperas externas dentro).
  const imgMeta = (Array.isArray(data.images) ? data.images : []) as Array<{ id: string; width: number; height: number; createdAt: string }>;
  const images: Array<{ id: string; profileId: string; full: Blob; thumb: Blob; width: number; height: number; createdAt: string }> = [];
  for (const m of imgMeta) {
    const full = await zip.file(`images/${m.id}.jpg`)?.async('blob');
    const thumb = await zip.file(`images/${m.id}.thumb.jpg`)?.async('blob');
    if (full && thumb) images.push({ id: remap(m.id) as string, profileId, full: new Blob([full], { type: 'image/jpeg' }), thumb: new Blob([thumb], { type: 'image/jpeg' }), width: m.width, height: m.height, createdAt: m.createdAt });
  }

  const remapRecord = (r: Record<string, unknown>) => {
    const out: Record<string, unknown> = { ...r, id: remap(r.id), profileId };
    for (const k of ['garmentId', 'imageId', 'outfitId', 'recommendationId']) if (r[k]) out[k] = remap(r[k]);
    if (Array.isArray(r.itemIds)) out.itemIds = r.itemIds.map(remap);
    if (typeof r.comboKey === 'string') out.comboKey = (out.itemIds as string[]).slice().sort().join('|');
    return out;
  };
  const records: Record<string, Record<string, unknown>[]> = {};
  for (const s of DATA_STORES) {
    const list = Array.isArray(data[s]) ? (data[s] as Record<string, unknown>[]) : [];
    records[s] = list.filter((r) => r && typeof r.id === 'string').map(remapRecord);
  }
  for (const g of records.garments) {
    if (typeof g.name !== 'string' || !((g.category as string) in CATEGORIES)) throw new BackupError('El respaldo contiene prendas con datos inválidos.');
    if (g.imageId && !images.some((i) => i.id === g.imageId)) delete g.imageId;
  }
  const prefs: UserPreferences = { ...defaultPreferences(profileId), ...((data.preferences as object) ?? {}), profileId };

  const stores: StoreName[] = ['profiles', 'preferences', 'images', ...DATA_STORES];
  await tx(stores, 'readwrite', async (t) => {
    await reqP(t.objectStore('profiles').add(profile));
    await reqP(t.objectStore('preferences').put(prefs));
    for (const i of images) await reqP(t.objectStore('images').add(i));
    for (const s of DATA_STORES) for (const r of records[s]) await reqP(t.objectStore(s).add(r));
  });
  return profile;
}

const csvCell = (v: unknown) => {
  const s = v === undefined || v === null ? '' : Array.isArray(v) ? v.join('; ') : String(v);
  // Neutraliza fórmulas al abrir en Excel/Sheets (inyección CSV).
  const safe = /^[=+\-@]/.test(s) ? `'${s}` : s;
  return /[",\n;]/.test(safe) ? `"${safe.replace(/"/g, '""')}"` : safe;
};

export function garmentsToCSV(garments: Garment[]): string {
  const cols: Array<[string, (g: Garment) => unknown]> = [
    ['nombre', (g) => g.name], ['categoria', (g) => CATEGORIES[g.category].label], ['subcategoria', (g) => g.subcategory],
    ['color_principal', (g) => COLORS[g.colorPrimary]?.label ?? g.colorPrimary], ['colores_secundarios', (g) => g.colorsSecondary.map((c) => COLORS[c]?.label ?? c)],
    ['material', (g) => g.material], ['estampado', (g) => g.pattern], ['estilo', (g) => g.style], ['formalidad', (g) => g.formality],
    ['temporadas', (g) => g.seasons], ['temp_min', (g) => g.tempMin], ['temp_max', (g) => g.tempMax], ['impermeable', (g) => (g.waterproof ? 'sí' : 'no')],
    ['marca', (g) => g.brand], ['fecha_adquisicion', (g) => g.acquiredAt], ['costo', (g) => g.cost], ['usos', (g) => g.wearCount],
    ['ultimo_uso', (g) => g.lastWornAt], ['estado', (g) => STATUS_LABEL[g.status]], ['favorita', (g) => (g.favorite ? 'sí' : 'no')],
    ['etiquetas', (g) => g.tags], ['observaciones', (g) => g.notes],
  ];
  const lines = [cols.map((c) => c[0]).join(','), ...garments.map((g) => cols.map(([, f]) => csvCell(f(g))).join(','))];
  return '﻿' + lines.join('\n'); // BOM para que Excel respete tildes
}

export function downloadBlob(blob: Blob, filename: string) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 2000);
}
